# -*- coding: utf-8 -*-
import urllib2
import ssl
import json
import logging
import sys
import time
import os,bz2
import paramiko
import re,base64
from logging.handlers import RotatingFileHandler
reload(sys)
sys.setdefaultencoding('utf-8')
#ctx = ssl.create_default_context()
#ctx.check_hostname = False
#ctx.verify_mode = ssl.CERT_NONE

# HX 서버 및 API URI 정보
HXSRV = 'https://112.175.67.137:3000'
HXSRV_TOKEN = '/hx/api/v3/token'
HXSRV_HOSTS_SETS = '/hx/api/v3/host_sets'
HXSRV_HOSTS = '/hx/api/v3/hosts'
HXSRV_ACQS = '/hx/api/v3/acqs/triages'
HXSRV_ALL_ALERTS = '/hx/api/v3/alerts'
HXSRV_CONDITION_BY_ID = '/hx/api/v3/conditions'

# 현재 시간 리턴
def time_ch(limit):
    start_time = time.localtime()
    check_localtime = time.localtime()
    if limit == 'day' :
        time_check = str(check_localtime.tm_year) + '-' + str(check_localtime.tm_mon) + '-' + str(check_localtime.tm_mday)
    else :
        time_check = str(check_localtime.tm_year) + '-' + str(check_localtime.tm_mon) + '-' + str(check_localtime.tm_mday) + '_' + str(check_localtime.tm_hour) + ':' + str(check_localtime.tm_min) + ':' + str(check_localtime.tm_sec)
    return time_check

def hxlogger(logname) :
    log_dir_root = 'hx_req_log'
    log_dir = os.path.join(log_dir_root,logname)
    if os.path.isdir(log_dir_root) == False :
        os.mkdir(log_dir_root)
    if os.path.isdir(log_dir) == False :
        os.mkdir(log_dir)
    logfile = os.path.join(log_dir,'%s_%s.log' %(time_ch('day'),logname))
    # log level DEBUG < INFO < WARNING < ERROR < CRITICAL
    # logger 생성
    hxlogger = logging.getLogger(logname)
    hxlogger.setLevel(logging.INFO)

    # log format 설정
    formatter = logging.Formatter('[%(levelname)s,%(filename)s,%(lineno)s] %(asctime)s,%(message)s')

    # 출력위치 설정

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    hxlogger.addHandler(stream_handler)

    # 로그파일 용량 100MB * 10개
    fileMaxByte = 1024 * 1024 * 100 #100MB
    file_handler = RotatingFileHandler(logfile, maxBytes=fileMaxByte, backupCount=10)
    file_handler.setFormatter(formatter)
    file_handler.set_name('file_handler')
    hxlogger.addHandler(file_handler)
    # 메시지 출력,저장
    #hxlogger.info('kakaka1')
    return hxlogger

# API Request Logger
#HX_REQ_LOGGER = hxlogger('hxreqall')
BUG = base64.decodestring('IWRuZmxydWRkbXMy')
# HX서버 인증 토큰 수신
def get_token():
    msg = ''
    handler = urllib2.HTTPHandler()
    opener = urllib2.build_opener(handler)
    urllib2.install_opener(opener)
    data = None
    request = urllib2.Request(HXSRV + HXSRV_TOKEN , data=data)
    context = ssl._create_unverified_context()
    request.add_header('Accept', 'application/json')
    #request.add_header('Authorization', 'Basic aXN0ZWFtX2FwaTpeXmt2cHFoZGtz')
    request.add_header('Authorization', 'Basic aXN0ZWFtX2FwaTohSXN0ZWFtMA==')
    request.get_method = lambda: 'GET'
    try:
        response = urllib2.urlopen(request, context=context)
    except urllib2.HTTPError as e:
        msg += 'HX_REQ_Error_Token : ' + str(e.read())
        #HX_REQ_LOGGER.error(msg)
        return msg
    except urllib2.URLError as e:
        msg += 'HX_REQ_Error_Token : ' + str(e.read())
        #HX_REQ_LOGGER.error(msg)
        return msg
    else:
        token = response.info().getheader('X-FeApi-Token')
        #print token
        return token

# API 요청
def request_hx(token,uri,parameter,method,data_info,store='n'):
    handler = urllib2.HTTPHandler()
    opener = urllib2.build_opener(handler)
    urllib2.install_opener(opener)
    data = data_info
    req_url = HXSRV + uri + parameter
    msg = method + ' ' + uri + parameter + ' '
    '''
    if raw_input(' Request URL : %s    Ok  ? [y/n] ' %req_url) != 'y' :
        print '\r\n Bye'
        sys.exit(1)
    '''
    request = urllib2.Request(req_url , data=data)
    context = ssl._create_unverified_context()
    request.add_header('X-FeApi-Token',token)
    request.add_header('Accept', 'application/json')
    if method in ['PUT','PATCH'] and req_url.find('conditions') > -1 :
        request.add_header('Content-Type', 'text/plain')
    else : request.add_header('Content-Type', 'application/json')
    #request.add_header('Accept', 'application/octet-stream')
    #request.add_header('Content-Type', 'application/octet-stream')
    request.get_method = lambda: method
    try:
        response = urllib2.urlopen(request, context=context)
    except urllib2.HTTPError as e:
        msg += 'HX_REQ_Error_HTTP : ' + str(e.read())
        #HX_REQ_LOGGER.error(msg)
        return msg
    except urllib2.URLError as e:
        msg += 'HX_REQ_Error_URL_Connect : ' + str(e.reason)
        #HX_REQ_LOGGER.error(msg)
        return msg
    else:
        if method == 'DELETE' :
            #HX_REQ_LOGGER.info(msg)
            return msg
        result = response.read() #unicode(response.read().decode('utf-8')).encode('euc-kr')
        #print unicode(result.decode('utf-8')).encode('euc-kr')
        dic_result = json.loads(result) # json > dic
        uri = re.sub('[\&|\=|\/|\?]','_',uri + parameter)
        if store != 'n' :
            f = open(os.path.join('etc',method+ '_' + uri + '_' + time_ch('all').replace(':',';').replace(' ','_') + '.txt'),'wb')
            f.write(json.dumps(dic_result,indent=4))
            f.close()
        msg +=  'HX_REQ_Completed : ' + dic_result['message']
        #HX_REQ_LOGGER.info(msg)
        return dic_result  # 성공 시 dic 반환

def req_host_info_by_id(host_id) :
    host_info_url =  '/hx/api/v3/hosts/%s' %host_id
    response = request_hx(get_token(),host_info_url,'','GET',None)
    return response

def req_host_set_info_by_id(host_set_id) :
    host_set_url = '/hx/api/v3/host_sets/%s' %host_set_id
    response = request_hx(get_token(),host_set_url,'','GET',None)
    return response


def download_triage(token,uri):
    triage_dir = '/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files'
    if os.path.isdir(triage_dir) == False :
        os.mkdir(triage_dir)
    handler = urllib2.HTTPHandler()
    opener = urllib2.build_opener(handler)
    urllib2.install_opener(opener)
    data = None
    req_url = HXSRV + uri 
    msg = 'GET' + ' ' + uri + ' '
    request = urllib2.Request(req_url , data=data)
    context = ssl._create_unverified_context()
    request.add_header('X-FeApi-Token',token)
    request.add_header('Accept', 'application/json,application/octet-stream')
    request.add_header('Content-Type', 'application/json,application/octet-stream')
    request.get_method = lambda: 'GET'
    try:
        response = urllib2.urlopen(request, context=context)
    except urllib2.HTTPError as e:
        msg += 'HX_REQ_Error_HTTP : ' + str(e.read())
        #HX_REQ_LOGGER.error(msg)
        return msg
    except urllib2.URLError as e:
        msg += 'HX_REQ_Error_URL_Connect : ' + str(e.reason)
        #HX_REQ_LOGGER.error(msg)
        return msg
    else:
        result = response.read()
        triage_file_name = uri.split('/')[-1]
        triage_full_path = os.path.join(triage_dir,triage_file_name)
        if os.path.isfile(triage_full_path) == False :
            with open(triage_full_path,'wb') as tf :
                tf.write(result)
        msg +=  'HX_REQ_Completed : Store Triage File %s'%triage_full_path
        #HX_REQ_LOGGER.info(msg)
        return triage_full_path

def health_check_hx():
    #example : https://raw.githubusercontent.com/hdinthkld/snippets/master/paramiko-asa.py
    rebuf = 65535
    hello = bz2.decompress('BZh91AY&SY\xe8\x1c\x9a\x13\x00\x00\x03\t\x80D\x00\x00*\x08  \x00!\x89\x84!\x80\x8a[\xb7\x8b\xb9"\x9c(Ht\x0eM\t\x80')
    world = bz2.decompress('BZh91AY&SYR\x85\xd1o\x00\x00\x00\x19\x80 \x00\x10\x00\x05\x07\x1a\x00 \x00"\x03#!\x000\xa4\xc0[\x91\xc9\xf8\xbb\x92)\xc2\x84\x82\x94.\x8bx')
    newworld = bz2.decompress('BZh91AY&SYu\xdbH5\x00\x00\x01\x98\x00\x00\x01;\x80 \x00!\xa3\xd4\xc4!\x80\xbd\x06\xd6\xa0\xb5\xf8\xbb\x92)\xc2\x84\x83\xae\xdaA\xa8')
    cmds = ['show users','show stat alarm','show system hardware status','show stats cpu','show memory','show system hardware status raid','show files system detail','en','conf t','aaa authentication attempts reset all' ]

    client_pre=paramiko.SSHClient()
    client_pre.load_system_host_keys()
    client_pre.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client_pre.connect(newworld, username=hello , password=world, look_for_keys=False, allow_agent=False)
    # if use key file
    # client.connect(ip,username=hello,password=world,key_filename='key file path')
    client = client_pre.invoke_shell(width=100, height=100)
    time.sleep(1)
    output = client.recv(rebuf)
    report,error_str = '' , []
    #print (output.splitlines())
    for cmd in cmds :
        client.send(cmd + '\n')
        time.sleep(1)
        output = client.recv(rebuf)
        report += output
    report += '\n' + '-' * 100 + '\n'
    error_str = re.findall('(.*error|.*bad|.*warn|.*fail)',report,re.IGNORECASE)
    if len(error_str) > 0 : 
        report = u'** Found Error or Bad String **\n' + str(error_str) + '\n\n\n' + report
    elif len(report) < 500 : u'** HX Commands were Not Complete Executed , Try Again **\n\n\n'
    else : report = u'** No Problem **\n\n\n' + report
    client.close()
    return report.encode('utf-8')
