# -*- coding: utf-8 -*-
import urllib2
import ssl
import json
import logging
import sys
import time
import os
import re,requests
from logging.handlers import RotatingFileHandler
import datetime
import psutil
import traceback
import pymysql

reload(sys)
sys.setdefaultencoding('utf-8')
#ctx = ssl.create_default_context()
#ctx.check_hostname = False
#ctx.verify_mode = ssl.CERT_NONE

# HX 서버 및 API URI 정보
HXSRV = 'https://112.175.67.137:3000'
HXSRV_TOKEN = '/hx/api/v3/token'
HXSRV_HOSTS_SETS = '/hx/api/v3/host_sets'
HXSRV_HOSTS = '/hx/api/v3/hosts'
HXSRV_ACQS = '/hx/api/v3/acqs/triages'
HXSRV_ALL_ALERTS = '/hx/api/v3/alerts'
HXSRV_CONDITION_BY_ID = '/hx/api/v3/conditions'

# 현재 시간 리턴
def time_ch(limit):
    start_time = time.localtime()
    check_localtime = time.localtime()
    if limit == 'day' :
        time_check = str(check_localtime.tm_year) + '-' + str(check_localtime.tm_mon) + '-' + str(check_localtime.tm_mday)
    else :
        time_check = str(check_localtime.tm_year) + '-' + str(check_localtime.tm_mon) + '-' + str(check_localtime.tm_mday) + '_' + str(check_localtime.tm_hour) + ':' + str(check_localtime.tm_min) + ':' + str(check_localtime.tm_sec)
    return time_check

# HX서버 인증 토큰 수신
def get_token():
    msg = ''
    handler = urllib2.HTTPHandler()
    opener = urllib2.build_opener(handler)
    urllib2.install_opener(opener)
    data = None
    request = urllib2.Request(HXSRV + HXSRV_TOKEN , data=data)
    context = ssl._create_unverified_context()
    request.add_header('Accept', 'application/json')
    request.add_header('Authorization', 'Basic aXN0ZWFtX2FwaTohSXN0ZWFtMA==')
    request.get_method = lambda: 'GET'
    try:
        response = urllib2.urlopen(request, context=context)
    except urllib2.HTTPError as e:
        msg += 'HX_REQ_Error_Token : ' + str(e.read())
        return msg
    except urllib2.URLError as e:
        msg += 'HX_REQ_Error_Token : ' + str(e.read())
        return msg
    else:
        token = response.info().getheader('X-FeApi-Token')
        return token

# API 요청
def request_hx(token,uri,parameter,method,data_info,store='n'):
    handler = urllib2.HTTPHandler()
    opener = urllib2.build_opener(handler)
    urllib2.install_opener(opener)
    data = data_info
    req_url = HXSRV + uri + parameter
    msg = method + ' ' + uri + parameter + ' '
    request = urllib2.Request(req_url , data=data)
    context = ssl._create_unverified_context()
    request.add_header('X-FeApi-Token',token)
    request.add_header('Accept', 'application/json')
    request.add_header('Content-Type', 'application/json')
    request.get_method = lambda: method
    try:
        response = urllib2.urlopen(request, context=context)
    except urllib2.HTTPError as e:
        msg += 'HX_REQ_Error_HTTP : ' + str(e.read())
        return msg
    except urllib2.URLError as e:
        msg += 'HX_REQ_Error_URL_Connect : ' + str(e.reason)
        return msg
    else:
        if method == 'DELETE' :
            #HX_REQ_LOGGER.info(msg)
            return msg
        result = response.read() #unicode(response.read().decode('utf-8')).encode('euc-kr')
        dic_result = json.loads(result) # json > dic
        return dic_result['data']  # 성공 시 dic 반환

def req_host_info_by_id(host_id) :
    host_info_url =  '/hx/api/v3/hosts/%s' %host_id
    response = request_hx(get_token(),host_info_url,'','GET',None)
    return response

def req_host_set_info_by_id(host_set_id) :
    host_set_url = '/hx/api/v3/host_sets/%s' %host_set_id
    response = request_hx(get_token(),host_set_url,'','GET',None)
    return response

#description : token timeout 점검 함수
def maru_restIsSessionValid():
    try:
        current_token = maru_token
        if current_token:
            last_use_delta = (datetime.datetime.utcnow() - datetime.datetime.strptime(current_token['last_use_timestamp'], '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
            grant_time_delta = (datetime.datetime.utcnow() - datetime.datetime.strptime(current_token['grant_timestamp'], '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
            if (last_use_delta < 13 and grant_time_delta < 110) :
                maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
                token = maru_token['token']
            else :
                reset_token()
        else:
            reset_token()
        # print maru_token['token']
    except Exception as err:
        pass #print(traceback.format_exc())

#description : token 허용시간이 지났을 경우 token 재생성
def reset_token():
    try:
        maru_token['token'] = get_token()
        maru_token['grant_timestamp'] = str(datetime.datetime.utcnow())
        maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
        token = maru_token['token']
    except Exception as err:
        pass #print(traceback.format_exc())

maru_token = {}
maru_token['token'] = get_token()
maru_token['grant_timestamp'] = str(datetime.datetime.utcnow())
maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
token = maru_token['token']
#prtracker_url = https://112.175.67.137:3000/hx/api/plugins/process-tracker/v1/events?sort=started_at:-1&filter=[{%22operator%22:%22between%22,%22field%22:%22started_at%22,%22arg%22:[%222020-06-01T15:00:00.000Z%22,%222020-06-02T14:59:59.000Z%22]}]&offset=0&limit=49

# process tracker 초기 전체 데이터 파일로 저장
def save_all_json():
    maru_restIsSessionValid()
    response = request_hx(get_token(),prtracker_url,'','GET',None)
    response = json.dumps(response,indent=2,ensure_ascii=True)
    with open('process_tracker_all_result.json','w') as f :
        f.write(response)

def has_handle(fpath):
    for proc in psutil.process_iter():
        try:
            for item in proc.open_files():
                if fpath == item.path:
                    return True
        except Exception as err:
            #print(err)
            pass
    return False

def make_dataeye_json(ptracker):
    try:
        dataeye = {'data':{}}
        logpath = '/opt/cafemon_test'
        if os.path.isdir(logpath) == False : os.mkdir(logpath)
        logdayf = 'cafemon_test_' + datetime.datetime.now().strftime('%Y%m%d')
        logdayf = os.path.join(logpath,logdayf)
        dataeye['data'] = ptracker
        dataeye['data']['logtype'] = 'process_tracker'
        dataeye['time'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ## first 시 속도문제로 주석처리 필요
        '''
        while has_handle(logdayf) == True :
            time.sleep(5)
        '''
        with open(logdayf,'a') as log :
            log.write( json.dumps(dataeye,ensure_ascii=False) + '\n')
    except Exception as err:
        pass #print(traceback.format_exc())

def get_process_tracker(offset) :
    try :
        global ID_LIST
        get_cpay_process_tracker()
        ## 처음 수집 시 offset 값 1만씩 늘려서 이전 데이터 받아오기 (limit max 1만)
        prtracker_url = '/hx/api/plugins/process-tracker/v1/events?sort=id:-1&filter=&offset=%d&limit=10000'%offset
        id , new_id , save_id , cnt = 0 , 0 , 0 , 0
        if sys.argv[1] == 'cron' :
            if os.path.isfile('ID.txt') == True : id = int(open('ID.txt','r').read())
        maru_restIsSessionValid()
        response = request_hx(get_token(),prtracker_url,'','GET',None)
        for idx , value in enumerate(response):
            value_str = json.dumps(value,indent=2,ensure_ascii=True)
            value = json.loads(value_str)
            if idx == 0 : save_id = value['id']
            new_id = value['id']
            if sys.argv[1] == 'cron' and new_id in ID_LIST : continue
            if new_id > id :
                if sys.argv[1] == 'cron' : ID_LIST.append(new_id)
                make_dataeye_json(value)
                cnt += 1
                insert_pt(value)
        #print('new event %d'%cnt)
        if sys.argv[1] == 'first' and offset != 0 : return
        if sys.argv[1] == 'first' and cnt == 0 : exit()
        with open('ID.txt','w') as f :
            f.write(str(save_id))
    except Exception as err:
        pass #print(traceback.format_exc())

def first_time():
    cnt = 0
    prtracker_url = 'https://112.175.67.137:3000/hx/api/plugins/process-tracker/v1/events?sort=id:-1&filter=&offset=0&limit=10'
    maru_restIsSessionValid()
    response = (get_token(),prtracker_url,'','GET',None)
    header = {'Accept':'application/json','Authorization':'Basic aXN0ZWFtX2FwaTohSXN0ZWFtMA=='}
    response = requests.get(prtracker_url,headers = header,verify=False)
    response = response.json()
    total = response['total']
    #print(total)
    maxnum = int(total/10000) + 1
    remainder = total%10000
    for i in range(0,maxnum) :
        get_process_tracker(cnt * 10000)
        cnt += 1
        time.sleep(40)

def get_alert():
    ## hx rule , malware guard , exploit guard 등의 이벤트가 탐지된 시점의 process tracker log
    prtracker_url = 'https://112.175.67.137:3000/hx/api/services/topic/HX_ALERTS'
    maru_restIsSessionValid()
    response = (get_token(),prtracker_url,'','GET',None)
    header = {'Accept':'application/json','Authorization':'Basic aXN0ZWFtX2FwaTohSXN0ZWFtMA=='}
    response = requests.get(prtracker_url,headers = header,verify=False)
    response = response.json()
    #print(json.dumps(response,indent=2))

# cpay syslog cams 채널에 수신된 cpay process tracker 수집
def get_cpay_process_tracker():
    try:
        #https://pypi.org/project/mattermost/
        token = 'Bearer ' + 'hkdyyccuu7ru8jtu1d5yj1jqie'
        me = 'https://mattermost.hanpda.com/api/v4/users/me'
        headers = {'Authorization':token}
        res = requests.get(me, headers=headers)
        cpaysym = 'ckg56smxy78s5enacq9xghg61y'
        #lasttime = 1615436440982
        timeflag = 'cpay_process_tracker_lasttime.txt'
        logpath = '/opt/cafemon_test'
        if os.path.isdir(logpath) == False : os.mkdir(logpath)
        logdayf = 'cafemon_test_' + datetime.datetime.now().strftime('%Y%m%d')
        logdayf = os.path.join(logpath,logdayf)
        if os.path.isfile(timeflag) == True :
            with open(timeflag,'r') as f :
                lasttime = int(f.read())
        else : lasttime = 0
        getpost = 'https://mattermost.hanpda.com/api/v4/channels/%s/posts?since=%s'%(cpaysym,str(lasttime))
        res = requests.get(getpost, headers=headers)
        res = res.json()
        if 'order' not in res : return
        order = res['order']
        order.reverse()
        for post_id in order :
            create_at = res['posts'][post_id]['create_at']
            if create_at <= lasttime : continue
            msg = res['posts'][post_id]['message']
            lasttime = create_at
            if ' #cpay_PT' not in msg : continue
            with open(logdayf,'a') as f :
                f.write(msg.splitlines()[1] + '\n')
            insert_pt(json.loads(msg.splitlines()[1])['data'])        
        with open(timeflag,'w') as f :
            f.write(str(lasttime))
    except Exception as err :
        pass #print(traceback.format_exc())


def create_pt_table() :
    ##create database process_tracker;
    con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='process_tracker', charset='utf8mb4',autocommit=True)
    cursor = con.cursor()
    create_process_tracker_table = '''
    create table if not exists process_tracker( id bigint(20) primary key , pid varchar(100) , file_attributes  varchar(100) , signature_verified varchar(100) , file_size int(11) , owner varchar(200) , started_at datetime default "0000-00-00 00:00:00", file_created_at datetime default "0000-00-00 00:00:00", parent_pid varchar(100) , uuid varchar(200) , enrichment_status varchar(100) , is_signed varchar(100) , parent_path text , last_status_change_time datetime default "0000-00-00 00:00:00", type varchar(100) , alerted_at datetime default "0000-00-00 00:00:00", enrichment_requested_at datetime default "0000-00-00 00:00:00", process_path text , process_file_exists varchar(100) , file_last_accessed_at datetime default "0000-00-00 00:00:00", args text , updated_at datetime default "0000-00-00 00:00:00", event_at datetime default "0000-00-00 00:00:00", users varchar(200) , groups varchar(200) , md5 varchar(100) , is_prelinked varchar(100) , created_at datetime , file_last_modified_at datetime default "0000-00-00 00:00:00", file_cert_ExpirationTime datetime default "0000-00-00 00:00:00", file_cert_subject text , file_cert_serialnumber text , file_cert_algorithm varchar(100) , file_cert_issuer text , agent_id varchar(100) , hxtype varchar(100) ) DEFAULT CHARSET=utf8mb4
    '''
    cursor.execute(create_process_tracker_table)
    con.commit()
    con.close()


def ch_timestamp(timestamp):
    try :
        timestamp = timestamp.replace('T',' ').replace('Z','').split('.')[0]
    except : timestamp = "0000-00-00 00:00:00"
    return timestamp

def insert_pt(pt_dict):
    try :
        id = pt_dict['id']
        pid = pt_dict['pid']
        file_attributes = pt_dict['file_attributes']
        signature_verified = str(pt_dict['signature_verified'])
        file_size = pt_dict['file_size']
        owner = pt_dict['owner']
        started_at = ch_timestamp(pt_dict['started_at'])
        file_created_at = ch_timestamp(pt_dict['file_created_at'])
        parent_pid = pt_dict['parent_pid']
        #uuid = pt_dict['uuid']
        enrichment_status = pt_dict['enrichment_status']
        is_signed = str(pt_dict['is_signed'])
        parent_path = pt_dict['parent_path']
        #last_status_change_time = ch_timestamp(pt_dict['last_status_change_time'])
        type = pt_dict['type']
        #alerted_at = ch_timestamp(pt_dict['alerted_at'])
        #enrichment_requested_at = ch_timestamp(pt_dict['enrichment_requested_at'])
        process_path = pt_dict['process_path']
        process_file_exists = str(pt_dict['process_file_exists'])
        file_last_accessed_at = ch_timestamp(pt_dict['file_last_accessed_at'])
        args = pt_dict['args']
        updated_at = ch_timestamp(pt_dict['updated_at'])
        event_at = ch_timestamp(pt_dict['event_at'])
        users = pt_dict['user']
        #group = pt_dict['group'] ## 컬럼명 groups
        md5 = pt_dict['md5']
        #is_prelinked = pt_dict['is_prelinked']
        created_at = ch_timestamp(pt_dict['created_at'])
        file_last_modified_at = ch_timestamp(pt_dict['file_last_modified_at'])
        if is_signed == 'True':
            file_cert_expirationtime = ch_timestamp(pt_dict['process_file_cert']['ExpirationTime'])
            file_cert_subject = pt_dict['process_file_cert']['Subject']
            file_cert_serialnumber = pt_dict['process_file_cert']['SerialNumber']
            file_cert_algorithm = pt_dict['process_file_cert']['Algorithm']
            file_cert_issuer = pt_dict['process_file_cert']['Issuer']
        else :
            file_cert_expirationtime = '0000-00-00 00:00:00'
            file_cert_subject = 'NULL'
            file_cert_serialnumber = 'NULL'
            file_cert_algorithm = 'NULL'
            file_cert_issuer = 'NULL'
        agent_id = pt_dict['agent_id']
        if 'HXtype' not in pt_dict : hxtype = 'internet_hx'
        else :  hxtype = pt_dict['HXtype']

        con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='process_tracker', charset='utf8mb4',autocommit=True)
        cursor = con.cursor()
        ## pymysql auto escape format
        insert = 'insert into process_tracker (id,pid,file_attributes,signature_verified,file_size,owner,started_at,file_created_at,parent_pid,enrichment_status,is_signed,parent_path,type,process_path,process_file_exists,file_last_accessed_at,args,updated_at,event_at,users,md5,created_at,file_last_modified_at,file_cert_expirationtime,file_cert_subject,file_cert_serialnumber,file_cert_algorithm,file_cert_issuer,agent_id,hxtype) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        cursor.execute(insert,(id,pid,file_attributes,signature_verified,file_size,owner,started_at,file_created_at,parent_pid,enrichment_status,is_signed,parent_path,type,process_path,process_file_exists,file_last_accessed_at,args,updated_at,event_at,users,md5,created_at,file_last_modified_at,file_cert_expirationtime,file_cert_subject,file_cert_serialnumber,file_cert_algorithm,file_cert_issuer,agent_id,hxtype))
        con.commit()
        con.close()
    except : pass #print(traceback.format_exc())

os.chdir('/home/apps/hxtool/HXTool-3.0/process_tracker')
ID_LIST = []
print('usage : process_tracker.py [ first | cron ]')
if sys.argv[1] == 'first' : first_time()
elif sys.argv[1] == 'cron' :
    while True :
        get_process_tracker(0)
        time.sleep(60)
elif sys.argv[1] == 'alert' : get_alert()

## cron 등록X
## */15 * * * * /usr/bin/python /home/apps/hxtool/HXTool-3.0/process_tracker/process_tracker.py cron

