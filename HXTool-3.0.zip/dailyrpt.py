import security_daily_report
security_daily_report.report('portable')
