# -*- coding: utf-8 -*-
import sqlite3
import os,sys



sql = 'delete from reqtriage where event like "%ezadmin%"' #event like "%bulktest%"'
 # like "%Attempt_WMI_Persisence_use_mof_wmic%"'
#sql = 'update reqtriage set "comment" = \'<font color="blue">[ NoProblem ]</font><br>IOC Test\' where triage_id = "2658"' 
#sql = 'update reqtriage set event = \'사용자 수동 수집<br>\' where event="사용자 수동 수집" and req_type="passive"'
con = sqlite3.connect('passive_triage.db')
cursor = con.cursor()
cursor.execute(sql)
rows = cursor.fetchall()
for row in rows:
    print str(row[0])
con.commit()
con.close()

