# -*- coding: utf-8 -*-
import matplotlib
matplotlib.use('Agg')
import pandas as pd
from sqlalchemy import create_engine
import pymysql
import pymysql.cursors
import warnings
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import matplotlib.font_manager as fm
import os,time,sys
from wordcloud import WordCloud
import datetime
from plotly import offline
import plotly.express as px
from plotly import graph_objs as go

reload(sys)
sys.setdefaultencoding('utf-8')
def sqltodataframe(sql):
    conn = pymysql.connect(host='localhost',user='security',password='security',db='security_event',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor)
    cursor = conn.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()
    conn.close()
    data = pd.DataFrame(result)
    return data

def getwordcloud(data,size='small'):
    fname =  '/usr/lib64/python2.7/site-packages/matplotlib/mpl-data/fonts/ttf/NanumGothic.ttf'
    STOPWORDS = []
    if size == 'large' :
        wordcloud = WordCloud(collocations=False,font_path=fname,max_font_size=500,width = 4000,height = 1500,background_color = 'black',stopwords = STOPWORDS).generate(data)
        png = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/event_wordcloud_large.png'
    else :
        wordcloud = WordCloud(collocations=False,font_path=fname,max_font_size=300,width = 4000,height = 500,background_color = 'black',stopwords = STOPWORDS).generate(data)
        png = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/event_wordcloud.png'
    plt.figure(figsize = (30,20))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.tight_layout(pad=0)
    plt.axis('off')
    #plt.savefig('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/event_wordcloud.png', bbox_inches='tight',pad_inches=0)
    plt.imsave(png,wordcloud)

def geteventname_for_wordcloud(event):
    evtn = event.split('<br>')[0].split(' : ')[-1].replace(' ','_')
    return evtn

sql_weekly = '''select * from reqtriage where request_time BETWEEN DATE_ADD(NOW() ,INTERVAL -1 WEEK ) AND NOW()
and event not regexp ("(heur|remote access|test_event|reputation|자동 요청|수동 수집|generic load point)")
and event not regexp("Symantec NTP :.*(web attack|malicious site|torrent|teamviewer|Port Scan|Browser Extension|pua|malicious domain|adware)")
and not (event regexp ("Symantec NTP :.*") and computer_name = "jboh_test")
and computer_name not like "%cswebmail%"
and not (event regexp ("symantec.+(trojan|php|asp)") and (computer_name not regexp("(ww|ws|sql|ssd).*\-[0-9]{3}$") or computer_name not regexp("(hanpda|cafe24)\.com")))
'''
sql_monthly = '''select * from reqtriage where request_time BETWEEN DATE_ADD(NOW() ,INTERVAL -1 MONTH ) AND NOW()
and event not regexp ("(heur|remote access|test_event|reputation|자동 요청|수동 수집|generic load point)")
and event not regexp("Symantec NTP :.*(web attack|malicious site|torrent|teamviewer|Port Scan|Browser Extension|pua|malicious domain|adware)")
and not (event regexp ("Symantec NTP :.*") and computer_name = "jboh_test")
and computer_name not like "%cswebmail%"
and not (event regexp ("symantec.+(trojan|php|asp)") and (computer_name not regexp("(ww|ws|sql|ssd).*\-[0-9]{3}$") or computer_name not regexp("(hanpda|cafe24)\.com")))
'''
#sql = 'select * from reqtriage where request_time BETWEEN DATE_ADD(NOW(),INTERVAL -1 WEEK ) AND NOW() '

def getdata(sql):
    data = sqltodataframe(sql)
    wordtemp = {}
    wordtemp['eventname'] = data['event'].apply(geteventname_for_wordcloud)
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace('.','_'))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace('/','_'))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace('!','_'))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace(':',''))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace('(',''))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace(')',''))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace('\n',''))
    wordtemp['eventname'] = wordtemp['eventname'].apply(lambda x : x.replace('-','_'))
    return wordtemp['eventname']

def groupby_threat_count(title,xlabel,ylabel,data,column) :
    symantec = data[data['device']=='symantec'][[column,'device']]
    symantec = symantec.groupby(symantec[column]).count()
    fortinet = data[data['device']=='fortinet'][[column,'device']]
    fortinet = fortinet.groupby(fortinet[column]).count()
    fireeye = data[data['device']=='FireEyeHX'][[column,'device']]
    fireeye = fireeye.groupby(fireeye[column]).count()
    cpay = data[data['device']=='CPAY'][[column,'device']]
    cpay = cpay.groupby(cpay[column]).count()
    #sentinel = data[data['device']=='SENTINELONE'][[column,'device']]
    #sentinel = sentinel.groupby(sentinel[column]).count()    
    plt.rcParams["figure.figsize"] = (9.1,2.3)
    plt.rcParams['lines.linewidth'] = 2
    plt.rcParams['lines.color'] = 'b'
    plt.rcParams['font.size'] = 8
    plt.rcParams['legend.fontsize'] = 'large'
    plt.rcParams['figure.titlesize'] = 'large'
    plt.rcParams['hatch.color'] = 'b'
    plt.rcParams['patch.force_edgecolor'] = True
    plt.rcParams['patch.facecolor'] = 'b'
    plt.rcParams['figure.facecolor'] = 'w'

    plt.plot(symantec,label='symantec',color='blue')
    plt.plot(fortinet,label='fortinet',color='green')
    plt.plot(fireeye,label='fireeye',color='red')
    plt.plot(cpay,label='cpay',color='black')
    #plt.plot(sentinel,label='sentinel',color='yellow')    
    plt.legend()

    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.savefig('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/weeklyevt.png',facecolor='grey')

def make_graph():
    sql = 'select * from reqtriage where request_time BETWEEN DATE_ADD(NOW() ,INTERVAL -5 Day ) AND NOW() and event not like "%Remote Access%" and event not like "%Symantec NTP%" and event not like "%W97M.Down%" and computer_name not like "%cswebmail%" order by request_time'
    data = sqltodataframe(sql)
    data['ttt'] = data['request_time'].str.split(' ').str[0]
    data['Events'] = data['ttt'].str.split('T').str[0]
    groupby_threat_count(u'Weekly Events (NO NTP) UTC0',u'Date','Events',data,'Events')

def make_plotly_graph():
    sql = 'select * from reqtriage where request_time BETWEEN DATE_ADD(NOW() ,INTERVAL -5 Day ) AND NOW() and event not like "%Remote Access%" and event not like "%Symantec NTP%" and event not like "%W97M.Down%" and computer_name not like "%cswebmail%" order by request_time'
    data = sqltodataframe(sql)
    data['Events'] = data['request_time'].str.split(' ').str[0]
    layout = go.Layout(title='Weekly Events (NO NTP)',xaxis=go.layout.XAxis(title=''),yaxis=go.layout.YAxis(title='Events'),width=900,height=300,paper_bgcolor='rgba(190,190,190,1)')
    #fig = go.Figure(layout=layout,layout_yaxis_range=[0,50])
    fig = go.Figure(layout=layout)

    for name, group in data.groupby('device'):
        trace = go.Histogram()
        #trace = go.Scatter()
        trace.name = name
        trace.x = group['Events']
        fig.add_trace(trace)
    fig.show()
    offline.plot(fig, filename='/home/apps/hxtool/hx_es_daemon/es_query_result/graph/events_via_device.html',auto_open=False)

    sql = 'select * from reqtriage where request_time BETWEEN DATE_ADD(NOW() ,INTERVAL -1 Week ) AND NOW() and device like "Symantec%" and event not like "%W97M.Down%" and computer_name not like "%cswebmail%"'
    data = sqltodataframe(sql)
    data['Events'] = data['request_time'].str.split(' ').str[0]
    data['type'] = data['rule'].str.split(':').str[0]

    layout = go.Layout(title='Weekly Events (Symantec)',xaxis=go.layout.XAxis(title=''),yaxis=go.layout.YAxis(title='Events'),width=1200,height=400)
    #fig = go.Figure(layout=layout,layout_yaxis_range=[0,300])
    fig = go.Figure(layout=layout)

    for name, group in data.groupby('type'):
        trace = go.Histogram()
        #trace = go.Scatter()
        trace.name = name
        trace.x = group['Events']
        fig.add_trace(trace)
    fig.show()
    offline.plot(fig, filename='/home/apps/hxtool/hx_es_daemon/es_query_result/graph/events_via_symantec.html',auto_open=False)

make_graph()
make_plotly_graph()
getwordcloud(' '.join(getdata(sql_weekly )))
getwordcloud(' '.join(getdata(sql_monthly)),'large')

