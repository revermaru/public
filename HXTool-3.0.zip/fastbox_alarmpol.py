import json
import time
import requests
import string
import random
import hashlib
import binascii
import dicttoxml
import xmltodict
import collections
import base64
from urllib import quote
from re import match
from Crypto.Cipher import AES
import mcrypt

# must modify variable groupware_id's value : ex) gsimplexi (bonsa) , fastbox (incheon)
# must modify jisa groupware api url
GROUPWAREURL = "http://gw.fastbox.cafe24.com"

class HostingAPIClient:
    def __init__(self, url, params={}, reseller_id='hosting'):
        self.url = url
        self.params = self._gen_params(params, reseller_id)
        self._mcrypt = mcrypt.MCRYPT('tripledes', 'cfb')
        self._key = self._gen_key('$_simplex_$')
        self._iv = self._gen_iv()
        self.result = None

    def _gen_key(self, key):
        for x in range(0, (24 - len(key))):
            key = key + "\0"
        return key

    def _gen_iv(self):
        iv_size = self._mcrypt.get_iv_size()
        return ''.join(
            [
                random.choice(string.ascii_letters + string.digits)
                for x in range(iv_size)
            ]
        )

    def _encrypt(self, text):
        self._mcrypt.init(self._key, self._iv)
        return {
            "hexlified_iv": binascii.hexlify(self._iv),
            "text": binascii.hexlify(self._mcrypt.encrypt(text))
        }

    def _decrypt(self, text, iv):
        iv = binascii.unhexlify(iv)
        self._mcrypt.init(self._key, iv)
        return self._mcrypt.decrypt(binascii.unhexlify(text))

    def _gen_params(self, params, reseller_id='hosting'):
        data = {u'time': str(int(time.time())), u'resellerId': reseller_id}
        for param in params.keys():
            data[param] = params[param]
        return dicttoxml.dicttoxml(data, custom_root="API")

    def request(self):
        encrypted = self._encrypt(self.params)
        data = {}
        data['iv'] = encrypted['hexlified_iv']
        data['xml'] = encrypted['text']
        result = requests.post(self.url, data=data)

        if result.text.strip():
            self.result = xmltodict.parse(result.text)
            return self.result


class GroupwareLoginAPIClient(HostingAPIClient):
    def __init__(self, user, passwd):
        groupware_id = "fastbox"
        passwd = hashlib.md5(passwd).hexdigest()
        groupware_key = self._gen_groupware_key("%s_%s" % (groupware_id, user))
        groupware_iv = "_cafe24_solution"
        AES.key_size = 128
        crypt_object = AES.new(
            key=groupware_key,
            mode=AES.MODE_CBC,
            IV=groupware_iv
        )
        passwd = binascii.hexlify(crypt_object.encrypt(passwd))
        url = "%s/groupware/api/GroupwareLogin.php" % GROUPWAREURL
        params = {'userId': groupware_id, 'empId': user, 'passwd': passwd}
        HostingAPIClient.__init__(self, url, params, reseller_id='hosting')

    def _gen_groupware_key(self, key):
        if len(key) < 16:
            key_size = 16
        elif len(key) < 24:
            key_size = 24
        else:
            key_size = 32
        for x in range(0, (key_size - len(key))):
            key = key + "\0"
        return key[:key_size]


class GroupwareAlarmAPIClient(GroupwareLoginAPIClient):
    def __init__(
            self,
            from_id,
            to_id,
            msg,
            deptnm=None,
            alarm_read=True,
            emergency=False,
            data_sync=True
    ):
        groupware_id = "fastbox"
        msg = self._gen_message(msg)
        groupware_key = self._gen_groupware_key(groupware_id)
        groupware_iv = "_cafe24_solution"
        AES.key_size = 128
        crypt_object = AES.new(
            key=groupware_key,
            mode=AES.MODE_CBC,
            IV=groupware_iv
        )
        msg = binascii.hexlify(crypt_object.encrypt(msg))
        if to_id == "dept":
            if deptnm:
                pass
                # deptnm = quote(deptnm)
            else:
                raise RuntimeError("deptnm required")
        if alarm_read:
            alarm_read = 1
        if emergency:
            emergency = 1
        if data_sync:
            data_sync = "y"

        url = "%s/groupware/api/GroupwareAlarm.php" % GROUPWAREURL
        params = dict()
        params['userId'] = groupware_id
        params['from_id'] = from_id
        params['to_id'] = to_id
        params['msg'] = msg
        params['deptnm'] = deptnm
        params['alarmRead'] = alarm_read
        params['emergency'] = emergency
        params['data_sync'] = data_sync

        HostingAPIClient.__init__(self, url, params, reseller_id='hosting')

    def _gen_message(self, msg):
        msg_size = len(msg)
        multiple_size = 16
        null_size = ((msg_size / multiple_size) + 1) * multiple_size
        null_size = null_size - msg_size
        if null_size == multiple_size:
            null_size = 0
        return "%s%s" % (msg, null_size * "\0")


class GroupwareSelEmpListAPIClient(HostingAPIClient):
    def __init__(
            self,
            user=None,
            name=None,
            company_name=None,
            all_dept=False,
            all=False,
            is_test=False
    ):
        groupware_id = "fastbox"
        url = "%s/groupware/api/GroupwareSelEmpList.php" % GROUPWAREURL
        params = dict()
        params['userId'] = groupware_id
        params['empId'] = user
        params['name'] = name
        params['company_name'] = company_name
        params['all_dept'] = all_dept
        params['all'] = all
        params['isTest'] = is_test
        HostingAPIClient.__init__(self, url, params, reseller_id='hosting')
        self.result = None

    def request(self):
        encrypted = self._encrypt(self.params)
        data = {}
        data['iv'] = encrypted['hexlified_iv']
        data['xml'] = encrypted['text']
        result = requests.post(self.url, data=data)

        if result.text.strip():
            self.result = xmltodict.parse(
                unicode(result.text).encode('latin1')
            )
            return self.result

    def get_mobiles(self):
        if self.result:
            try:
                data = self.result['API']['data']['record']['record']
            except Exception as e:
                return []
            if type(data) == dict or type(data) == collections.OrderedDict:
                return [
                    "%s-%s-%s" % (
                        data['mobile_01'],
                        data['mobile_02'],
                        data['mobile_03']
                    )
                ]
            elif type(data) == list:
                mobiles = []
                for info in data:
                    mobile = "%s-%s-%s" % (
                        info['mobile_01'],
                        info['mobile_02'],
                        info['mobile_03']
                    )
                    if mobile not in mobiles:
                        mobiles.append(mobile)
                return mobiles

    def get_emails(self):
        if self.result:
            try:
                data = self.result['API']['data']['record']['record']
            except Exception as e:
                return []
            if type(data) == dict or type(data) == collections.OrderedDict:
                return ["%s@simplexi.com" % (data['id'])]
            elif type(data) == list:
                emails = []
                for info in data:
                    email = "%s@simplexi.com" % (info['id'])
                    if email not in emails:
                        emails.append(email)
                return emails

    def get_ids(self):
        if self.result:
            try:
                data = self.result['API']['data']['record']['record']
            except Exception as e:
                return []
            if type(data) == dict or type(data) == collections.OrderedDict:
                return [data['id']]
            elif type(data) == list:
                ids = []
                for info in data:
                    id = info['id']
                    if id not in ids:
                        ids.append(id)
                return ids


class AlarmSMSAPIClient:
    def __init__(self, reseller_id, user_id, secure_key):
        self.url = "http://alarm.simplexi.com/api/cafe24Sms/sms.php"
        self.params = dict()
        self.params['resellerId'] = reseller_id
        self.params['userId'] = user_id
        self.params['secureKey'] = secure_key
        self.params['mode'] = ""
        self.params['returnType'] = "json"
        self.params['receivePhone'] = ""
        self.params['sendPhone'] = ""
        self.params['msg'] = ""
        self.params['startDate'] = ""
        self.params['endDate'] = ""

    def set_sms(self, receive_phone, msg, send_phone="1588-3284"):
        params = self.params
        params['mode'] = "send"
        if not match("(\d{1,4}-\d{1,4}(-\d{0,4})?,?)+", receive_phone):
            raise RuntimeError(
                "Invalid receive phone number '%s'" % (receive_phone)
            )
        params['receivePhone'] = receive_phone
        if not match("\d{1,4}-\d{1,4}(-\d{0,4})?", send_phone):
            raise RuntimeError("Invalid send phone number '%s'" % (send_phone))
        params['sendPhone'] = "1588-3284"
        params['msg'] = msg.replace('\'', '\\\'')
        result = self._request(params)
        return json.loads(result.text)

    def _request(self, data):
        return requests.post(self.url, data=data)

    def get_sms(self, start_date, end_date):
        params = self.params
        params['mode'] = "search"
        if not match("\d{8}", start_date):
            raise RuntimeError("Invalid start date '%s'" % (start_date))
        params['startDate'] = start_date
        if not match("\d{8}", end_date):
            raise RuntimeError("Invalid end date '%s'" % (end_date))
        params['endDate'] = end_date
        result = self._request(params)
        return json.loads(result.text)


class ApiRequest():
    def __init__(self, url, params={}, reseller_id='echat'):
        self.url = url
        self.params = self._gen_params(params, reseller_id)
        self._mcrypt = mcrypt.MCRYPT('tripledes', 'cfb')
        self._key = self._gen_key('$_sms_hosting_$')
        self._iv = self._gen_iv()

    def request(self):
        encrypted = self._encrypt(self.params)

        data = {}
        data['iv'] = encrypted['hexlified_iv']
        data['xml'] = encrypted['text']

        result = requests.post(self.url, data=data)

        if result.text.strip():
            result = xmltodict.parse(result.text)
            print result
            return result

    def _encrypt(self, text):
        self._mcrypt.init(self._key, self._iv)
        return {
            "hexlified_iv": binascii.hexlify(self._iv),
            "text": binascii.hexlify(self._mcrypt.encrypt(text))
        }

    def _gen_params(self, params, reseller_id='echat'):
        data = {u'time': str(int(time.time())), u'resellerId': reseller_id}
        for param in params.keys():
            data[param] = params[param]
        return dicttoxml.dicttoxml(data, custom_root="API")

    def _gen_key(self, key):
        for x in range(0, (24 - len(key))):
            key = key + "\0"
        return key

    def _gen_iv(self):
        iv_size = self._mcrypt.get_iv_size()
        return ''.join(
            [
                random.choice(string.ascii_letters + string.digits)
                for x in range(iv_size)
            ]
        )


class sendSms():
    def __init__(self, params={}):
        # params['receivePhone'] = sendPhone
        self.params = params
        self.params['userId'] = 'echat'
        self.params['passwd'] = 'aksaudadmin'
        self.url = 'http://smsapi.cafe24.com/api/sms/1.0/sms_send.php'

    def sendSms(self, receive_phone, msg='', send_phone='1588-3284'):
        encoded_msg = base64.encodestring(msg)

        self.params['receivePhone'] = receive_phone
        self.params['msg'] = encoded_msg
        self.params['sendPhone'] = send_phone

        smsapi = ApiRequest(self.url, self.params)
        smsapi.request()


