#!/usr/bin/env python
# -*- coding: utf-8 -*-

import matplotlib
matplotlib.use('Agg')

import pandas as pd
from sqlalchemy import create_engine
import pymysql
import pymysql.cursors
import warnings
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import matplotlib.font_manager as fm
import os,sys
#[f.fname for f in matplotlib.font_manager.fontManager.ttflist]
from matplotlib import font_manager, rc
font_fname = '/usr/lib64/python2.7/site-packages/matplotlib/mpl-data/fonts/ttf/NanumGothic.ttf'
font_name = font_manager.FontProperties(fname=font_fname).get_name()
rc('font', family=font_name)
from matplotlib import font_manager, rc

os.system('find /home/apps/hxtool/hx_es_daemon/es_query_result/graph -name "*.png" -exec mv -f {} /home/_trash/deleted \\;')
os.system('find /home/apps/hxtool/hx_es_daemon/es_query_result/graph -name "*.html" -exec mv -f {} /home/_trash/deleted \\;')


# 노트북 안에 그래프를 그리기 위해
#get_ipython().run_line_magic('matplotlib', 'inline')

# 그래프에서 격자로 숫자 범위가 눈에 잘 띄도록 ggplot 스타일을 사용
mpl.style.use('ggplot')
#plt.style.use('classic')
mpl.rcParams["figure.figsize"] = (30,10)
mpl.rcParams['lines.linewidth'] = 4
mpl.rcParams['lines.color'] = 'b'
mpl.rcParams['font.size'] = 12
mpl.rcParams['legend.fontsize'] = 'large'
mpl.rcParams['figure.titlesize'] = 'large'
mpl.rcParams['hatch.color'] = 'b'
mpl.rcParams['patch.force_edgecolor'] = True
mpl.rcParams['patch.facecolor'] = 'b'

# 그래프에서 마이너스 폰트 깨지는 문제에 대한 대처
mpl.rcParams['axes.unicode_minus'] = False
warnings.filterwarnings(action='ignore')

figpath = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph'
# 사업장 아이피로 나누기
company = {
    'Philippines':['192.168.0.','192.168.1.'],
    'Fastbox':['192.168.22.','172.17.106.','172.17.107.','192.168.4.','192.168.55.'],
    'Yanji':['10.7.1.','10.5.1.','10.8.1.'],
    'Pusan':['172.16.106.','172.168.107.'],
    'JC':['172.17.108.'],
    'Tokyo':['172.168.1.','172.16.1.'],
    'Hukuoka':['172.168.0.'],
    'Hangzu':['172.17.2.'],
    'Taiwna':['172.17.1.'],
    'PIMZ':['172.16.109.'],
    'Seoul':[]
          }

# table 통째로 가져오기
'''
engine = create_engine('mysql://maru:maru@localhost/security_event', convert_unicode=True)
conn = engine.connect()
data = pd.read_sql_table('reqtriage', conn)
print(data.head())
'''

def sqltodataframe(sql):
    conn = pymysql.connect(host='localhost',user='security',password='security',db='security_event',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor)
    cursor = conn.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()
    conn.close()
    data = pd.DataFrame(result)
    return data
    
def groupby_threat_count(title,xlabel,ylabel,data,column,ish=False) :
    tmp = data #data[data['device'] =='FireEyeHX' ]
    fireeye_threat_groupby = tmp[tmp['isthreat']==1][[column,'isthreat']]
    #fireeye_threat_groupby = tmp[[column,'isthreat']]
    fireeye_threat_groupby = fireeye_threat_groupby.groupby(fireeye_threat_groupby[column]).count()
    if ish == True : fireeye_threat_groupby.plot(kind='bar')
    else : fireeye_threat_groupby.plot.barh()
    #fireeye_threat_groupby.plot.box()
    #fireeye_threat_groupby.cumsum()
    #print('Threat groupby %s'%column)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    #plt.show()
    plt.savefig(os.path.join(figpath,(title + '.png')))

def isthreat(comment):
    if '[ threat ]' in comment.lower():
        return 1
    elif '[ noproblem ]' in comment.lower():
        return -1
    else : return 0
    
# eventname 컬럼추가
def geteventname(event):
    evtn = event.split('<br>')[0]
    return evtn    

# pc , server 컬럼추가 , pc , server 나누기
import re
def isserver(computer_name):
    if bool(re.search('.*-\d{3}',computer_name)) == True : return 'server'
    else : return 'pc'

# 아이피로 사업장 찾기
def getcompany(ipaddress):
    for com in company :
        getcom = 'Seoul'
        for i in company[com]:
            if i not in ipaddress : continue
            else : return com
    return getcom

# server 호스트종류별 나누기
def splitserverhost(computer_name):
    return computer_name.split('-')[0]

def makesns_scatterplot(data,x,y,groupby_col,title,sizex,sizey):
    plt.figure()
    mpl.rcParams["figure.figsize"] = (sizex,sizey)
    ttt =  data.groupby(data[groupby_col]).count()
    ttt.reset_index(inplace=True)
    sns.scatterplot(x=x,y=y,data=data,hue='isserver',s=300).set_title(title)
    plt.xticks(rotation=30, ha='right')
    plt.savefig(os.path.join(figpath,(title + '.png')))


if __name__ == '__main__' :
    # query 결과만 가져오기
    when = sys.argv[1] # '2019-12'
    sql = 'select * from reqtriage where request_time like "%{0}%" and comment like "%[ threat%"'.format(when)
    data = sqltodataframe(sql)
    yeardata = sqltodataframe('select * from reqtriage where (request_time like "%2019%" or request_time like "%2020%" or request_time like "%2021%") and comment like "%[ threat%"')

    # isthreat 컬럼추가 (연 데이타)
    tmp = yeardata['event_time'].str.split(' ').str[0].str.split('-')
    yeardata['year-mon']  = tmp.str[0] + '-' + tmp.str[1]
    yeardata['isthreat'] = yeardata['comment'].apply(isthreat)

    # 년-월 , 년-월-일 컬럼추가 , isthreat 컬럼 추가 (월 데이타)
    data['year-mon-day'] = data['event_time'].str.split(' ').str[0]
    tmp = data['year-mon-day'].str.split('-')
    data['year-mon'] = tmp.str[0] + '-' + tmp.str[1]
    data['isthreat'] = data['comment'].apply(isthreat)

    data['eventname'] = data['event'].apply(geteventname)
    yeardata['eventname'] = yeardata['event'].apply(geteventname)
    #data['eventname'] = data['eventname'].apply(lambda x : x.replace(' ','_'))
    #yeardata['eventname'] = yeardata['eventname'].apply(lambda x : x.replace(' ','_'))

    data['isserver'] = data['computer_name'].apply(isserver)
    #server = data [ data['computer_name'].str.match('.*-\d{3}') == True]
    #pc = data [ data['computer_name'].str.match('.*-\d{3}') == False]

    pc = data [ data['computer_name'].str.match('.*-\d{3}') == False]
    server = data [ data['computer_name'].str.match('.*-\d{3}') == True ]

    pc['company'] = pc['ipaddress'].apply(getcompany)

    server['hosttype'] = server['computer_name'].apply(splitserverhost)

    groupby_threat_count(u'1.월별 위협수',u'위협','',yeardata,'year-mon')
    #x = yeardata[yeardata['isthreat']== 1]['isthreat'].groupby(yeardata['year-mon']).count()
    #x.plot()
    #col = data.columns

    # 월간 이벤트별 위협 수
    groupby_threat_count(u'%s 이벤트별 위협 수'%when,u'위협','',data,'eventname')

    # 날짜별 위협 수
    groupby_threat_count(u'%s 일간 위협수'%when,u'위협','',data,'year-mon-day')

    #x = threats['isthreat'].groupby(threats['year-mon-day']).count()
    #x.plot()
    #data[ data['computer_name'].str.match('.*-\d{3}') == True]

    # pc vs server
    groupby_threat_count(u'%s PC,Server별 위협수'%when,u'위협','',data,'isserver')


    pc = data [ data['computer_name'].str.match('.*-\d{3}') == False]
    server = data [ data['computer_name'].str.match('.*-\d{3}') == True ]

    # 월간 PC 사용자 별 위협 수
    groupby_threat_count(u'%s PC Hostname별 위협 수'%when,u'위협',u'사용자',pc,'computer_name',ish=False)

    pc['company'] = pc['ipaddress'].apply(getcompany)

    # 월간 회사별 위협 수
    groupby_threat_count(u'%s 사업장별 위협 수'%when,u'위협','',pc,'company')

    # 월간 회사별 탐지이벤트
    for i in company.keys() :
        try:
            groupby_threat_count(u'%s 위협이벤트 : %s'%(when,i),u'위협','', pc[ pc['company']== i]     ,'eventname')
        except Exception as err:
            pass#print(err)

    # server 호스트종류 별 위협수
    server['hosttype'] = server['computer_name'].apply(splitserverhost)
    groupby_threat_count(u'%s 서버 호스트종류별 위협수'%when,u'위협','',server,'hosttype')

    # 서버별 위협수
    groupby_threat_count(u'%s 서버별 위협수'%when,u'위협','',server,'computer_name')

    # 서버군 위협 탐지 룰
    groupby_threat_count(u'%s 서버군 위협탐지이벤트'%when,u'위협','',server,'eventname')

    # PC , Server 의 EventName에 따른 분포
    makesns_scatterplot(data[data['isthreat']==1],'computer_name','eventname','year-mon',u'2.PC , Server 의 EventName에 따른 분포',45,30)


    '''
    # 시간포맷 변경 및 추가
    yeardata['evttime'] = pd.to_datetime(yeardata['event_time'], format='%Y-%m-%d %H:%M:%S' ).apply(pd.Timestamp)
    yeardata["year"] = yeardata["evttime"].dt.year
    yeardata["month"] = yeardata["evttime"].dt.month
    yeardata["day"] = yeardata["evttime"].dt.day
    yeardata["hour"] = yeardata["evttime"].dt.hour
    yeardata["minute"] = yeardata["evttime"].dt.minute
    yeardata["second"] = yeardata["evttime"].dt.second
    yeardata.shape
    yeardata.columns
        
    #seaborn groupby 그래프 그리기
    def makesns_bar_point(data,x,y,groupby_col,title,sizex,sizey):
        try:
            data = data[data['isthreat']==1]
            plt.figure()
            mpl.rcParams["figure.figsize"] = (sizex,sizey)
            ttt = data.groupby(data[groupby_col]).count()
            ttt.reset_index(inplace=True)
            sns.barplot(x=x, y=y, data=ttt ).set_title(title)
            sns.pointplot(x=x, y=y, data=ttt).set_title(title)
            plt.xticks(rotation=30, ha='right')
            plt.savefig(title + '.png')
        except Exception as err :
            print err

    pc2 = data [ data['computer_name'].str.match('.*-\d{3}') == False]
    server2 = data [ data['computer_name'].str.match('.*-\d{3}') == True ]
    pc2['company'] = pc2['ipaddress'].apply(getcompany)
    server2['hosttype'] = server2['computer_name'].apply(splitserverhost)
    makesns_bar_point(yeardata,'year-mon','isthreat','year-mon',u'월별 위협수치',15,7)
    makesns_bar_point(data,'isserver','isthreat','isserver',u'%s PC VS Server'%when,15,7)
    makesns_bar_point(pc2,'year-mon-day','isthreat','year-mon-day',u'%s PC 일일 위협수치'%when,15,7)
    makesns_bar_point(pc2,'company','isthreat','company',u'%s 사업장별 위협수치'%when,15,7)

    # 월간 회사별 탐지이벤트
    for i in company.keys() :
        try:
            makesns_bar_point(pc2[pc2['company']==i], 'eventname','isthreat','eventname',u'%s 사업장별 PC 이벤트 - %s'%(when,i),15,7)
        except Exception as err:
            pass#print(err)

    makesns_bar_point(pc2,'computer_name','isthreat','computer_name',u'%s PC Host별 위협수치'%when,15,7)
    makesns_bar_point(pc2,'eventname','isthreat','eventname',u'%s PC 이벤트별 위협수치'%when,15,7)

    # server 그래프
    makesns_bar_point(server2,'year-mon-day','isthreat','year-mon-day',u'%s Server 일일 위협수치'%when,15,7)
    makesns_bar_point(server2,'hosttype','isthreat','hosttype',u'%s Server HostType별 위협수치'%when,15,7)
    makesns_bar_point(server2,'computer_name','isthreat','computer_name',u'%s Server Host별 위협수치'%when,15,7)
    makesns_bar_point(server2,'eventname','isthreat','eventname',u'%s Server 이벤트별 위협수치'%when,15,7)

    #!pip install wordcloud
    #wordcloud
    from wordcloud import WordCloud
    import matplotlib.pyplot as plt
    get_ipython().run_line_magic('matplotlib', 'inline')
    def getwordcloud(data):
        STOPWORDS = ['Fireeye','dtype','object']
        wordcloud = WordCloud(font_path=font_fname,max_font_size=100,width = 3000,height = 2000,background_color = 'white',stopwords = STOPWORDS).generate(data) #.generate_from_frequencies(data)
        plt.figure(figsize = (20,10))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
    getwordcloud(' '.join(list(['eventname'])))

    getwordcloud(' '.join((data['computer_name'])))

    '''

