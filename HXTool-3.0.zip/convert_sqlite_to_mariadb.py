#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import pymysql
import sqlite3
reload(sys)
sys.setdefaultencoding('utf-8')


maria = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
maria_cursor = maria.cursor()
maria_cursor.execute('create table if not exists reqtriage(triage_id varchar(100) primary key,req_type varchar(100),state varchar(100),downlink varchar(300),device varchar(100),category varchar(100),event_time varchar(100),alertdatetime1 varchar(100),request_time varchar(100),computer_name varchar(100),user_name varchar(100),ipaddress varchar(100),agent_id varchar(100),req_success varchar(100),event text,comment text)')

sqlitecon = sqlite3.connect('passive_triage.db')
sqlite_cursor = sqlitecon.cursor()
sqlite_cursor.execute('select * from reqtriage')
rows = sqlite_cursor.fetchall()
insert_sql = ''
for row in rows:
    insert_sql = ''
    for idx,col in enumerate(row) :
        if idx==0 : triage_id = col
        elif idx==1 : req_type = col
        elif idx==2 : state = col
        elif idx==3 : downlink = col
        elif idx==4 : device = col
        elif idx==5 : category = col
        elif idx==6 : event_time = col
        elif idx==7 : alertdatetime1 = col
        elif idx==8 : request_time = col
        elif idx==9 : computer_name = col
        elif idx==10 : user_name = col
        elif idx==11 : ipaddress = col
        elif idx==12 : agent_id = col
        elif idx==13 : req_success = col
        elif idx==14 : event = col
        elif idx==15 : comment = col
    insert_sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment)
    maria_cursor.execute(insert_sql)
maria.close()
sqlitecon.close()
        





