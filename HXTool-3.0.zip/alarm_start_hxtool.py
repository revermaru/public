#!/usr/bin/env python
# -*- coding: utf-8 -*-
from alarmpol import AlarmSMSAPIClient, GroupwareAlarmAPIClient, sendSms
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

def sendalarm(msg, user_id, team=''):
    try:
        user_id = user_id.replace(' ', '')
        team = team.replace(' ', '')
        msg = msg.replace('\\','/')
        if team == '':
            client = GroupwareAlarmAPIClient('isteamalarm', user_id, msg)
        else:
            client = GroupwareAlarmAPIClient('isteamalarm', 'dept', msg, team)
        client.request()
    except Exception as err :
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}

sendalarm('[ start hxtool.py ]','yskim04')

