# -*- coding: utf-8 -*-
import urllib2
import ssl
import json
import logging
import sys
import time
import os
from reqhx import get_token,request_hx
reload(sys)
sys.setdefaultencoding('utf-8')
#ctx = ssl.create_default_context()
#ctx.check_hostname = False
#ctx.verify_mode = ssl.CERT_NONE

HXSRV = 'https://112.175.67.137:3000'
HXSRV_TOKEN = '/hx/api/v3/token'
HXSRV_HOSTS_SETS = '/hx/api/v3/host_sets'
HXSRV_HOSTS = '/hx/api/v3/hosts'
HXSRV_ACQS = '/hx/api/v3/acqs/triages'
HXSRV_ALL_ALERTS = '/hx/api/v3/alerts'
HXSRV_CONDITION_BY_ID = '/hx/api/v3/conditions'

def request_alerts(maxnum):

    # 토큰요청
    token = get_token()

    # alerts list 요청
    alerts = request_hx(token,HXSRV_ALL_ALERTS,'?sort=event_at+d&limit=%s' %maxnum,'GET',None)

    # 레포트 생성 (host id 로 alert event 묶음)
    report , host_id , condition_id = '','',''
    for item in alerts['data']['entries'] :
        #print item['agent']['_id']
        # 호스트 정보 추가
        print(json.dumps(item,indent=2))
        if host_id != item['agent']['_id'] :
            host_id = item['agent']['_id']
            report += '4. Additional check points\r\n\r\n'
            report += '\r\n\r\n===========================================\r\n\r\n'
            report += '0. indicator : \r\n\r\n'
            host_info = request_hx(token,HXSRV_HOSTS,'/%s' %host_id,'GET',None)
            report += '1. Host Name : ' + host_info['data']['hostname'] + '\r\n\r\n'
            report += '2. Primary IP Address : ' + host_info['data']['primary_ip_address'] + '\r\n\r\n'
            report += '3. stats\r\n' + str(host_info['data']['stats']) + '\r\n\r\n'


        # condition 추가 (탐지패턴)
        if str(type(item['condition'])).find('NoneType') > -1 :
            continue
        if condition_id != item['condition']['_id'] :
            condition_id = item['condition']['_id']
            condition_info = request_hx(token,HXSRV_CONDITION_BY_ID,'/%s' %condition_id,'GET',None)
            #report += '4. Condition : ' + str(condition_info['data']).replace('[','\r\n').replace(']','\r\n') + '\r\n\r\n'
            report += '[ Condition ]\r\n'
            for op in condition_info['data']['tests'] :
                if op.has_key('negate') == True and op['negate'] == True :
                    report += 'Not '
                else :
                    report += '& '
                report += op['token'] + '   ' + op['operator'] + '   '  + op['value'] + '\r\n'

            report += '\r\n'

        # 탐지 이벤트 내용 추가
        # report += '4. Containment State : ' + item['agent']['containment_state'] + '\r\n'
        report += '[ Event ]\r\n'
        report += 'Event Time : ' + item['event_at'] + '\r\n'
        report += 'Event Type : ' + item['event_type'] + '\r\n'
        report += 'Event Value : ' + str(item['event_values']) + '\r\n\r\n'

    report = report.replace('u\'','').replace('\'','').replace('{','').replace('}','').replace(',','\r\n')
    #print report

    # 파일 저장
    logf = 'triage_history.txt'
    with open(logf, 'wb') as f:
        f.write(report.encode('utf-8'))

    #os.system('notepad.exe %s' %logf)

if __name__ == '__main__' :
    #num = raw_input('Input Max Event Number : ')
    #request_alerts(str(num))

    # response_success_list  = ['OK','Accepted','Created',']
    
    x = os.popen('ps -ef | grep hxtool.py').read().splitlines()
    y = []
    for i in x : 
        if 'grep' in i : continue
        y.append(i)
    print(y)
