#!/usr/bin/env python
# -*- coding: utf-8 -*-

# marucode + original
##################################################
# hxTool - 3rd party user-interface for FireEye HX 
#
# Henrik Olsson
# henrik.olsson@fireeye.com
#
# For license information see the 'LICENSE' file
##################################################

# Core python imports
import base64
import sys
import logging
import json
import io
import os
import datetime
import threading
import time
from functools import wraps
import xml.etree.ElementTree as ET
from string import Template
from xml.sax.saxutils import escape as xmlescape
import re
from flask_autoindex import AutoIndex

reload(sys)
sys.setdefaultencoding('utf-8')

try:
    import StringIO
except ImportError:
    # Running on Python 3.x
    from io import StringIO
    from io import BytesIO

# Flask imports
try:
    from flask import Flask, request, Response, session, redirect, render_template, send_file, g, url_for, abort
    from jinja2 import evalcontextfilter, Markup, escape
except ImportError:
    print("hxtool requires the 'Flask' module, please install it.")
    exit(1)
    
# pycryptodome imports
try:
    from Crypto.Cipher import AES
    from Crypto.Protocol.KDF import PBKDF2
    from Crypto.Hash import HMAC, SHA256
except ImportError:
    print("hxtool requires the 'pycryptodome' module, please install it.")
    exit(1)
    
# hx_tool imports
from hx_lib import *
from hxtool_formatting import *
from hxtool_db import *
from hxtool_process import *
from hxtool_config import *
from hxtool_data_models import *

app = Flask(__name__, static_url_path='/static')
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['PERMANENT_SESSION_LIFETIME'] =  datetime.timedelta(minutes=60*24*7)
RESULT_DIR = '/home/apps/hxtool/hx_es_daemon/es_query_result'
AutoIndex(app, RESULT_DIR,add_url_rules=True)
HXTOOL_API_VERSION = 1
IAMS_FIREEYE_ALERT_NUM = 1712
IAMS_FIREEYE_ALERT_APIKEY = '95a312c4-20f8-47c1-8506-fd3754453ca7'
IAMS_GITLEAK_NUM = 1339
IAMS_GITLEAK_APIKEY = '0dc02b04-a3b6-418e-9884-8592e82d0d3d'

ht_config = None
ht_db = None

def valid_session_required(f):
    @wraps(f)
    def is_session_valid(*args, **kwargs):
        if (session and 'ht_user' in session and 'ht_api_object' in session):
            o = HXAPI.deserialize(session['ht_api_object'])
            if o.restIsSessionValid():
                kwargs['hx_api_object'] = o
                if (session and 'otp' in session) and session['otp'] == True :
                    session.permanent = True
                    return f(*args, **kwargs)
                else : 
                    return redirect('/otppage') 
            else:
                app.logger.info("The HX API token for the current session has expired, redirecting to the login page.")
        return redirect(url_for('login', redirect_uri = request.full_path))    
    return is_session_valid

#maru add login session 
def valid_session_required_maru(f):
    @wraps(f)
    def is_session_valid(*args, **kwargs):
        if (session and 'ht_user' in session):
            if (session and 'otp' in session) and session['otp'] == True : 
                session.permanent = True
                return f(*args, **kwargs)
            else : return redirect('/otppage') 
        else:
            app.logger.info("Login Failed")
        return redirect(url_for('login', redirect_uri = request.full_path))
    return is_session_valid

@app.route('/maruhome',methods=['GET'])
@valid_session_required_maru #maru
def maruhome():
    return redirect('https://hx-tool.hanpda.com/es_query_result/triage_list/search?keyword=fireeyehx&field=device')

### Flask/Jinja Filters
####################################

_newline_re = re.compile(r'(?:\r\n|\r|\n){1,}')
@app.template_filter()
@evalcontextfilter
def nl2br(eval_ctx, value):
    result = '<br />\n'.join(escape(p) for p in _newline_re.split(value or ''))
    if eval_ctx.autoescape:
        result = Markup(result)
    return result

#### Authentication
#######################

@app.route('/login', methods=['GET', 'POST'])
def login():
    
    if (request.method == 'POST'):
        if 'ht_user' in request.form:
            ht_profile = ht_db.profileGet(request.form['controllerProfileDropdown'])
            if ht_profile:    

                hx_api_object = HXAPI(ht_profile['hx_host'], hx_port = ht_profile['hx_port'], proxies = ht_config['network'].get('proxies'), headers = ht_config['headers'], cookies = ht_config['cookies'], logger = app.logger)

                (ret, response_code, response_data) = hx_api_object.restLogin(request.form['ht_user'], request.form['ht_pass'])
                if ret:
                    # Set session variables
                    session['ht_user'] = request.form['ht_user']
                    session['ht_profileid'] = ht_profile['profile_id']
                    session['ht_api_object'] = hx_api_object.serialize()
                    
                    # Decrypt background processor credential if available
                    # TODO: this could probably be better written
                    iv = None
                    salt = crypt_generate_random(32)
                    background_credential = ht_db.backgroundProcessorCredentialGet(ht_profile['profile_id'])
                    if background_credential:
                        salt = HXAPI.b64(background_credential['salt'], True)
                        iv = HXAPI.b64(background_credential['iv'], True)
                        
                    key = crypt_pbkdf2_hmacsha256(salt, request.form['ht_pass'])
                    
                    if iv and salt:
                        try:
                            decrypted_background_password = crypt_aes(key, iv, background_credential['hx_api_encrypted_password'], decrypt = True)
                            start_background_processor(ht_profile['profile_id'], background_credential['hx_api_username'], decrypted_background_password)
                        except UnicodeDecodeError:
                            app.logger.error("Failed to decrypt background processor credential! Did you recently change your password? If so, please unset and reset these credentials under Settings.")
                        finally:
                            decrypted_background_password = None

                    session['key']= HXAPI.b64(key)
                    session['salt'] = HXAPI.b64(salt)

                    app.logger.info("Successful Authentication - User: %s@%s:%s", session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
                    redirect_uri = request.args.get('redirect_uri')
                    if not redirect_uri:
                        redirect_uri = "/?time=today"
                    return redirect(redirect_uri, code=302)
                else:
                    return render_template('ht_login.html', fail=response_data)        
        return render_template('ht_login.html', hx_default_port = HXAPI.HX_DEFAULT_PORT, fail = "Invalid profile id.")
    else:    
        return render_template('ht_login.html', hx_default_port = HXAPI.HX_DEFAULT_PORT)

@app.route('/logout', methods=['GET'])
def logout():
    if session and session['ht_api_object']:
        hx_api_object = HXAPI.deserialize(session['ht_api_object'])
        hx_api_object.restLogout()
        app.logger.info('User logged out: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        session.pop('ht_user', None)
        session.pop('ht_api_object', None)
        session.pop('otp',None)
        hx_api_object = None
    return redirect("/login", code=302)


####################################
#
#    HXTool API
#    
####################################    
    
####################
# Profile Management
####################
@app.route('/api/v{0}/profile'.format(HXTOOL_API_VERSION), methods=['GET', 'PUT'])
def profile():
    if request.method == 'GET':
        profiles = ht_db.profileList()
        return json.dumps({'data_count' :  len(profiles), 'data' : profiles})
    elif request.method == 'PUT':
        request_json = request.json
        if validate_json(['hx_name', 'hx_host', 'hx_port'], request_json):
            if ht_db.profileCreate(request_json['hx_name'], request_json['hx_host'], request_json['hx_port']):
                app.logger.info("New controller profile added")
                return make_response_by_code(200)
        else:
            return make_response_by_code(400)
            
@app.route('/api/v{0}/profile/<profile_id>'.format(HXTOOL_API_VERSION), methods=['GET', 'PUT', 'DELETE'])
def profile_by_id(profile_id):
    if request.method == 'GET':
        profile_object = ht_db.profileGet(profile_id)
        if profile_object:
            return json.dumps({'data' : profile_object})
        else:
            return make_response_by_code(404)
    elif request.method == 'PUT':
        request_json = request.json
        if validate_json(['profile_id', 'hx_name', 'hx_host', 'hx_port'], request_json):
            if ht_db.profileUpdate(request_json['_id'], request_json['hx_name'], request_json['hx_host'], request_json['hx_port']):
                app.logger.info("Controller profile %d modified.", profile_id)
                return make_response_by_code(200)
    elif request.method == 'DELETE':
        if ht_db.profileDelete(profile_id):
            app.logger.info("Controller profile %s deleted.", profile_id)
            return make_response_by_code(200)
        else:
            return make_response_by_code(404)

####################
# Utility Functions
####################

def validate_json(keys, j):
    for k in keys:
        if not k in j or not j[k]:
            return False    
    return True
        
def make_response_by_code(code):
    code_table = {200 : {'message' : 'OK'},
                400 : {'message' : 'Invalid request'},
                404 : {'message' : 'Object not found'}}
    return (json.dumps(code_table.get(code)), code)

"""
Generate a random byte string for use in encrypting the background processor credentails
"""
def crypt_generate_random(length):
    return os.urandom(length)

"""
Return a PBKDF2 HMACSHA256 digest of a salt and password
"""
def crypt_pbkdf2_hmacsha256(salt, data):
    return PBKDF2(data, salt, dkLen = 32, count = 100000, prf = lambda p, s: HMAC.new(p, s, SHA256).digest())

"""
AES-256 operation
"""
def crypt_aes(key, iv, data, decrypt = False, base64_coding = True):
    cipher = AES.new(key, AES.MODE_OFB, iv)
    if decrypt:
        if base64_coding:
            data = HXAPI.b64(data, True)
        data = cipher.decrypt(data).decode('utf-8')
        # Implement PKCS7 de-padding
        pad_length = ord(data[-1:])
        if 1 <= pad_length <= 15:
            if all(c == chr(pad_length) for c in data[-pad_length:]):
                data = data[:len(data) - pad_length:]
        return data
    else:
        # Implement PKCS7 padding
        pad_length = 16 - (len(data) % 16)
        if pad_length < 16:
            data += (chr(pad_length) * pad_length)
        data = data.encode('utf-8')            
        data = cipher.encrypt(data)
        if base64_coding:
            data = HXAPI.b64(data)
        return data
    
"""
Iter over a Requests response object
and yield the chunk
"""
def iter_chunk(r, chunk_size = 1024):
    for chunk in r.iter_content(chunk_size = chunk_size):
        yield chunk
    
### background processing 
#################################
def start_background_processor(profile_id, hx_api_username, hx_api_password):
    p = hxtool_background_processor(ht_config, ht_db, profile_id, logger = app.logger)
    p.start(hx_api_username, hx_api_password)
    app.logger.info('Background processor started.')    

@app.route('/')
@valid_session_required
def index(hx_api_object):
    return redirect('https://hx-tool.hanpda.com/es_query_result/triage_list/search?keyword=fireeyehx&field=device')

#################################
# Add Function for Request Passive Triage (by soccermaru)
# todolist : make event message from post request
# event 컬럼 사용 시 event 컬럼의 <br> 로 구분자 사용함에 주의 (event 컬럼 추가 시 <br> 최소 한 개 입력해야함)
#################################
def crypt_generate_random(length):
    return os.urandom(length)

from flask_restful import Resource, Api
from flask_restful import reqparse
from reqhx import request_hx,get_token,download_triage,hxlogger,BUG,health_check_hx
import sys,time,datetime,sqlite3,os
import threading
import urllib2,urllib
import ssl
import re,pytz
from alarmpol import AlarmSMSAPIClient, GroupwareAlarmAPIClient, sendSms

passive_traige_error = hxlogger('passive_traige_error')
passive_traige_request = hxlogger('passive_traige_request')
HXSRV_HOSTS = '/hx/api/v3/hosts'
HXSRV_ACQS = '/hx/api/v3/acqs/triages'
HXSRV_TRIAGE_LIST = '/hx/api/v3/acqs/triages'
PASSIVE_TRIAGE_DBFILE = '/home/apps/hxtool/HXTool-3.0/passive_triage.db'
#app = Flask(__name__)

# must modify
DBTYPE = 'mariadb'
#DBTYPE = 'sqlite'
#hxtool_srv = 'https://localhost:9000' 
hxtool_srv = 'https://hx-tool.hanpda.com'
errorreceiver = 'yskim04'
alarmreceiver = 'yskim04,chlee,yccheon,jjchoi,ywkim02,chmoon,ghseol' # must modify
#alarmreceiver = 'yskim04'
SYMANTEC_IOC = '.VBN File Written Event(ccSvcHst.exe)'
RE_TAG = '(heur|miner|pua|pup|reputation|adv|android|securityrisk|adware|NTP)'
#RE_TAG = '(bot|rat|apt|operation|steal|ddos|shell|cve-|exploit|expkit|trojan|fireeye|netcat|hack|mimikatz|ransom|scan|backdoor)' 
IGNORED_TAG = ['cafe24printeragent_setup','EICAR\\sTest\\sString','SUMMARIZED\\sDATA','OfficeTalkUpdate\\.exe',
'.*NESSUSD.EXE.*Intrusion.*ip_addr1_text": "123.140.249.97"','.*NTP.*Scan.*"remote_host_ip_text": "123.140.249.97"','Tracking\\sCookies','filepath.+Cookie.+@',
'.*NESSUSD.EXE.*Intrusion.*ip_addr1_text": "1.209.128.245"','.*NTP.*Scan.*"remote_host_ip_text": "1.209.128.245"','Americano\\Americano',
'uws.*cafe24.*com','/home/.*www/.*','.*NESSUSD.EXE.*Intrusion.*ip_addr1_text": "10.5.1.10"','cafe24security(_admin)*\\.exe','tssafeedit\\.dat',
'gseo-portal\\.cafe24\\.com','Malicious\\sDomain\\sRequest','Browser\\sExtension','TeamViewer\\sRemote\\sAccess\\sActivity','Symantec\\sNTP\\s:\\sWeb\\sAttack',
'Generic Load Point','LightShot\\sTool\\sActivity'
]
# triage 정보수집 기능 외 (비)활성화
ISDISABLE = 'FALSE'

api = Api(app)

if DBTYPE == 'mariadb' :
    import pymysql
    con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
    cursor = con.cursor()
    # create reqtriage table
    create_reqtriage_table = '''
    create table if not exists reqtriage(triage_id varchar(100) primary key,req_type varchar(100),state varchar(100),downlink varchar(300),device varchar(100),category varchar(100),event_time varchar(100),alertdatetime1 varchar(100),request_time varchar(100),computer_name varchar(100),user_name varchar(100),ipaddress varchar(100),agent_id varchar(100),req_success varchar(100),event text,comment text,summary text,spenttime varchar(100))  DEFAULT CHARSET=utf8mb4
    '''

    cursor.execute(create_reqtriage_table)
    # create waitreqtriage table
    cursor.execute('''
    create table if not exists waitreqtriage(postbody text) DEFAULT CHARSET=utf8mb4
    ''')
    # create ioc enterprise search table
    create_ioc_es_table = '''
    create table if not exists ioces(search_id varchar(100) primary key, request_time varchar(100), end_time varchar(100), ioc_dic text, hx_response_json text, description text, reference text, search_result_json text, userinfo text, es_summary text) DEFAULT CHARSET=utf8mb4
    '''
    cursor.execute(create_ioc_es_table)
    con.commit()
    con.close()
else :
    con = sqlite3.connect(PASSIVE_TRIAGE_DBFILE)
    cursor = con.cursor()
    create_reqtriage_table = '''
    create table if not exists reqtriage(triage_id text primary key,req_type text,state text,downlink text,device text,category text,event_time text,alertdatetime1 text,request_time text,computer_name text,user_name text,ipaddress text,agent_id text,req_success text,event text,comment text)
    '''
    cursor.execute(create_reqtriage_table)
    cursor.execute('''
    create table if not exists waitreqtriage(postbody text primary key)
    ''')
    con.commit()
    con.close()


maru_token = {}
maru_token['token'] = get_token()
maru_token['grant_timestamp'] = str(datetime.datetime.utcnow())
maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
token = maru_token['token']

CHECK_TRIAGE_STATE_TIME = 15
MAX_DURATION = 60
MAX_QUEUE =101
MAX_VIEW_LIST_NUM = 5

#description : db 접속 함수 (초기 테스트 시 sqlite를 사용,현재는 mariadb 사용)
def dbconn() :
    if DBTYPE == 'mariadb' : con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
    else : con = sqlite3.connect(PASSIVE_TRIAGE_DBFILE)
    return con


#description : token timeout 점검 함수
def maru_restIsSessionValid():
    try:
        current_token = maru_token
        if current_token:
            last_use_delta = (datetime.datetime.utcnow() - datetime.datetime.strptime(current_token['last_use_timestamp'], '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
            grant_time_delta = (datetime.datetime.utcnow() - datetime.datetime.strptime(current_token['grant_timestamp'], '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
            if (last_use_delta < 13 and grant_time_delta < 110) :
                maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
                token = maru_token['token']
            else : 
                reset_token()
        else:
            reset_token()
        # print maru_token['token']
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : token 허용시간이 지났을 경우 token 재생성
def reset_token():
    try:
        maru_token['token'] = get_token()
        maru_token['grant_timestamp'] = str(datetime.datetime.utcnow())
        maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
        token = maru_token['token']
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description :  time format을 통일시키기 위한 함수
def convert_timeformat(timestr) :
    timestr = str(timestr).replace('Z','').replace('T',' ').split('.')[0]
    return timestr

#description :  주기적으로 triage stat 업데이트 및 auto triage 추가
NOT_COMPLETE = []
def check_triage_state():
    global NOT_COMPLETE
    try:
        es_daemon = os.popen('ps -ef').read()
        if es_daemon.find('es_daemon.0.2.py start') == -1 and ISDISABLE == 'FALSE' :
            os.system('cd /home/apps/hxtool/hx_es_daemon; /usr/bin/python /home/apps/hxtool/hx_es_daemon/es_daemon.0.2.py start &')
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('select count(*) from reqtriage')
        rows = cursor.fetchall()[0][0]
        maru_restIsSessionValid()
        if int(rows) < 10 :
            limittriage = 10000
            limitalerts = 10000
        else:
            limittriage = 100
            limitalerts = 1000
        triage_list = request_hx(maru_token['token'],HXSRV_TRIAGE_LIST,'?&sort=request_time+descending&limit=%d'%limittriage,'GET',None)
        #print json.dumps(triage_list)
        checked_host = []
        for item in triage_list['data']['entries'] :
            device = ''
            alerts = ''
            event = ''
            event_time = ''
            alertdatetime1 = ''
            request_time = ''
            dupl_alert = []
            agent_id = item['host']['_id']
            req_type = item['request_actor']['username']

            #if req_type.find('automatic') > -1 : print str(request_hx(maru_token['token'],item['indicator']['url'],'','GET',None)['data']) #['display_name']   

            triage_id = str(item['_id'])
            request_time = convert_timeformat(item['request_time'])
            state = item['state']
            cursor.execute('select state from reqtriage where triage_id = "%s"'%triage_id)
            rows = cursor.fetchall()
            # 이미 테이블에 triage_id가 존재한다면 state만 체크 및 업데이트
            if len(rows) > 0 :
                if rows[0][0] != state :
                    cursor.execute('update reqtriage set state = \'{0}\' where triage_id = \'{1}\''.format(state,triage_id))
                    con.commit()
                    cursor.execute('select event from reqtriage where triage_id = \'{0}\''.format(triage_id))
                    event_row = cursor.fetchall()
                    event_row = event_row[0][0].replace('<br>','\r\n')
                    con.close()
                    if state == 'COMPLETE' :
                        hostinfo = request_hx(maru_token['token'],'/hx/api/v3/hosts/',agent_id,'GET',None)
                        computer_name = hostinfo['data']['hostname']
                        ipaddress = hostinfo['data']['last_poll_ip']
                        if event_row.find('Fireeye Manual') > -1 and req_type == 'isteam_api' : alarmtitle = 'Fireye Addition'
                        else : alarmtitle = event_row.split('\r\n')[0]
                        sendalarm('[Fireeye HX] Triage Completed ({0})\r\n computer_name : {1}\r\n IPAddress : {2}\r\n triage_type : {3}\r\n downlink : {4}'.format(alarmtitle,computer_name,ipaddress,req_type,'{0}/es_query_result/stored_triage_files/{1}\r\n\r\n {2}\r\n\r\n Triage 요청 예외 항목 : {3}'.format(hxtool_srv,triage_id,event_row,str(IGNORED_TAG))),alarmreceiver)

                        # fireeye autotriage 인 경우 complete 된 이 후 수동으로 triage 재요청
                        if req_type.find('automatic') > -1 and ISDISABLE == 'FALSE' : #print 'must modify'
                            retriage = request_hx(maru_token['token'],HXSRV_HOSTS,'/' + agent_id + '/triages','POST',None)
                        # fireeeye event auto triage 완료 시 maxav 자동점검 요청
                        if 1==1 : #alarmtitle.find('Fireeye : ') > -1 or alarmtitle.find('Symantec') > -1: 
                            response = requests.get('http://localhost:8080/es_query_result/triage_list/req_maxav?triage_id=%s'%triage_id)
                continue
            if req_type.find('automatic') > -1: 
                try :
                    if item['indicator'] != None : 
                        indicator =  request_hx(maru_token['token'],item['indicator']['url'],'','GET',None)
                        display_name = indicator['data']['display_name'] 
                        if display_name != None : indicator = display_name + '<br>'
                        else : indicator = item['indicator']['url'].split('/')[-1] + '<br>'
                    else : indicator = 'multiple indicator<br>'
                    # if symantec event 
                    if indicator.find(SYMANTEC_IOC) > -1 :
                        device = 'symantec'
                        #alerts = str(request_hx(maru_token['token'],item['alert']['url'],'','GET',None)['data']['event_values']['fileWriteEvent/textAtLowestOffset'])
                        alerts_dic = request_hx(maru_token['token'],'/hx/api/v3/alerts?sort=event_at+d&limit=%d'%limitalerts,'','GET',None)
                        for alert in alerts_dic['data']['entries'] :
                            if alert['agent']['_id'] == agent_id :
                                alertdatetime1 = convert_timeformat(alert['event_at'])
                                event_time = alertdatetime1
                                if alert['event_values'].has_key('fileWriteEvent/textAtLowestOffset'):
                                    checkduplication = alert['event_values']['fileWriteEvent/textAtLowestOffset'].replace('.','').lower()
                                if checkduplication not in dupl_alert :
                                    alerts += alert['event_values']['fileWriteEvent/textAtLowestOffset'] + '<br>'
                                    dupl_alert.append(checkduplication)
                                else : 
                                    continue
                    else : 
                        if indicator.lower().find('noalarm_') > -1 : 
                            device = 'noalarm'
                            request_hx(maru_token['token'],'/hx/api/v3/acqs/triages/%s'%triage_id,'','DELETE',None)
                        else : device = 'FireEyeHX'
                        alerts = request_hx(maru_token['token'],item['alert']['url'],'','GET',None)
                        if indicator == 'multiple indicator<br>' : indicator = alerts['data']['multi_indicators'][0]['display_name'] + '<br>'
                        alertdatetime1 = convert_timeformat(alerts['data']['event_at'])
                        event_time = alertdatetime1
                        alert_dic =  alerts['data']['event_values']
                        alerts = ''
                        for key,value in alert_dic.items():
                            alerts += str(key) + ' : ' + str(value).replace('<','[').replace('>',']') + '<br>'
                    alerts = alerts.replace(',','<br>').replace("'",'"').replace('u"','"')
                    event = 'Fireeye : {0}'.format(indicator)
                    event += '<a href = "https://112.175.67.137:3000/hx/api/plugins/storytime/viewer?triage=%s" style="text-decoration:none" title="StoryTime Viewer" target="_blank"><font color="yellow">StoryTime </font></a>'%triage_id
                    event += '<a href="https://112.175.67.137:3000/hx/hosts/{0}/alerts/" style="text-decoration:none" title="Event Viewer on HX" target="_blank"><font color="green"> 상세보기</font></a><br>{1}'.format(agent_id,alerts)   
                except Exception as err: 
                    #passive_traige_error.error(str(err))
                    pass
            else :
                if req_type == 'isteam_api' : 
                    event = 'Fireeye Addition : HX 이벤트 발생에 따른 추가 Triage 자동 요청<br>'
                else : 
                    event = 'Fireeye Manual : 사용자 수동 수집<br>'
                req_type = 'passive'
                event_time = request_time
                alertdatetime1 = event_time
                device = 'FireEyeHX'
            
            rulename = event.split('<br>')[0] 
            if triage_id.find('Null') > -1 : continue
            #device = 'FireEyeHX'
            category = 'threats'
            hostinfo = request_hx(maru_token['token'],'/hx/api/v3/hosts/',agent_id,'GET',None)
            computer_name = hostinfo['data']['hostname']
            user_name,comment = '','<font color="white">NotYet</font>'
            if triage_id.find('Null') > -1 : downlink = 'Null'
            elif triage_id.find('.') > -1 : downlink = 'Null'
            else: downlink = '<a href ="{0}/es_query_result/stored_triage_files/{1}" target="_blank"><font color="white">{2}.mans</font></a>'.format(hxtool_srv,triage_id,triage_id)
            NOT_COMPLETE = list(set(NOT_COMPLETE))
            if computer_name not in checked_host :
                if state == 'COMPLETE' and computer_name in NOT_COMPLETE :  NOT_COMPLETE.remove(computer_name)
                    #sendalarm('[Fireeye HX] Triage Completed\r\n computer_name : {0}\r\n triage_type : {1}\r\n device : {2}\r\n downlink : {3}'.format(computer_name,req_type,device,'{0}/es_query_result/stored_triage_files/{1}'.format(hxtool_srv,triage_id)),alarmreceiver)
                elif state != 'COMPLETE' and computer_name not in NOT_COMPLETE : NOT_COMPLETE.append(computer_name)
                checked_host.append(computer_name)
            elif  rulename.find('noalarm_') > -1 : pass
            else : continue
            ipaddress = hostinfo['data']['last_poll_ip']
            req_success = 'true'
            sql = 'select triage_id from reqtriage where triage_id = \'{0}\''.format(triage_id)
            cursor.execute(sql)
            rows = cursor.fetchall()
            if len(rows) == 0 :
                if DBTYPE == 'mariadb' :
                    event = event.replace('\\','/')
                    sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment,rulename) 
                    if req_type.find('automatic') > -1 :
                        if containment(agent_id,event,maru_token['token']) == 'Created' :
                            sendalarm('[Fireeye HX] Containment Completed ({0})\r\n computer_name : {1}\r\n IPAddress : {2}\r\n triage_type : {3}\r\n downlink : {4}'.format('!',computer_name,ipaddress,req_type,'{0}/es_query_result/stored_triage_files/{1}\r\n\r\n {2}\r\n'.format(hxtool_srv,triage_id,event.replace('<br>','\n'))),alarmreceiver)
                else :
                    sql = 'insert or ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',\'{16}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment,rulename)
                cursor.execute(sql)
                con.commit()
                # *Git Commit 사용자 체크 * 
                if rulename.lower().find('noalarm_git_commit_external_repo') > -1 :
                    tmp_evt , giturl = event.split('<br>') , ''
                    for line in tmp_evt : 
                        if line.find('processEvent/processCmdLine') > -1 :
                            line = line.split(' ')
                            for i in line :
                                if i.lower().find('http') > -1 : giturl = i
                    gitleakmsg = "*Git Commit 사용자 체크* : [{'repo':'%s','ip':'%s','host':'%s'}]"%(giturl,ipaddress,computer_name)
                    iamsalarm(gitleakmsg,IAMS_GITLEAK_NUM,IAMS_GITLEAK_APIKEY)   
                #iams 
                if req_type.find('automatic') > -1 :
                    event = re.sub(r'<a href.*</a>','',event)
                    iams_msg = '[ Fireeye Alert ]\n'
                    iams_msg += 'rulename : ' + rulename + '\n'
                    iams_msg += 'host : ' + computer_name + '\n'
                    iams_msg += 'ipaddress : ' + ipaddress + '\n'
                    iams_msg += 'event_time : ' + event_time + '\n'
                    iams_msg += 'event : ' + event.replace('<br>','\n') + '\n'
                    if 'noalarm_' not in rulename : iamsalarm(iams_msg.replace('<br>','\n'),IAMS_FIREEYE_ALERT_NUM,IAMS_FIREEYE_ALERT_APIKEY) 
                    make_dataeye_json('',event.replace('<br>','\n'),triage_id,device,alertdatetime1,computer_name,ipaddress,'','',rulename)
            cursor.execute('update reqtriage set state = \'{0}\' where triage_id = \'{1}\''.format(state,triage_id)) 
            con.commit()
        con.close()
        getcpayhx_from_slack_http()
        getcpaysymantec_from_slack_http()
        #getcpayhx_from_mattermost() #mattermost 종료
        #getcpaysymantec_from_mattermost() #mattermost 종료
        #getsentinelone() #poc
        time.sleep(CHECK_TRIAGE_STATE_TIME)
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

## poc
def getsentinelone() :
    try : 
        timeflag = 'sentinel_lasttime.txt'
        if os.path.isfile(timeflag) == True :
            with open(timeflag,'r') as f :
                lasttime = int(f.read())
        else : lasttime = 0    
        srv = 'https://apne1-1110-mssp.sentinelone.net'
        headers = {'Authorization':'ApiToken mqWWOqjazX8QhLgfUlBF1XrsfSi6B8F5EadL59Nded7j1jiLY3dXeAsYgZgjrceOupmKvXAXg8tP6HYq'}
        #threat_url = '/web/api/v2.1/threats?createdAt__gte=2022-02-09T03%3A00%3A00.000000Z&osTypes=macos'
        threat_url = '/web/api/v2.1/threats?sortOrder=desc&sortBy=updatedAt'
        r = requests.get(srv + threat_url , headers = headers)
        r = r.json()
        evtid = r['data'][0]['id']
        if int(evtid) <= lasttime : return
        else : lasttime = str(evtid)
        for idx in r['data'] :            
            threat = idx['threatInfo']['threatName']
            threat_info = str(idx['threatInfo']).replace('\',','<br>').replace('u\'','').replace('\'','')
            event = 'SentinelOne : ' + threat 
            hostname = idx['agentRealtimeInfo']['agentComputerName']
            ipaddr = idx['agentDetectionInfo']['externalIp']
            evttime = str(idx['threatInfo']['updatedAt']).split('.')[0]
            alerts = event + '<br>'
            alerts += threat_info
            ## insert hxtool db
            con = dbconn()
            cursor = con.cursor()
            sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(evttime,'automatic','COMPLETE','notfound','SENTINELONE','threats',evttime,evttime,evttime,hostname,hostname,ipaddr,'notfound','true',alerts,'NotYet',event) 
            cursor.execute(sql)
            con.commit()
            con.close()
        with open(timeflag,'w') as f :
            f.write(str(lasttime))    
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        passive_traige_error.error(str(err))

def getcpayhx_from_slack_http():
    try:
        token = "xoxb-306622492115-3150109205522-sFHFf9t1g6zP5RD6xq0rAo5n"
        #channel_name = "#n_is_fireeye_cpay"
        channel_id = 'C02S64UQPLG'
        token = 'Bearer ' + token
        me = 'https://cafe24corp.slack.com/api/conversations.history?channel=%s'%channel_id
        headers = {'Authorization':token}
        #lasttime = 1615436440982
        timeflag = 'cpayhx_lasttime.txt'        
        if os.path.isfile(timeflag) == True :
            with open(timeflag,'r') as f :
                lasttime = int(f.read())
        else : lasttime = 0
        res = requests.get(me, headers=headers)
        res = res.json()
        for i in res['messages'] :
            if i['type'] != 'message' : continue
            if 'ts' not in i : continue
            if 'text' not in i : continue
            if 'HX Alarm' not in i['text'] : continue    
            ts = int(i['ts'].split('.')[0])
            if ts <= lasttime : continue
            lasttime = ts
            msg = i['text'].split('= ') 
            event = 'CPAY Fireeye : ' + msg[0].split(' : ')[1]
            hostname = msg[1].split(' : ')[1].replace('\n','')
            ipaddr = msg[2].split(' : ')[1].replace('\n','')
            evttime = msg[3].split(' : ')[1].replace('\n','')
            alerts = event + msg[4].split('Alerts')[1].replace('\\','/').replace(',','\n').replace('"','').replace('{','').replace('}','').replace('\n','<br>')
            alerts = alerts.replace('<br> <br>','<br>').replace('<br><br>','<br>')
            ## insert hxtool db
            con = dbconn()
            cursor = con.cursor()
            sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(evttime,'automatic','COMPLETE','notfound','CPAY','threats',evttime,evttime,evttime,hostname,hostname,ipaddr,'notfound','true',alerts,'NotYet',event) 
            cursor.execute(sql)
            con.commit()
            con.close()
        with open(timeflag,'w') as f :
            f.write(str(lasttime))
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        passive_traige_error.error(str(err))

def getcpaysymantec_from_slack_http():
    try:
        token = "xoxb-306622492115-3150109205522-sFHFf9t1g6zP5RD6xq0rAo5n"
        #channel_name = "#n_cpay_symantec"
        channel_id = 'C031N3XLL2K'
        token = 'Bearer ' + token
        me = 'https://cafe24corp.slack.com/api/conversations.history?channel=%s'%channel_id
        headers = {'Authorization':token}
        #lasttime = 1615436440982
        timeflag = 'cpaysymantec_lasttime.txt'
        if os.path.isfile(timeflag) == True :
            with open(timeflag,'r') as f :
                lasttime = int(f.read())
        else : lasttime = 0
        res = requests.get(me, headers=headers)
        res = res.json()
        for i in res['messages'] :
            if i['type'] != 'message' : continue
            if 'ts' not in i : continue
            if 'text' not in i : continue
            if 'symantec-manager-pay' not in i['text'] : continue    
            ts = int(i['ts'].split('.')[0])
            if ts <= lasttime : continue
            lasttime = ts
            msg = i['text']
            msg = msg.splitlines()
            alerts = ''
            for line in msg : 
                if 'Virus Name' in line : event = 'CPAY Symantec : ' + line.split(' : ')[1]
                elif 'User Name' in line : user = line.split(' : ')[1]
                elif 'System Name' in line : hostname = line.split(' : ')[1]
                elif 'IP Address' in line : ipaddr = line.split(' : ')[1]  
                elif 'Event Occur Time' in line : evttime = line.split(' : ')[1]                
                else : alerts += line + ('\n')
            alerts = alerts.replace('\n\n','\n').replace('\n','<br>').replace('\\','/')
            alerts = event + '<br>' + alerts            
            ## insert hxtool db
            con = dbconn()
            cursor = con.cursor()
            sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(evttime,'passive','COMPLETE','notfound','CPAY','threats',evttime,evttime,evttime,hostname,hostname,ipaddr,'notfound','true',alerts,'NotYet',event) 
            cursor.execute(sql)
            con.commit()
            con.close()            
        with open(timeflag,'w') as f :
            f.write(str(lasttime))
    except Exception as err :
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        passive_traige_error.error(str(err))

def getcpayhx_from_mattermost():
    try:
        #https://pypi.org/project/mattermost/
        '''
        login = 'https://mattermost.hanpda.com/api/v4/users/login'
        data = '{"login_id":"isteamalarm","password":"isteam@01"}'
        res = requests.post(login, data=data)
        token = 'Bearer ' + res.headers['Token']
        '''
        token = 'Bearer ' + 'hkdyyccuu7ru8jtu1d5yj1jqie'
        me = 'https://mattermost.hanpda.com/api/v4/users/me'
        headers = {'Authorization':token}
        res = requests.get(me, headers=headers)
        cpayhx = 'nroe3by79irnjns4tiqqb6utrr'
        timeflag = 'cpayhx_lasttime.txt'
        if os.path.isfile(timeflag) == True :
            with open(timeflag,'r') as f :
                lasttime = int(f.read())
        else : lasttime = 0
        getpost = 'https://mattermost.hanpda.com/api/v4/channels/%s/posts?since=%s'%(cpayhx,str(lasttime))
        res = requests.get(getpost, headers=headers)
        res = res.json()
        if 'order' not in res : return        
        order = res['order']
        order.reverse()
        for post_id in order :
            create_at = res['posts'][post_id]['create_at']
            if create_at <= lasttime : continue
            msg = res['posts'][post_id]['message']    
            if '#CPAY HX Alarm' not in msg : continue
            lasttime = create_at            
            msg = msg.replace('\n','').split('= ')
            event = 'CPAY Fireeye : ' + msg[0].split(' : ')[1]
            hostname = msg[1].split(' : ')[1]
            ipaddr = msg[2].split(' : ')[1]
            evttime = msg[3].split(' : ')[1]
            alerts = event + '<br>'
            alerts += msg[4].split('Alerts')[1].replace('\\','/').replace(',','<br>').replace('"','').replace('{','').replace('}','')
            ## insert hxtool db
            con = dbconn()
            cursor = con.cursor()
            sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(evttime,'automatic','COMPLETE','notfound','CPAY','threats',evttime,evttime,evttime,hostname,hostname,ipaddr,'notfound','true',alerts,'NotYet',event) 
            cursor.execute(sql)
            con.commit()
            con.close()
        with open(timeflag,'w') as f :
            f.write(str(lasttime))
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        passive_traige_error.error(str(err))
       
def getcpaysymantec_from_mattermost():
    try:
        #https://pypi.org/project/mattermost/
        '''
        login = 'https://mattermost.hanpda.com/api/v4/users/login'
        data = '{"login_id":"isteamalarm","password":"isteam@01"}'
        res = requests.post(login, data=data)
        token = 'Bearer ' + res.headers['Token']
        '''
        token = 'Bearer ' + 'hkdyyccuu7ru8jtu1d5yj1jqie'
        me = 'https://mattermost.hanpda.com/api/v4/users/me'
        headers = {'Authorization':token}
        res = requests.get(me, headers=headers)
        cpaysym = '6nj67bc3g3yc8pnmk3kgxho8yh'
        #lasttime = 1615436440982
        timeflag = 'cpaysymantec_lasttime.txt'
        if os.path.isfile(timeflag) == True :
            with open(timeflag,'r') as f :
                lasttime = int(f.read())
        else : lasttime = 0

        getpost = 'https://mattermost.hanpda.com/api/v4/channels/%s/posts?since=%s'%(cpaysym,str(lasttime))
        res = requests.get(getpost, headers=headers)
        res = res.json()
        if 'order' not in res : return        
        order = res['order']
        order.reverse()
        for post_id in order :
            create_at = res['posts'][post_id]['create_at']
            if create_at <= lasttime : continue
            msg = res['posts'][post_id]['message']                
            if 'symantec-manager-pay' not in msg : continue
            lasttime = create_at 
            msg = msg.splitlines()
            alerts = ''
            for line in msg : 
                if 'Virus Name' in line : event = 'CPAY Symantec : ' + line.split(' : ')[1]
                elif 'User Name' in line : user = line.split(' : ')[1]
                elif 'System Name' in line : hostname = line.split(' : ')[1]
                elif 'IP Address' in line : ipaddr = line.split(' : ')[1]  
                elif 'Event Occur Time' in line : evttime = line.split(' : ')[1]                
                else : alerts += line + ('\n')
            alerts = alerts.replace('\n\n','\n').replace('\n','<br>')
            alerts = event + '<br>' + alerts
            ## insert hxtool db
            con = dbconn()
            cursor = con.cursor()
            sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(evttime,'passive','COMPLETE','notfound','CPAY','threats',evttime,evttime,evttime,hostname,hostname,ipaddr,'notfound','true',alerts,'NotYet',event) 
            cursor.execute(sql)
            con.commit()
            con.close()            
        with open(timeflag,'w') as f :
            f.write(str(lasttime))
    except Exception as err :
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        passive_traige_error.error(str(err))
 
def iamsalarm(message,number,iamskey) : 
    try :
        iams = 'https://iams-api.hanpda.com/v1/send-alarm?api_key='
        data = {'alarm_rule_no':number,'message': message}
        res = requests.post(iams + iamskey , data=data , verify=False)
    except Exception as err :
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)

# desc : special event and seoulpc => auto containment
def containment(agent_id,event,token):
    try : 
        CONTAINMENT_EVENT = ['net1.+group.+\/domain']
        #agent_id = 'DXxSqEaw4z4dcVhdL2QIpU' # 'h5l06sdPJx6gfN4kxgDfWL'
        is_contain = False
        result = 'false'
        hostset_uri = '/hx/api/v3/host_sets/1000/hosts?search=%s&limit=1'%agent_id 
        hostset_info = request_hx(token,hostset_uri,'','GET','')
        if hostset_info['data']['total'] == 0 : return result # is seoul pc ?
        for i in CONTAINMENT_EVENT :
            if bool(re.search(i.lower(),event.lower())) == True :
                is_contain = True
                break
        if is_contain == False : return result
        print '[ Start Containment ]'
        containment_uri = '/hx/api/v3/hosts/%s/containment'%agent_id
        request_hx(token,containment_uri,'','POST','')
        time.sleep(1)
        #u'message': u'Created'
        result = request_hx(token,containment_uri,'','PATCH','{"state":"contain"}')
        result = result['message']
        #print json.dumps(request_hx(token,containment_uri,'','GET',''),indent=2)
        #print request_hx(token,containment_uri,'','DELETE','')
        return result
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))


#description : alarm 전송 함수
import fastbox_alarmpol
def sendalarm(msg, user_id, team=''):
    try:
        user_id = user_id.replace(' ', '')
        team = team.replace(' ', '')
        msg = msg.replace('\\','/')
        if msg.find('192.168.22.') > -1 : # if fbox group 
            fastbox = fastbox_alarmpol.GroupwareAlarmAPIClient('yskim04','yskim04,jhpark,nkahn',msg)
            fastbox.request()
        if team == '':
            client = GroupwareAlarmAPIClient('isteamalarm', user_id, msg)
        else:
            client = GroupwareAlarmAPIClient('isteamalarm', 'dept', msg, team)
        client.request()
    except Exception as err :
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        print str(err)


def check_interesting_event(event) :
    if bool(re.search(RE_TAG,event.lower())) == False :return '<strong><font color="red">' + event + '</font></strong>' 
    else : return '<strong>' + event + '</strong>'

sys.path.insert(0, '/home/apps/hxtool/hx_es_daemon/lib')
import reqvirustotal

#description : ReqTriage 클래스    
class ReqTriage(Resource):
    def sendalarm(self,msg, user_id, team=''):
        try:
            user_id = user_id.replace(' ', '')
            team = team.replace(' ', '')
            msg = msg.replace('\\','/')
            #logger.info("sendGroupwareAlarm receiver:{receiver}".format(receiver=user_id))
            # print msg
            if team == '':
                client = GroupwareAlarmAPIClient('isteamalarm', user_id, msg)
            else:
                client = GroupwareAlarmAPIClient('isteamalarm', 'dept', msg, team)
            client.request()
        except Exception as err :
            err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
            #sendalarm('* HX REQ Triage Error : ' + err,errorreceiver) 
            passive_traige_error.error(str(err))
    ''''
    # 파라미터 정의
    parser = reqparse.RequestParser()
    parser.add_argument('device',type=str,required=True)
    parser.add_argument('category',type=str,required=True)
    parser.add_argument('event_time', type=str)
    parser.add_argument('begin_time', type=str)
    parser.add_argument('alertdatetime1', type=str)
    parser.add_argument('computer_name', type=str)
    parser.add_argument('user_name', type=str)
    parser.add_argument('ipaddress', type=str)
    parser.add_argument('event', type=str)
    '''
    #description :  running 갯수 제한에 의해 waitreqtriage 테이블에 저장되어 있던 triage를 재요청 한 후 삭제 & call check_triage_state 
    def re_req_triage():
        while True :
            try :
                check_triage_state()
                req_triage_uri = hxtool_srv + '/reqtriage'
                handler = urllib2.HTTPHandler()
                opener = urllib2.build_opener(handler)
                urllib2.install_opener(opener)
                con = dbconn()
                cursor = con.cursor()
                rows = cursor.execute('select postbody from waitreqtriage')
                rows = cursor.fetchall()
                for row in rows :
                    try:
                        data=str(row[0])
                        request = urllib2.Request(req_triage_uri , data=data)
                        context = ssl._create_unverified_context()
                        request.add_header('Content-Type', 'application/json')
                        request.get_method = lambda: 'POST'
                        response = urllib2.urlopen(request, context=context)
                    except urllib2.HTTPError as e:
                        msg = 'err : ' + str(e.read())
                        print msg
                        continue
                    if response.read().find('"message": "Created"') > -1 :
                        cursor.execute('delete from waitreqtriage where postbody = \'%s\' '%str(row[0]))
                con.commit()
                con.close()
                time.sleep(120)
            except Exception as err :
                err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
                #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
                passive_traige_error.error(str(err))
                #time.sleep(60)
                continue
    t1 = threading.Thread(target=re_req_triage)
    t1.daemon = True
    t1.start()
    

    def create_condition_for_detected_file_by_symantec(self,filepath,sha256) :
        #return 0
        try:
            print 'create_condition_for_detected_file_by_symantec'
            maru_restIsSessionValid()
            if filepath.find('/') > -1 : filepath = filepath.replace('/','\\')
            # check compressed file type (compressed file : include ">>" character in symantec log)
            # 압축파일 내 악성코드인 경우 full path 를 알 수 없어 filename으로 룰조건을 생성할 경우 대량의 오탐 가능성이 존재함
            # 따라서 filepath 에 ">>"가 포함된 경우 룰을 생성하지 않는다.
            # 압축이 해제 된 후에도 탐지가 되므로 압축해제 후 탐지되는 full path로 룰조건을 생성하기로함
            iscompressed = False
            if filepath.find('>>') > -1 : iscompressed = True #filepath = filepath.split('>>')[-1]
            iname = 'Malware_Execution_Event_By_Symantec'
            new_indicator_uri = '/hx/api/v3/indicators/cafe24'
            uriname_file = '/home/apps/hxtool/HXTool-3.0/Malware_Execution_Event_By_Symantec'
            if os.path.isfile(uriname_file) :
                f = open(uriname_file,'r')
                indicator_uri_name = f.read().replace('\n','')
                f.close()
                response = request_hx(maru_token['token'],'/hx/api/v3/indicators/cafe24/',indicator_uri_name,'GET',None,'n')
                if str(response).lower().find('indicator not found') > -1 :
                    new_indicator_data = '{"display_name":"%s","create_text":"isteam_api_bot","description":"Malware Execution Event(Symantec)"}'%(iname)
                    response_indicator = request_hx(maru_token['token'],new_indicator_uri,'','POST',new_indicator_data,'n')
                    indicator_uri_name = response_indicator['data']['_id']
                    f = open(uriname_file,'w')
                    f.write(indicator_uri_name)
                    f.close()
            else :
                #if indicator is not exists Create Indicator For filepath / searching indicator is too much spent time
                # indicator 주기적 삭제는 es_daemon.py 의 interval 모드에 추가 : 23시간 이후 삭제
                #del_response = request_hx(maru_token['token'],'/hx/api/v3/indicators/cafe24/',indicator_uri_name,'DELETE',None,'no')
                new_indicator_data = '{"display_name":"%s","create_text":"isteam_api_bot","description":"Malware Execution Event(Symantec)"}'%(iname)
                response_indicator = request_hx(maru_token['token'],new_indicator_uri,'','POST',new_indicator_data,'n')
                indicator_uri_name = response_indicator['data']['_id']
                f = open(iname,'w')
                f.write(indicator_uri_name)
                f.close()
            # create conditions
            filepath = filepath.replace('\\','\\\\')
            create_conditions_uri = '/hx/api/v3/indicators/cafe24/%s/conditions/execution' %indicator_uri_name
            if iscompressed == False :
                processpath_condition_format = u'{"tests": [{"operator": "contains","token": "processEvent/processPath", "type": "text", "value": "%s"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "ccSvcHst.exe"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "bandizip.exe"}]}'%filepath
                cmdline_condition_format = u'{"tests": [{"operator": "contains","token": "processEvent/processCmdLine","type": "text", "value": "%s"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "ccSvcHst.exe"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "bandizip.exe"},{"operator": "contains","negate": true, "token": "processEvent/processCmdLine", "type": "text", "value": "AcroEdit\\AcroEdit.exe"},{"operator": "contains","negate": true, "token": "processEvent/processCmdLine", "type": "text", "value": "system32\\notepad.exe"}]}'%filepath
                imageload_condition_format = u'{"tests": [{"operator": "contains","token": "imageLoadEvent/fullPath","type": "text", "value": "%s"},{"operator": "equal","negate": true, "token": "imageLoadEvent/process", "type": "text", "value": "ccSvcHst.exe"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "bandizip.exe"}]}'%filepath
                response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',processpath_condition_format.encode('utf-8'),'n')
                #print json.dumps(response_new_condition) + '\n'
                response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',cmdline_condition_format.encode('utf-8'),'n')
                #print json.dumps(response_new_condition) + '\n'
                response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',imageload_condition_format.encode('utf-8'),'n')
                #print json.dumps(response_new_condition) + '\n' 
            if sha256 != '' :
                vt_result = reqvirustotal.convert_sha256_to_md5_from_vt(sha256) 
                if vt_result != 'Not Found VTReport' :
                    processmd5_condition_format = u'{"tests": [{"operator": "equal","token": "processEvent/md5", "type": "md5", "value": "%s"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "ccSvcHst.exe"}]}'%vt_result
                    response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',processmd5_condition_format.encode('utf-8'),'n')
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err

    #description :  logstat에서 전달 받은 symantec 로그 파싱 함수
    def parsing_symantec(self,device,category,args):
        try:

            if 'filepath' in args :
                sha256 = ''
                if 'hash' in args : sha256 = args['hash']
                elif 'app_hash' in args : sha256 = args['app_hash']
                if 1==2 :
                #if len(args['filepath']) > 10 and args['filepath'].lower().find('windows/system32') == -1 and args['filepath'].lower().find('windows\\system32') == -1: 
                    self.create_condition_for_detected_file_by_symantec(args['filepath'],sha256)   
            
            if category.lower() == 'threats' :
                event_time = convert_timeformat(args['time'])
                alertdatetime1 = convert_timeformat(args['alertdatetime1'])
                computer_name = args['computer_name']
                user_name = args['user_name']
                ipaddr = args['ip_addr1_text']
                event = ('Symantec THREATS : ' + args['virusname'] + '<br>')
                event += 'app_hash : ' + '<a href="https://www.virustotal.com/#/file/%s/detection" target=_blank>'%args['app_hash']  + args['app_hash'] + '</a><br>'  + 'filepath : ' + args['filepath'] + '<br>' 
                event += 'downloader : ' + args['downloader'] + '<br>' + 'url : ' + args['url'] + '<br>'
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            elif category.lower() == 'ntp' :
                if args['event_name'].lower().find('port scan') > -1 :
                    if args['traffic_direction'].lower().find('inbound') > -1: ipaddr = args['remote_host_ip_text']
                    else : ipaddr = args['ip_addr1_text']
                elif args['event_name'].lower().find('active response') > -1 :
                    return  {"state":"error","message":"nothing_matches"}
                else : #args['event_name'].lower().find('intrusion') > -1 :
                    if args['event_desc'].lower().find('bruteforce attempt') > -1 and args['traffic_direction'].lower().find('inbound') > -1 : 
                        ipaddr = args['remote_host_ip_text']
                    else : ipaddr = args['ip_addr1_text']
                event_time = convert_timeformat(args['time'])
                alertdatetime1 = convert_timeformat(args['begin_time'])
                computer_name = args['computer_name']
                user_name = args['user_name']
                if args['event_name'].find('Port Scan') > -1 : event = ('Symantec NTP : ' + args['str_cids_sign_id'] + ' Port Scan<br>' )
                else : event = ('Symantec NTP : ' + args['str_cids_sign_id'] + '<br>')
                event += 'event_name : ' + args['event_name'] + '<br>' + 'remoteIP : ' + args['remote_host_ip_text'] + '<br>' + 'traffic_direction : ' + args['traffic_direction'] + '<br>'  
                event += 'app_name : ' + args['app_name'] + '<br>' + 'event_desc : ' + args['event_desc'] + '<br>' + 'intrusion_url : ' + args['intrusion_url'] + '<br>'
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            elif category.lower() == 'sonar' :
                event_time = convert_timeformat(args['time'])
                alertdatetime1 = convert_timeformat(args['alertdatetime1'])
                computer_name = args['computer_name']
                user_name = args['user_name']
                # ipaddr = args['source_computer_ip_text'] # why all values was 0.0.0.0 ?
                ipaddr = ''
                event = ('Symantec SONAR : ' + args['virusname_help'] + '<br>')
                event += 'app_name : ' + args['app_name'] + '<br>' +  'web_domain : ' + args['web_domain'] + '<br>' 
                event += 'filepath : ' + args['filepath'] + '<br>' + 'hash : ' + '<a href="https://www.virustotal.com/#/file/%s/detection" target=_blank>'%args['hash']  + args['hash'] + '</a><br>' + 'downloader : ' + args['downloader'] + '<br>' + 'url : ' + args['url'] + '<br>'
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            else : 
                result = {"state":"okay","message":"nothing_matches"}
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err


    #description : fortinet antivirus 로그 파싱 함수 / fortinet 로그는 es_daemon.py 에서 주기적으로 요청
    def parsing_fortinet(self,device,category,args):
        try :            
            event_time = convert_timeformat(args['date'] + 'T' + args['time'] + '.00')
            alertdatetime1 = event_time
            computer_name = ''
            user_name = ''
            event = 'Fortinet AntiVirus : '
            ipaddr = args['srcip']
            if 'virus' in args : event +=  args['virus'] + '<br>'
            if 'url' in args : event += 'url : ' + args['url'] + '<br>' 
            if 'filename' in args : event += 'filename : ' + args['filename'] + '<br>' 
            if 'direction' in args : event += 'direction : ' + args['direction'] + '<br>' #here
            event += 'src ip / port : ' + args['srcip'] + ' : ' + args['srcport'] +'<br>'
            event += 'dst ip / port : ' + args['dstip'] + ' : ' + args['dstport'] +'<br>'
            if 'action' in args : event += 'action : ' + args['action'] + '<br>' 
            if 'service' in args : 'service : ' + args['service'] + '<br>'
            if 'reference' in args : event += 'reference : ' + args['ref'] + '<br>'
            if self.isduplicated_event(device,alertdatetime1,event,ipaddr) == True : 
                return {"state":"okay","message":"same event was exists"}
            result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            if str(result).find('not_found') > -1 :
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,args['dstip'],event)
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err

    #description : 원격접속자 triage 요청 : from 원격접속 미설치 체크 로직
    def parsing_remote_connection(self,device,category,args):
        try :
            result = {"state":"okay","message":"not_found_agent_false"}
            limitnum = 10
            event_time = datetime.datetime.today().strftime("%Y-%m-%dT%H:%M:%S")
            alertdatetime1 = event_time
            if len(args['users']) > limitnum : return {"state":"okay","message":"too much users"}
            for item in args['users']:
                item = item.split(',')
                ipaddr , user_name , computer_name = item[0] , item[1] , ''
                if user_name == 'FW_chiePC' : continue
                event = 'Remote Access : %s %s'%(ipaddr,user_name)
                if self.isduplicated_event(device,alertdatetime1,event,ipaddr) == True : continue
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err

    def isduplicated_event(self,device,alertdatetime1,event,ipaddr):
        con = dbconn()
        cursor = con.cursor()
        rows = cursor.execute('select * from reqtriage where device = \'{}\' and alertdatetime1 = \'{}\' and event = \'{}\' and ipaddress = \'{}\''.format(device,alertdatetime1,event,ipaddr))
        rows = cursor.fetchall()
        if len(rows) > 0 : return True
        else : return False

    #description :  post 메소드 정의
    def post(self):
        try:
            request.data = re.sub(r'null','""',request.data)
            passive_traige_request.info(str(request.data))
            bypass_category = []
            if  bool(re.search("'",request.data)) : request.data = request.data.replace("'",'') #return {"state":"error","message":"do not include single quote"}
            #args = self.parser.parse_args()
            #restful 에서 request.data 으로 변경
            device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event = '','','','','','','',''
            args = json.loads(request.data,encoding='utf-8')
            if 'device' in args : device = args['device']
            else : device = 'symantec'
            category = args['category']
            if category.lower() in bypass_category : return {"state":"okay","message":"Bypass category %s"%category}
            # device 추가 시 해당 device event log parsing 작업 추가필요
            if device == 'symantec' and ISDISABLE == 'FALSE' : 
                result = self.parsing_symantec(device,category,args)
            elif device == 'fortinet' and ISDISABLE == 'FALSE' :
                if 'srcip' not in args or 'dstip' not in args or 'direction' not in args or 'srcport' not in args or 'dstport' not in args :
                    result = {"state":"error","message":"not found fortinet important fields"}
                else : result = self.parsing_fortinet(device,category,args)
            elif device == 'remotecon' and ISDISABLE == 'FALSE' :
                result = self.parsing_remote_connection(device,category,args) 
            else : 
                result = {"state":"error","message":"not defind device %s"%device}
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err

    #description : computer_name , ipaddress 를 받아 Triage 요청
    def request_triage(self,device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event):
        try :
            if 'symantec ntp' in event.lower() and bool(re.search(u'-\d{3,4}|\.cafe24\.com|systemrestore-winw',computer_name.lower())) == True : return {"state":"okay","message":"This Event Was Passed"}
            elif '**summarized data**' in event.lower() : return {"state":"okay","message":"This Event Was Passed"}
            rulename = event.split('<br>')[0]
            for i in IGNORED_TAG :
                if bool(re.search(i.lower(),event.lower())) == True :
                    comment = '<font color="white"><strong>Ignored Event</strong></font>'
                    self.insert_triage(str(datetime.datetime.utcnow()),'','','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,'Null','false',event,comment,rulename)
                    return {"state":"okay","message":"This Event Was Passed"}
            maru_restIsSessionValid()
            # (state: '<NEW|ERROR|QUEUED|RUNNING|COMPLETE|FAILED>')
            # new (이미 요청을 한 호스트를 다시 triage 요청한 경우) , queued (requested) , running (acquring) 
            aquaring = request_hx(maru_token['token'],HXSRV_ACQS,'?sort=request_time+descending&limit=100','GET',None)
            queued = 0
            for host in aquaring['data']['entries'] :
                if host['state'] in ['QUEUED','RUNNING','NEW'] :
                    # print host['state']
                    queued += 1
            # 전달받은 computer_name & ipaddress 의 두 조건이 모두 일치하는지 확인하여 agent_id 리턴
            #print device + category + computer_name + ipaddr
            agent_id = self.check_host(maru_token['token'],device,category,computer_name,ipaddr)
            # 대상 host에 triage 생성 요청
            if str(agent_id).find('false') == -1 :
                if queued < MAX_QUEUE :
                    maru_restIsSessionValid()
                    result = request_hx(maru_token['token'],HXSRV_HOSTS,'/' + agent_id + '/triages','POST',None)
                    triage_id = str(result['data']['_id'])
                    # for bulktest must modify
                    #result = str(datetime.datetime.now())
                    #triage_id = result
                    
                    maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
                    # insert db req_success = "true"
                    self.insert_triage(triage_id,'passive','QUEUED','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,agent_id,'true',event,'<font color="white">NotYet</font>',rulename)
                else : 
                    self.insert_waitreqtriage(request.data)
                    result =  {"state":"okay","message":"limited_running_state_false"}
            else : # not found agent_id , send sms?
                comment = ''
                if str(agent_id).find('not_found') > -1 : 
                    comment = '<font color="red"><strong>NotFoundAgent</strong></font>'
                    self.insert_triage(str(datetime.datetime.utcnow()),'','','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,'Null','false',event,comment,rulename)
                elif str(agent_id).find('duplicated') > -1 : 
                    # if duplicated , add row ?  or add only event message ? 
                    '''
                    con = dbconn()
                    cursor = con.cursor()
                    rows = cursor.execute('select event,triage_id from reqtriage where computer_name = \'{0}\' order by request_time desc limit 1'.format(computer_name))
                    rows = cursor.fetchall()
                    before = rows[0][0]
                    triage_id = rows[0][1]
                    event = event.replace('\r\n','<br>')
                    if before.find(event) == - 1:
                        event = before + '<br>' + event
                        cursor.execute('update reqtriage set event = \'{0}\' where triage_id = \'{1}\''.format(event,triage_id))
                    con.commit()
                    con.close()
                    '''
                    comment = '<font color="white">duplicated request</strong></font>'
                    self.insert_triage(str(datetime.datetime.utcnow()),'','','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,'Null','false',event,comment,rulename)
                result = agent_id
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

    #description : 전달받은 computer_name or ipaddress 로 Triage_ID 를 검색
    # api 로 computer_name 검색 시 equal 이 아닌 like 옵션이 적용되어 검색값이 여러 개 나올 수 있어 ip address 체크 (X)
    # 또는 검색 결과 리스트의 hostname을 computer_name 과 같은지 다시 체크 (O)
    # 동일한 computer_name 이 존재 할 수 있어 last audit time 옵션 설정
    def check_host(self,token,device,category,computer_name,ipaddr):
        check_only_ipaddress = ['ntp','fortinet','remote_connection'] # IP로 검색해야 하는 카테고리
        try:
            iplist = []
            result = {"state":"okay","message":"not_found_agent_false"}
            if device.lower() != 'fireeye' and ISDISABLE != 'FALSE' : return result
            maru_restIsSessionValid()
            # get agent_id from computer_name or ipaddress 
            search_url = '?search=' + computer_name + '&sort=last_poll_timestamp+descending&limit=100'
            search_url = urllib.parse.urlparse(search_url)
            search_url = urllib.parse.parse_qs(search_url.query)
            search_url = '?' + urllib.parse.urlencode(search_url,doseq=True)
            print search_url
            # get agent_id from computer_name or ipaddress 
            if computer_name != '' : # and category.lower() not in check_only_ipaddress : 
                response = request_hx(token,HXSRV_HOSTS,search_url,'GET',None)
                #print json.dumps(response,ensure_ascii=False,indent=2)
                if response['data']['total'] == 0 : 
                    return {"state":"okay","message":"not_found_agent_false"}
                for entry in response['data']['entries'] :
                    print entry['hostname']
                    if computer_name.lower() == entry['hostname'].lower() :
                        if self.check_last_triage_time(entry['_id'],device,category) == True : 
                            result = entry['_id']
                        else : result = {"state":"okay","message":"req_duplicated_false"}
                        break
                    else : result = {"state":"okay","message":"not_found_agent_false"}
            elif ipaddr != '' :
                response = request_hx(token,HXSRV_HOSTS,'?search=' + ipaddr + '&sort=last_poll_timestamp+descending&limit=200','GET',None)
                #print json.dumps(response,indent=4)
                if response['data']['total'] == 0 : 
                    return {"state":"okay","message":"not_found_agent_false"} 
                for entry in response['data']['entries'] :
                    if ipaddr == entry['last_poll_ip'] or ipaddr == entry['primary_ip_address'] :
                        if self.check_last_triage_time(entry['_id'],device,category) == True : 
                            result = entry['_id']
                        else : result = {"state":"okay","message":"req_duplicated_false"}
                        break
                    else : result = {"state":"okay","message":"not_found_agent_false"}
                '''
                for netinfo in sysinfo['data']['networkArray']['networkInfo'] :
                    if netinfo.has_key('ipArray') :
                        if netinfo['ipArray'].has_key('ipInfo') :
                            for ipinfo in netinfo['ipArray']['ipInfo'] :
                                if ipinfo.has_key('ipAddress') :
                                    ip = ipinfo['ipAddress']
                                    if ip.find('127.0.0.1') == -1 and ip.find('169.254') == -1 :
                                        iplist.append(ip)
                if ipaddr in iplist :
                    if self.check_last_triage_time(entry['_id'],device,category) == True :
                        result = entry['_id']
                else : result = 'check_last_triage_time_false'
                '''
            return result
            #allhost = request_hx(maru_token,HXSRV_HOSTS,'?limit=10000','GET',None,'yes')
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

    # 특정 시간 동안 동일 호스트의 Passive Triage 를 요청하는 케이스 제한 (not use hx server request_time)
    def check_last_triage_time(self,agent_id,device,category):
        try:
            #response = request_hx(maru_token['token'],'/hx/api/v3/acqs/triages','?sort=request_time+descending&search={0}&limit=1'.format(agent_id),'GET',None)
            #maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
            if 1==2 : #response['data']['total'] == 0 :
                return True
            else :
                #reqtime = response['data']['entries'][0]['request_time'].replace('T',' ').replace('Z','')
                reqtime = self.get_reqtime(agent_id,device,category)
                if reqtime.find('false') > -1 : return True
                reqtime = convert_timeformat(reqtime)
                #duration = (datetime.datetime.utcnow() - datetime.datetime.strptime(reqtime, '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
                duration = (datetime.datetime.utcnow() - datetime.datetime.strptime(reqtime, '%Y-%m-%d %H:%M:%S')).seconds / 60
                #print 'duration %s' %str(duration)
                return(duration > MAX_DURATION)
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

    #description :  insert triage info 
    def insert_triage(self,triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment,rulename):
        try:
            if triage_id.find('Null') > -1 : downlink = ''
            elif triage_id.find('.') > -1 : downlink = ''
            else: downlink = '<a href ="{0}/es_query_result/stored_triage_files/{1}" target="_blank"><font color="white">{2}.mans</font></a>'.format(hxtool_srv,triage_id,triage_id) 
            con = dbconn()
            cursor = con.cursor()
            if DBTYPE == 'mariadb':
                event = event.replace('\\','/')
                cursor.execute('insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\',NULL,NULL,NULL,\'{16}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment,rulename))

            else :
                cursor.execute('insert or ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment))
                
            con.commit()
            con.close()
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
    #description :  insert wait req , 최대치 triage 요청인 경우 table 저장 후 다시 요청
    def insert_waitreqtriage(self,postbody) :
        try:
            con = dbconn()
            cursor = con.cursor()
            if DBTYPE == 'mariadb' :cursor.execute('insert ignore into waitreqtriage values(\'{0}\')'.format(postbody))
            else : cursor.execute('insert or ignore into waitreqtriage values(\'{0}\')'.format(postbody))
            con.commit()
            con.close()
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
    
    # category : db에서 triage request time 검색
    def get_reqtime(self,agent_id,device,category):
        try: 
            con = dbconn()
            cursor = con.cursor()
            # 동일 device , category 이벤트가 특정시간 동안 여러개 triage 요청 들어오면 이벤트 컬럼만 업데이트 하고 triage 요청하지 않음 (현재는 device , 시간만 체크로 변경)
            #rows = cursor.execute('select request_time from reqtriage where (agent_id = \'{0}\' and req_success = "true" and device = \'{1}\' and category = \'{2}\') order by request_time desc limit 1'.format(agent_id,device,category))
            rows = cursor.execute('select request_time from reqtriage where (agent_id = \'{0}\' and req_success = "true" and device = \'{1}\') order by request_time desc limit 1'.format(agent_id,device))
            rows = cursor.fetchall()
            con.close()
            if len(rows) == 0 :
                return 'get_reqtime_false'
            else :
                return rows[0][0]
            con.close()
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

api.add_resource(ReqTriage, '/reqtriage')

# maru flask area
# triage 파일 다운로드 함수
@app.route('/es_query_result/stored_triage_files/<triageid>')
@valid_session_required_maru #maru
def get_passive_triage_file(triageid):
    try:
        maru_restIsSessionValid()
        response =  download_triage(maru_token['token'],'/hx/api/v3/acqs/triages/{0}.mans'.format(triageid))
        if response.find('Not Found') == -1 :
            response = response.split('/')[-1]
            result = '<a href= "{0}/es_query_result/passive_triage_files/{1}">Download {2}</a>'.format(hxtool_srv,response,response)
            result += '<br><a href= "{0}/es_query_result/passive_triage_files/">All Passive Files In HXTools Server</a>'.format(hxtool_srv)
            #return result
            return redirect('{0}/es_query_result/passive_triage_files/{1}'.format(hxtool_srv,response,response))
        else : return response
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : triage list view 메인페이지
@app.route('/es_query_result/triage_list/<type>',methods=['POST','GET'])
@valid_session_required_maru #maru
def triage_list(type) :
    try:
        html = '<html><head><meta http-equiv="p3p" content=\'CP="CAO DSP AND SO" policyref="/w3c/p3p.xml"\'>'
        con = dbconn()
        cursor = con.cursor()
        includesrv = False
        if type == 'ls' :
            if not 'page' in request.args : page = 0
            else : page = int(request.args.get('page'))
            #html += '<script>setTimeout("location.reload()",60000)</script>'
            #rows = cursor.execute('select triage_id,req_type,state,downlink,device,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where req_success = "true" order by cast(triage_id as unsigned) desc limit %d'%MAX_VIEW_LIST_NUM)
            rows = cursor.execute('select triage_id,req_type,state,downlink,device,request_time,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage  order by request_time desc limit %d , %d'%(page*MAX_VIEW_LIST_NUM,MAX_VIEW_LIST_NUM))
            rows = cursor.fetchall()
            con.close()
        elif type == 'search' :
            if request.method == 'POST':
                keyword = request.form['keyword']
                field = request.form['searching_field']
                if not 'page' in request.form.keys() : page = 0
                else : page = int(request.form['page'])
            else : 
                if not 'page' in request.args : page = 0
                else : page = int(request.args.get('page'))
                keyword , field = request.args.get('keyword') , request.args.get('field')
                if 'includesrv' in request.args : includesrv = True
            if field == 'event' and 'symantec' in keyword.lower() :
                if includesrv != True :
                    search_sql = 'select triage_id,req_type,state,downlink,device,request_time,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where {0} like \'%{1}%\' and computer_name not regexp "(cafe24.com|-[0-9][0-9][0-9])" order by request_time desc limit {2},{3}'.format(field,keyword,page*MAX_VIEW_LIST_NUM,MAX_VIEW_LIST_NUM)
                else :
                    search_sql = 'select triage_id,req_type,state,downlink,device,request_time,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where {0} like \'%{1}%\' and computer_name regexp "(cafe24.com|-[0-9][0-9][0-9])" order by request_time desc limit {2},{3}'.format(field,keyword,page*MAX_VIEW_LIST_NUM,MAX_VIEW_LIST_NUM)
            else :
                search_sql = 'select triage_id,req_type,state,downlink,device,request_time,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where {0} like \'%{1}%\' order by request_time desc limit {2},{3}'.format(field,keyword,page*MAX_VIEW_LIST_NUM,MAX_VIEW_LIST_NUM)
            rows = cursor.execute(search_sql)
            rows = cursor.fetchall()
            con.close()
        # html style
        html += '''
        <title>Threat Hunting - Cafe24</title></head>
        <style>body {margin: 0;background-color:#222222;}
        #fixed-menu{
        width: 100%;
        background-color:#222222;
        color:white;        
        position: fixed;
        top: 0px;
        left: 0px;
        }
        #main-content {
        background-color:#222222;
        color:white;
        width: 100%;
        margin-top: 100px;
        }
        #fixed-menu li {
        display: inline-block;
        margin-right: 30px;
        }
        img {
        max-width: 100%;
        }
        </style>
        <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: blue;
        }

        li {
            float: left;
        }

        li a, .dropbtn {
            display: inline-block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover, .dropdown:hover .dropbtn {
            background-color: red;
        }

        li.dropdown {
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }

        .dropdown-content a:hover {background-color: #f1f1f1}

        .dropdown:hover .dropdown-content {
            display: block;
        }
        </style>
        <div id="fixed-menu">
        <style> * {margin:0px;padding:0px;}</style>
        <form action="/es_query_result/triage_list/search" method="post">
        <input type="text" name="keyword"> 
        <select name="searching_field">
        <option value="computer_name">computername</option>
        <option value="ipaddress">ipaddress</option>
        <option value="alertdatetime1">alerttime</option>
        <option value="device">device</option>
        <option value="comment">comment</option>
        <option value="event" selected="selected">event</option>
        </select>
        <input type="submit" value="Search" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;">
        </form>
        <br>
        <!-- <script>setTimeout("location.reload()",180000)</script> -->
        <ui>
        <strong>              
         <li><a href="/es_query_result/triage_list/ls" style="text-decoration:none">All EVT</a></li>
         <li><a href="https://123.140.249.57:8080/" style="text-decoration:none" target=_blank>DashBoard</a> </li>         
         <li><a href="/es_query_result/triage_list/search?keyword=fireeyehx&field=device" style="text-decoration:none">FireeyeHX</a> </li>
         <!-- <li><a href="/es_query_result/triage_list/search?keyword=sentinelone&field=device" style="text-decoration:none">SentinelOne</a> </li> -->
         <li><a href="/es_query_result/triage_list/search?keyword=cpay&field=device" style="text-decoration:none">CPAY</a> </li>
         <li><a href="/es_query_result/triage_list/search?keyword=fortinet&field=device" style="text-decoration:none">ForitNet</a> </li>
         <li><a href="/es_query_result/triage_list/search?keyword=noalarm&field=device" style="text-decoration:none">NoAlarm</a> </li>
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">Symantec</a>
            <div class="dropdown-content">
              <a href="/es_query_result/triage_list/search?keyword=Symantec%20Threats&field=event">SEP Threats(User)</a>
              <a href="/es_query_result/triage_list/search?keyword=Symantec%20Sonar&field=event">SEP Sonar(User)</a>
              <a href="/es_query_result/triage_list/search?keyword=Symantec%20NTP&field=event">SEP NTP(User)</a>
              <a href="/es_query_result/triage_list/search?keyword=Symantec%20Threats&field=event&includesrv=true">SEP Threats(SRV)</a>
              <a href="/es_query_result/triage_list/search?keyword=Symantec%20Sonar&field=event&includesrv=true">SEP Sonar(SRV)</a>
              <a href="/es_query_result/triage_list/search?keyword=Symantec%20NTP&field=event&includesrv=true">SEP NTP(SRV)</a>
            </div>
        </li>           
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">Results</a>
            <div class="dropdown-content">
              <a href="/es_query_result/triage_list/search?keyword=%5B+Threat+%5D&field=comment">Threat</a>
              <a href="/es_query_result/triage_list/search?keyword=%5B+noproblem+%5D&field=comment">NoProblem</a>
              <a href="/es_query_result/triage_list/search?keyword=NotYet&field=comment">NotYet</a>              
            </div>
        </li>
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">Triages</a>
            <div class="dropdown-content">
              <a href="/es_query_result/search_triage" target=_blank>Triage String 검색</a>
              <a href="http://123.140.249.57:8501" target=_blank>TriageAnalyzer</a>
            </div>
        </li>           
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">API</a>
            <div class="dropdown-content">
              <a href="/esfromtext" target=_blank>ES With IOC</a>
              <a href="/es_query_result/hxhealth" target=_blank>HXHealth</a>
              <a href="/daily_report" target=_blank>dailyRPT</a>
            </div>
        </li>                           
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">Agents</a>
            <div class="dropdown-content">
              <a href="/hosts_info" target=_blank>AgentList</a>
              <a href="/es_query_result/triage_list/search?keyword=NotFoundAgent&field=comment">NotFound</a>
              <a href="/es_query_result/triage_list/search?keyword=remote%20access&field=event&includesrv=true">RDP접속자</a>              
            </div>
        </li>              
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">Graph</a>
            <div class="dropdown-content">
              <a href="/graph/hx_daily_event_num?where=" target=_blank>DailyEvent</a>
              <a href="/graph/hx_monthly_event_name?where=" target=_blank>EventName</a>
              <a href="/graph/hx_host_num?where=" target=_blank>Host</a>
              <a href="/graph/osint_ioc_num?where=" target=_blank>OSINT</a>
              <a href="/graph/osint_ioc_tag?where=" target=_blank>MalTrend</a>
              <a href="/graph/highgraph?when=" target=_blank>수치고도화</a>
            </div>
        </li>   
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn"> OSINT </a>
            <div class="dropdown-content">
              <a href="https://www.virustotal.com" target=_blank>VirusTotal</a>
              <a href="https://otx.alienvault.com" target=_blank>Alienvault</a>
              <a href="https://www.onyphe.io/" target=_blank>onyphe</a>
              <a href="https://urlscan.io/" target=_blank>urlscan</a>
              <a href="/osintdb/ls" target=_blank>OSINT DB</a>
            </div>
        </li> 
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">SecDevice</a>
            <div class="dropdown-content">
              <a href="https://112.175.67.137:3000" target=_blank>FireeyeHX</a>
              <a href="https://112.175.50.61/p/login/" target=_blank>FortiAnalyzer</a>              
              <a href="https://log-stat-web.cafe24.com/v2.php/security/sepm2" target=_blank>Symantec</a>
              <a href="https://system.simplexi.com/new_board/board_list.php?show_b_type=61&show_b_nm=%BA%B8%BE%C8%C3%BC%C5%A9&show_b_sub_type=298" target=_blank>SystemTeam</a>
              <a href="https://data-eye.hanpda.com/private_grafana/d/5me4uE1Zk/2-process-event?orgId=5&refresh=2h" target=_blank>CafeMon</a>
              <a href="https://data-eye.hanpda.com/grafana/d/pHcattqZz/mchecker-from-file-server?orgId=1&refresh=5m" target=_blank>MChecker</a>
            </div>
        </li>           
        <li><a href="/logout" style="text-decoration:none">LogOut</a></li>
         </strong>
        </ui></div>
         <div id="main-content">
         <style type="text/css">
         .evtTable { background-color:#222222;color:white;border-collapse:collapse;table-layout:fixed;font-size:15px }
         .etvTable th { background-color:#2f2f2f;color:white; }
         .evtTable td { background-color:#2f2f2f;color:white; }
         .evtTable tr.mover:hover { background-color: #81BEF7; }
         </style>
         <a href="/es_query_result/graph/event_wordcloud_large.png" target=_blank>
        <center> <img src="/es_query_result/graph/event_wordcloud.png" title="Weekly Event WordCloud (NO NTP). Click for Monthly Events" style="max-width: 100%; height: auto;"></center>
         </a>
         <iframe src="/es_query_result/graph/events_via_device.html" width=48% height=35% scrolling="no"></iframe>
         <iframe src="/es_query_result/topusers" width=20% height=35% scrolling="yes"></iframe>
         <iframe src="/es_query_result/events" width=30% height=35% scrolling="yes"></iframe>
         <table class="evtTable" border="1" cellspacing="0">
         <colgroup><col width="3%"><col width="3%"><col width="3%"><col width="4%"><col width="6.5%"><col width="6.5%"><col width="5%"><col width="35%"></colgroup>
        <tr >
        <th>TriageID<p>Report</th><th>Req Info</th><th>Download</th><th>Device</th><th>RequestTime(utc0)</th><th>AlertTime(utc0)</th><th>User Info</th><th>Event Message</th><th>Comment</th>
        </tr>
        '''
        for row in rows :
            #if 'test_event' in str(row) : continue
            html += '<tr class="mover" style="font-size:12px;" onMouseOver=bgColor="#81BEF7" onMouseOut=bgColor="" bgcolor="#FBFAFA">'
            for idx,item in enumerate(row) :
                if idx == len(row) - 1 : # last index = submit comment / row[0] = triage_id
                    html += ' <td  style="word-break:break-all;border: 1px solid #81BEF7;">{0}<br><form action="{1}" method="get" target="print_popup" onsubmit="window.open(\'about:blank\',\'print_popup\',\'width=1050,height=850\');"><div><div style="display:inline;width:200px;"> <input type="submit" value="Write" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form></td>'.format(item,hxtool_srv + '/write_proc/%s'%row[0])
                elif idx== len(row) -2 : # event message
                    eventname = item.split('<br>')[0] + '<br>'
                    tmp = check_interesting_event(eventname)
                    item = item.replace(eventname,tmp)
                    html += '<td width=600 style="word-break:break-all;border: 1px solid #81BEF7;">' + item + '</td>' 
                elif idx == 1: html += '<td style="border: 1px solid #81BEF7;" ><a href = "/es_query_result/triage_list/search?keyword=%s&field=req_type" style="text-decoration:none"><font color="white">'%item + item + '</font></a>' #req_type
                elif idx == 2: html += '<br><a href = "/es_query_result/triage_list/search?keyword=%s&field=state" style="text-decoration:none"><font color="white">'%item + item + '</font></a></td>' # state
                elif idx == 4: html += '<td style="border: 1px solid #81BEF7;" ><a href = "/es_query_result/triage_list/search?keyword=%s&field=device" style="text-decoration:none"><font color="white">'%item + item + '</font></a></td>' #device
                elif idx == 5 : html += '<td style="border: 1px solid #81BEF7;" ><font color="white">' + item.replace(' ','T') + '</font></td>' # request_time
                elif idx == 6: #alertdatetime1
                    if str(datetime.datetime.now(tz=pytz.utc)).split(' ')[0] in item :
                        html += '<td style="border: 1px solid #81BEF7;" ><strong><font color="white">' + item.replace(' ','T') + '</font><br><font color="yellow">Today</font></strong></td>'
                    elif str(datetime.datetime.now(tz=pytz.utc) - datetime.timedelta(days = 1)).split(' ')[0] in item : 
                        html += '<td style="border: 1px solid #81BEF7;" ><strong><font color="white">' + item.replace(' ','T') + '</font><br><font color="green">Yesterday</font></strong></td>'
                    else : html += '<td style="border: 1px solid #81BEF7;" ><font color="white">' + item.replace(' ','T') + '</font></td>'
                elif idx == 7: html += '<td style="border: 1px solid #81BEF7;" ><a href = "/es_query_result/triage_list/search?keyword=%s&field=computer_name" style="text-decoration:none"  title="searching computername"><font color="white">'%item + item + '</font></a>' #computer_name
                elif idx == 8: html += '<br><a href = "/es_query_result/triage_list/search?keyword=%s&field=ipaddress" style="text-decoration:none" title="searching ipaddress"><font color="white">'%item + item + '</font></a></td>' # ipaddress
                elif idx == 0: # triage_id
                    reportstr = ''
                    reportcon = sqlite3.connect('/home/apps/hxtool/HXTool-3.0/hashdb')
                    reportcursor = reportcon.cursor()
                    reportcursor.execute('select alarm from maxav_alarm where triage_id = "%s"'%item)
                    reportrow = reportcursor.fetchone()
                    if reportrow != None : reportstr = '<a href = "/es_query_result/triage_list/req_maxav?triage_id=%s" style="text-decoration:none" title="auto triage analyzer report" target="_blank"><font color="yellow"> Report</font></a>'%item
                    reportcon.close()                       
                    html += '<td style="border: 1px solid #81BEF7;" ><br><font color="white">' + item + '</font>' + reportstr + '</td>' # if click > query maxav 
                else : html += '<td style="border: 1px solid #81BEF7;" ><font color="white">' + item + '</font></td>'
            html += '</tr>'
        html += '</table></div><strong><center>'
        current_url = request.url
        print(current_url)
        pagelist = ''
        if type == 'ls' : current_url = current_url.split('?page')[0]
        else : 
            if type == 'search' :
                if request.method == 'POST':
                    current_url = current_url + '?keyword=' + request.form['keyword'] + '&field=' + request.form['searching_field']
                else : current_url = current_url.split('&page')[0]
        for i in range(page,page + 5) :
            if type == 'ls' : pagelist += ' <a href="%s" style="text-decoration:none"><font color="white">[ %d ] </font></a>'%(current_url + '?page=%d'%i,i)
            else : pagelist += ' <a href="%s" style="text-decoration:none"><font color="white">[ %d ] </font></a>'%(current_url + '&page=%d'%i,i)
        if page == 0 :
            if type == 'ls' : current_url = current_url + '?page=%d'%(page + 1)
            else : current_url = current_url + '&page=%d'%(page + 1)
            html += pagelist + '<a href="%s" style="text-decoration:none"><font color="white">Priv >> </font></a>'%current_url
        else :
            if type == 'ls' : 
                html += '<a href="%s" style="text-decoration:none"><font color="white"> << Next </font></a>'%(current_url + '?page=%d'%(page - 1)) 
                html += pagelist 
                html += '<a href="%s" style="text-decoration:none"><font color="white">Priv >> </font></a>'%(current_url + '?page=%d'%(page + 1))
            else : 
                html += '<a href="%s" style="text-decoration:none"><font color="white"> << Next </font></a> '%(current_url + '&page=%d'%(page - 1))
                html += pagelist 
                html += '<a href="%s" style="text-decoration:none"><font color="white">Priv >> </font></a>'%(current_url + '&page=%d'%(page + 1))
        html += '</center></strong><br><br><br></html>'
        app.logger.info(current_url + ' - User: %s',session['ht_user'])
        return html
        #return render_template('triage_list.html',rows = rows)
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))


#description : 지라 생성 함수 (이벤트 처리 지라의 하위 지라로 생성)
from jira import JIRA
def create_event_jira(report,worktime,lastcomment,reporter,groupwarepwd):
    try :
        SPLITTAG = '\r\n'
        now = datetime.datetime.today().strftime("%Y-%m-%d")
        #EVENT_ISSUE = 'SECURITY-23447' # 2018
        EVENT_ISSUE = 'SECURITY-37962' #2019
        #USER = 'yskim04'
        jira = JIRA('https://jira.simplexi.com',auth=(reporter,groupwarepwd))
        report_lines = report.split(SPLITTAG)
        print len(report_lines)
        summary , description , labels = '[SecurityEvent] ' , u'이벤트 발생 - ' , [u'is팀','SecurityEvent']
        for idx,line in enumerate(report_lines) :
            if idx == 0 : 
                if line.find('Threat') > -1 : 
                    summary += '*Threat* '
                    labels.append('threats')
                else : 
                    summary += '*NoProblem* '
                    labels.append('noproblem')
                summary += now + ' '
            elif line.find('Indicator') > -1 :
                line = line.replace('Indicator    :','')
                summary += line + ' '
                description += line
            elif line.find('ComputerName') > -1 : summary += line.replace('ComputerName :','')
        # create subtask
        subtask = {
            'project' : { 'key' : 'SECURITY' },
            'summary' : summary, # 변수
            'description' : description, # 변수
            'labels' : labels, # 변수
            'issuetype' : { 'name' : u'Sub_보안이슈' },
            'parent' : { 'key' : EVENT_ISSUE },
            'assignee' : { 'name' : reporter },
            'reporter' : {'name' : reporter },
            'customfield_15313' : now,
            'customfield_15314' : now,
            'duedate' : now
        }
        issue = jira.create_issue(fields=subtask)
        #print("created child: " + issue.key)
        # worklog 추가
        jira.add_worklog(issue, timeSpent="5m", user=reporter, comment= '확인완료\r\n' + report)
        #jira.add_comment(issue,checked) # comment 추가
        now = datetime.datetime.today().strftime("%Y-%m-%d")
        done_id = ''
        tr = jira.transitions(issue)
        for i in tr :
            if i['name'].lower() =='done':
                done_id = i['id']
                #print done_id
        if done_id != '' :
            jira.transition_issue(issue,done_id,comment = lastcomment, worklog=worktime,fields={'customfield_15313':now,'customfield_15314':now})
        return issue.key
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))        


def write_comment_event_jira(device,rule,computer_name,alerttime,worktime,summary,reporter):
    try :
        now = datetime.datetime.today().strftime("%Y-%m-%d")
        EVENT_ISSUE = 'SECURITY-58270'
        jira = JIRA('https://jira.simplexi.com',auth=('yskim04',BUG))
        issue = jira.issue(EVENT_ISSUE)
        comment = device + ' / ' + rule + ' / ' + alerttime + ' / ' + computer_name + ' / ' + summary + ' / ' + reporter
        # worklog 추가
        jira.add_worklog(issue, timeSpent="%sm"%worktime, user=reporter, comment= comment)
        #jira.add_comment(issue,checked) # comment 추가
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))      

@app.route('/write_proc/<triage_id>',methods=['GET'])
@valid_session_required_maru #maru
def write_proc(triage_id) :
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    #html = '<html><title>Write Comment</title>이벤트 처리 내역을 기입한 후 "쪽지&지라생성" 버튼을 클릭하세요.<br><br><form action="/write_comment" method="post"><input type="radio" name="result" value="[ Threat ];위협">위협<input type="radio" name="result" value="[ NoProblem ];비위협">비위협<input type="radio" name="result" value="[ Threat ];정책위반">정책위반<input type="radio" name="result" value="[ NoProblem ];IS팀테스트">IS팀테스트<br><br><textarea name="comment" cols="130" rows="20">[ 발생원인 ]\r\n\r\n\r\n[ 확인내역 ]\r\n\r\n\r\n[ 처리 내역 ]\r\n\r\n\r\n[ 처리 상태 ]\r\n완료/대기\r\n\r\n</textarea><div><div style="display:inline;width:200px;"><input type="hidden" name="triage_id" value="%s"><input type="submit" value="쪽지&지라생성" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form>'%triage_id
    html = '''
<html>
<title>Write Comment</title>
<body style="background-color:#222222;color:white">
이벤트 처리 내역을 기입한 후 "쪽지&지라생성" 버튼을 클릭하세요.<br><br>
<form action="/write_comment" method="post">
<input type="radio" name="result" value="[ Threat ];위협">위협
<input type="radio" name="result" value="[ NoProblem ];비위협">비위협
<input type="radio" name="result" value="[ Threat ];정책위반">정책위반
<input type="radio" name="result" value="[ NoProblem ];IS팀테스트">IS팀테스트<br><br>
<input type="checkbox" name="isnoupdate" value="noupdate">게시글만 작성 (지라,쪽지 생성하지 않기)<br><br>
분석 소요시간(분단위 : 5분이면 5 입력)<br>
<input type="text" name="worktime" size="40"><br>
분석 요약내용(예시 : 악성코드 탐지 / 평판정보 정상 , 오탐 확인 / 비위협)<br>
<input type="text" name="summary" size="40"><br>
분석가<br>
<input type="text" name="reporter" size="40" value="%s"><br><br>
<textarea name="comment" cols="120" rows="25">
[ 발생원인 ]\r\n\r\n\r\n[ 분석&처리 ]\r\n\r\n\r\n[ 처리 상태 ]\r\n완료\r\n\r\n</textarea>
<div>
<div style="display:inline;width:200px;">
<input type="hidden" name="triage_id" value="%s">
<input type="submit" value="쪽지&지라생성" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;">
</div>
</form>
</body>
    '''%(session['ht_user'],triage_id)
    return html

#description : 처리내역  & 지라 생성,삭제 함수
@app.route('/write_comment',methods=['POST'])
@valid_session_required_maru #maru
def write_comment() :
    try:
        app.logger.info(request.url + ' - User: %s',session['ht_user'])
        con = dbconn()
        cursor = con.cursor()
        #comment = re.escape(request.form['comment'])
        triage_id = request.form['triage_id']
        result_form = request.form['result'].split(';') # .replace('yyy','<font color="red">[ Threat ]</font>').replace('nnn','<font color="blue">[ NoProblem ]</font>')
        worktime = request.form['worktime']
        summary = request.form['summary']
        reporter = request.form['reporter']
        #groupwarepwd = request.form['groupwarepwd']
        isthreat = 'NoProblem'
        result = result_form[0].replace('[ Threat ]','<font color="red">[ Threat ]</font>').replace('[ NoProblem ]','<font color="blue">[ NoProblem ]</font>')
        desc = result_form[1]
        comment = request.form['comment'].replace('\\','/').replace("'","").replace('/>','/]')
        comment = result + u'\r\n[ 결과 ]\r\n' + desc + '\r\n\r\n' + comment
        if bool(re.search("'",comment)) == False and len(comment) < 2000 :
            rows = cursor.execute('select comment from reqtriage where triage_id = \'{0}\''.format(triage_id))
            rows = cursor.fetchall()
            before = rows[0][0]
            #cursor.execute('update reqtriage set comment = \'{0}\' where triage_id = \'{1}\''.format(comment.replace('\r\n','<br>'),triage_id)) #.format(before + '<br>' + comment.replace('\r\n','<br>'),triage_id))
            cursor.execute('update reqtriage set analyst =\'{}\' , comment = \'{}\' , summary = \'{}\' , spenttime = \'{}\' where triage_id = \'{}\''.format(reporter,comment.replace('\r\n','<br>') + '[ analyst : ' + reporter + ' ]<br>',summary,worktime,triage_id))
            con.commit()
            if comment.find('noupdate') > -1 or 'isnoupdate' in request.form : return '<script>window.close();</script>'
            rows = cursor.execute('select * from reqtriage where triage_id = \'{0}\''.format(triage_id))
            rows = cursor.fetchall()
            if comment.find('[ Threat ]') > -1 : 
                msg = '[ Security Event ] Closed (Threat) %s : analyst - %s\r\n\r\n'%(summary,reporter)
                isthreat = 'Threat'
            else : msg = '[ Security Event ] Closed (NoProblem) %s : analyst - %s\r\n\r\n'%(summary,reporter)
            for row in rows :
                alarm_event = re.sub('" target=.*</a>','',re.sub('<a href="',u'상세보기:',row[14].replace('<br>','\r\n')))
                rulename = alarm_event.split('\r\n')[0].split(':')[-1]
                msg += 'Comment      :' + comment + '\r\n' + '\r\n'
                msg += 'Indicator    :' + alarm_event + '\r\n' + '\r\n'
                msg += 'Triage ID    :' + row[0] + '\r\n' + '\r\n'
                msg += 'Device       :' + row[4] + '\r\n' + '\r\n'
                msg += 'AlertTime    :' + row[7] + '\r\n' + '\r\n'
                msg += 'ComputerName :' + row[9] + '\r\n' + '\r\n'
                msg += 'IPAddress    :' + row[11] + '\r\n' + '\r\n'
                msg += '사용자 Event 목록 : https://hx-tool.hanpda.com/es_query_result/triage_list/search?keyword={0}&field=computer_name'.format(row[9])
            #jira_key = create_event_jira(str(msg),worktime,summary,reporter,groupwarepwd)
            #msg += '\r\n\r\n' + '자동생성 지라 URL : ' + 'https://jira.simplexi.com/browse/' + jira_key

            write_comment_event_jira(row[4],row[9],row[7],rulename,worktime,summary,reporter)

            sendalarm(str(msg).replace('<br>',''),alarmreceiver)
            iamsalarm(str(msg).replace('<br>',''),IAMS_FIREEYE_ALERT_NUM,IAMS_FIREEYE_ALERT_APIKEY)
            con.close()
            #make_dataeye_json(comment,alarm_event,row[0],row[4],row[7],row[9],row[11],'https://jira.simplexi.com/browse/' + jira_key,isthreat,rulename)
            make_dataeye_json(comment,alarm_event,row[0],row[4],row[7],row[9],row[11],'',isthreat,rulename)
        else : return 'error : do not include single quote or limit 2000byte input size'
        #return redirect(url_for('triage_list',type='ls'))
        return '<script>window.close();</script>'
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))
        return (str(err))

def make_dataeye_json(comment,indicator,triageid,device,alerttime,computername,ipaddress,jiraurl,isthreat,rulename):
    try:
        dataeye = {'data':{}}
        logpath = '/opt/cafemon_test'
        if os.path.isdir(logpath) == False : os.mkdir(logpath)
        logdayf = 'cafemon_test_' + datetime.datetime.now().strftime('%Y%m%d')
        dataeye['data']['rulename'] = rulename.encode('utf-8')
        dataeye['data']['comment'] = comment.encode('utf-8')
        dataeye['data']['event'] = indicator.encode('utf-8')
        dataeye['data']['triageid'] =triageid
        dataeye['data']['device'] =  device
        dataeye['data']['alerttime'] =  alerttime
        dataeye['data']['computername'] = computername.encode('utf-8')
        dataeye['data']['ipaddress'] = ipaddress
        dataeye['data']['jira'] = jiraurl
        dataeye['data']['logtype'] = 'incident response'
        dataeye['data']['isthreat'] = isthreat
        dataeye['time'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(os.path.join(logpath,logdayf),'a') as log :
            log.write( json.dumps(dataeye,ensure_ascii=False) + '\n')        
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        passive_traige_error.error(str(err))


@app.route('/es_query_result/delete_comment/<triage_id>',methods=['POST','GET'])
@valid_session_required_maru #maru
def delete_comment(triage_id):
    try:
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('update reqtriage set comment = \'{0}\' where triage_id = \'{1}\''.format('',triage_id))
        con.commit()
        con.close()
        return redirect(url_for('triage_list',type='ls'))
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : 사용자 통계페이지 (24시간,한달)
@app.route('/es_query_result/topusers')
@valid_session_required_maru #maru
def topusers():
    con = dbconn()
    cursor = con.cursor()
    reqtime = convert_timeformat(str(datetime.datetime.utcnow())).split(' ')[0]
    if DBTYPE == 'sqlite' :
        sql1 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date("now", "-1 day") group by computer_name order by events desc'
        sql2 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date("now", "-1 month") group by computer_name order by events desc'
    else : 
        sql1 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 day) and event not like "%Remote Access%" and event not like "%Symantec NTP%" and computer_name not like "%cswebmail%" and computer_name not like "%test_event%" group by computer_name order by events desc'
        sql2 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 month) and event not like "%Remote Access%" and event not like "%Symantec NTP%" and computer_name not like "%cswebmail%" and computer_name not like "%test_event%" group by computer_name order by events desc'
    cursor.execute(sql1)
    rows = cursor.fetchall()
    html = '<html><title>Event Summary</title><strong><font color="yellow" >24Hours Event Users (NO NTP)</font></strong><br>'
    for row in rows :
        if len(row[1]) <  5 : continue
        html += '<font color="white" >' + str(row[0]) +'회 </font>' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=computer_name" style="text-decoration:none" target=_blank><font color="white" >{1}</font></a><br>'.format(row[1],row[1])
    cursor.execute(sql2)
    rows = cursor.fetchall()
    html += '<br><strong><font color="yellow" >Monthly Event Users (NO NTP)</font></strong><br>'
    for row in rows :
        if len(row[1]) <  5 : continue
        html += '<font color="white" >' + str(row[0]) +'회 </font>' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=computer_name" style="text-decoration:none" target=_blank><font color="white">{1}</font></a><br>'.format(row[1],row[1])
    html += '</html>'
    return html 

#description : 이벤트 통계 페이지 (24시간,한달)
@app.route('/es_query_result/events')
@valid_session_required_maru #maru
def events():
    con = dbconn()
    cursor = con.cursor()
    reqtime = convert_timeformat(str(datetime.datetime.utcnow())).split(' ')[0]
    #html ='<html><title>Event Summary</title>* Red != {0}<br>* Triage 요청 예외 항목 : {1}<br><br>'.format(RE_TAG,str(IGNORED_TAG))
    html ='<html><title>Event Summary</title>'
    if DBTYPE == 'sqlite' :
        sql1 = 'select count(*) as num,substr(event,1,pos-1) as firstevent from (select *,instr(event,"<br>") as pos from reqtriage where alertdatetime1 > date("now", "-1 day")) group by firstevent order by num desc'
        sql2 = 'select count(*) as num,substr(event,1,pos-1) as firstevent from (select *,instr(event,"<br>") as pos from reqtriage where alertdatetime1 > date("now", "-1 month")) group by firstevent order by num desc'
    else :  
        sql0 = 'select max(alertdatetime1) as maxdate,count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage test where request_time BETWEEN DATE_ADD(NOW() ,INTERVAL -14 day) AND NOW() and event not regexp("remote access|web attack|heur|malicious site") group by firstevent having (num < 4 or (num > 100 and firstevent not like "%NTP%")) order by maxdate desc limit 10;'
        sql1 = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 day) and event not like "%Remote Access%" and event not like "%Symantec NTP%" and computer_name not like "%cswebmail%" and computer_name not like "%test_event%" group by firstevent order by num desc;'
        sql2 = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 month) and event not like "%Remote Access%" and event not like "%Symantec NTP%" and computer_name not like "%cswebmail%" and computer_name not like "%test_event%" group by firstevent order by num desc'
        
    html += '<strong><font color="yellow" >Outlier Events (14days)</font></strong><br>'
    now = datetime.datetime.today().strftime("%Y-%m-%d")
    yesterday = (datetime.datetime.now() - datetime.timedelta(days = 1)).strftime("%Y-%m-%d")
    cursor.execute(sql0)
    rows = cursor.fetchall()
    for row in rows :
        msg = row[2].split('>')[-1]
        if now in str(row) or yesterday in str(row) : 
            html += '<font color="red" >' + str(row[0]).split(' ')[0] + ' ' + str(row[1]) +'회 </font>' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none" target=_blank><font color="red" >{1}</font></a><br>'.format(msg.split(' : ')[-1],msg)   
        else :
            html += '<font color="white" >' + str(row[0]).split(' ')[0] + ' ' + str(row[1]) +'회 </font>' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none" target=_blank><font color="white" >{1}</font></a><br>'.format(msg.split(' : ')[-1],msg)  
        
    html += '<br><strong><font color="yellow" >24Hours Events (NO NTP)</font></strong><br>'
    cursor.execute(sql1)
    rows = cursor.fetchall()
    for row in rows :
        msg = row[1].split('>')[-1]
        if 1==2 : #bool(re.search(RE_TAG,msg.lower())) == False :
                if len(msg) <  5 : continue
                html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none" target=_blank><font color="red">{1}</font></a><br>'.format(msg.split(' : ')[-1],msg)
        else :html += '<font color="white" >' + str(row[0]) +'회 </font>' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none" target=_blank><font color="white" >{1}</font></a><br>'.format(msg.split(' : ')[-1],msg)
        
    html += '<br><strong><font color="yellow" >Monthly Events (NO NTP)</font></strong><br>'        
    cursor.execute(sql2)
    rows = cursor.fetchall()    
    for row in rows :
        msg = row[1].split('>')[-1]
        if 1==2 : #bool(re.search(RE_TAG,msg.lower())) == False :
                if len(msg) <  5 : continue
                html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none" target=_blank><font color="red">{1}</font></a><br>'.format(msg.split(' : ')[-1],msg)
        else :html += '<font color="white" >' + str(row[0]) +'회 </font>' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none" target=_blank><font color="white" >{1}</font></a><br>'.format(msg.split(' : ')[-1],msg)
    return html 

#description : triage analyzer
import os,sys,time,shutil,re
import xml.etree.ElementTree as ET
import zipfile

@app.route('/es_query_result/search_triage',methods=['GET'])
@valid_session_required_maru #maru
def search_triage():
    html = '''
            <title>Search Keyword From Triage - Cafe24</title>
            <frameset rows="7%,*"> 
            <frame src="/es_query_result/search_triage_bar"></frame>
            <frame name="search_triage_result_frame"></frame>
            </frameset>
            '''
    return html

@app.route('/es_query_result/search_triage_bar',methods=['GET'])
@valid_session_required_maru #maru
def search_triage_bar():
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    html = '''
    * Triage 파일에서 지정한 키워드를 grep 명령어로 검색합니다. grep 명령어의 대상 파일명은 검색 할 "triageid 번호" + ".one" 확장자입니다. (ex : grep -i "malware\.exe" 6000.one | grep -v "test")<br>
    <form action="/es_query_result/timeline" method="post" target="search_triage_result_frame"><input type="text" name="keyword" style="width:700px">
    <input type="submit" value="Search" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;">
    <input type="radio" name="beautify" value="yes" checked="checked">beautify
    <input type="radio" name="beautify" value="no">rawdata | 
    <input type="radio" name="bypass" value="yes" checked="checked">Bypass Reg,ImgLoad,ProcMem
    <input type="radio" name="bypass" value="no">Check Reg,ImgLoad,ProcMem
    </form>
    '''
    return html

@app.route('/es_query_result/timeline',methods=['POST'])
@valid_session_required_maru #maru
def get_timeline():
    try:
        filter = request.form['keyword']
        '''
        cmd_result = os.popen(filter).read()
        if len(cmd_result) / (1024 *1024) > 31 : return ('Too Much Result Text')
        return Response(cmd_result, mimetype='text/plain')
        '''
        triage_id = re.findall('[0-9]{1,20}\.one',filter)[0].replace('.one','')
        #print triage_id
        path = '/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files'
        mans = path + '/' + triage_id + '.mans'
        onelinefile = path + '/' + triage_id + '.one'
        extract_path = path + '/' + triage_id + '_extract'
        temp = extract_path + '/' + filter.split(' ')[0].replace('"','') + '_' + triage_id  + '_temp.txt'
        grep_re = extract_path + '/' + filter.split(' ')[0].replace('"','') + '_' + triage_id  + '.txt'
        if os.path.isfile(onelinefile)  == False :
            if os.path.isfile(mans)  == False:
                maru_restIsSessionValid()
                response =  download_triage(maru_token['token'],'/hx/api/v3/acqs/triages/{0}.mans'.format(triage_id))
                if response.find('Not Found') > -1 :  return '"error":"Not Found Triage File"'
            flist = unzip_triage(mans,extract_path)
            for file in flist :
                make_oneline(os.path.join(extract_path,file),onelinefile)
            
        #os.system('grep -i  "%s" %s | grep -iv "regkeyevent\\|imageload\\|processitem" > %s ' %(filter,onelinefile,temp))
        #filter = re.sub('[%;&><`!\\\$]','',filter)
        filter = re.sub('[%;&`!\$]','',filter)
        cmdline = re.sub('[0-9]{1,20}\.one',os.path.join(path, triage_id + '.one'),filter)
        if request.form['bypass'] == 'yes' : 
            cmdline = cmdline + ' | grep -iv "regkeyevent\\|imageload\\|processitem\\|registryitem" > ' + temp
            #print cmdline
            sec_flag = check_command_injection(cmdline)
            if sec_flag == False : return 'Bad Request. Try Again'
            os.system(cmdline)
        else : 
            sec_flag = check_command_injection(cmdline)
            if sec_flag == False : return 'Bad Request. Try Again'
            os.system('%s > %s ' %(cmdline , temp))
        if 1==1 : # os.path.isfile(grep_re) == False:
            if os.path.getsize(temp) > (1024*1024 *30 ) : return '"error":"result  size bigger than 30MBytes"'
            elif os.path.getsize(temp) == 0 : return 'No Matched. Try Again'
            f = open(grep_re,'wb')
            result = open(temp,'rb')
            for line in result.readlines() : 
                line = line.replace('\n','\n' + '-' *200 + '\n').replace('<','\n<')
                line = line.replace('\n<value>',' : ').replace('<name>','')
                f.write(line)
            f.close()
            result.close()
        if request.form['beautify'] == 'yes' :  
            with open(grep_re,'r') as resultf :
                resultf = resultf.read().replace('<','').replace('>',' : ')
                #re.sub(filter,'<font color ="red">filter</font>',resultf)
        else :
            with open(temp,'r') as resultf :
                resultf = resultf.read()
        return Response(resultf, mimetype='text/plain')
    
    except Exception as err :
        #return 'Bad Request. Try Again'
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        return str(err)

def check_command_injection(cmdline):
    cmdline = cmdline.replace('\\|','nosplit')
    sec_flag = True
    cmdline_dic = cmdline.split('|')
    for cmd in cmdline_dic :
        #print 'split value : %s'%cmd
        if bool(re.search('^(\s*(grep|sort|uniq|awk))',cmd)) == False : 
            sec_flag = False
            break
    return sec_flag


 
# triage 파일 압축 해제 
def unzip_triage(filename,extract_path):
    if os.path.isdir(extract_path):
        shutil.rmtree(extract_path)
    os.mkdir(extract_path)
    triage = zipfile.ZipFile(filename)
    triage.extractall(extract_path)
    triage.close()
    os.system('rm {0}/*.json;rm {1}/script.xml'.format(extract_path,extract_path))
    flist = os.listdir(extract_path)
    return flist
    
# 압축 해제된 triage 파일을 이벤트별로 한 라인으로 변경하는 함수(기본 xml 형식으로 여러 라인으로 분할되어 있음)
def make_oneline(filename,onelinefile):
    ALLLINE = open(onelinefile,'ab')
    one = ''
    with open(filename,'rb') as ori :
        for line in ori.xreadlines():
            line = line.replace('\n','').replace('\r\n','').replace('&amp;','&')
            if bool(re.search('^ {1}</',line)) :
                one += line
                one = one.replace('  ','').replace('\t','') + '\n'
                one = one.replace('<details>','').replace('<detail>','')
                one = re.sub('((</\w{1,40}>)|(<\w{1,30}/>))','',one)
                #one = re.sub(' uid=".*"','',one)
                ALLLINE.write(one)
                #print one
                one = ''
            #elif line.find(' <') > -1: one += line
            #elif line.find('Host:') > -1 : one += line
            else : one += line
    ALLLINE.close()

#description : test api 함수
@app.route('/health_check',methods=['GET'])
def health_check() :
    return 'alive'

@app.route('/bulktest',methods=['POST'])
def bulktest():
    data = request.data
    print data
    return str(data)

@app.route('/byebye',methods=['GET'])
@valid_session_required_maru #maru
def byebye():
    triage_id = request.args.get('triage_id')
    if triage_id.find('maru') == -1 : return 'test page'
    con = dbconn()
    cursor = con.cursor()
    cursor.execute('delete from reqtriage where triage_id = "{0}"'.format(triage_id.replace('maru','')))
    con.commit()
    con.close()
    return redirect(url_for('triage_list',type='ls'))
#description : hx에  등록된 이력이 있는 osint ioc database view page
#hx 등록은 현재 시간 기준 한달 내 보고된 ioc만 등록
@app.route('/osintdb/<type>',methods=['POST','GET'])
@valid_session_required_maru #maru
def osintdb(type) :
    try:
        app.logger.info(request.url + ' - User: %s',session['ht_user'])
        html = '<html>'
        osintdb = '/home/apps/hxtool/hx_es_daemon/dbosint.db'
        con = sqlite3.connect(osintdb)
        cursor = con.cursor()
        if type == 'ls' :
            rows = cursor.execute('select idx,date,ioctype,value,tag,description,report_url,reference from osint_ioc order by idx desc limit 1000')
            rows = cursor.fetchall()
            con.close()
        elif type == 'search' :
            if request.method == 'POST':
                keyword = request.form['keyword']
                field = 'value'
            else : keyword , field = request.args.get('keyword') , request.args.get('field')
            search_sql = 'select idx,date,ioctype,value,tag,description,report_url,reference from osint_ioc where {0} like \'%{1}%\' order by idx desc limit 1000'.format(field,keyword)
            rows = cursor.execute(search_sql)
            rows = cursor.fetchall()
            con.close()
        # html style
        html += '''
        <title>OSINT DB - Cafe24</title>
        <style>body {margin: 0;}
        #fixed-menu{
        width: 100%;
        background-color: #ffffff;
        position: fixed;
        top: 0px;
        left: 0px;
        }
        #main-content {
        width: 100%;
        margin-top: 100px;
        }
        #fixed-menu li {
        display: inline-block;
        margin-right: 30px;
        }
        img {
        max-width: 100%;
        }
        </style>
        <div id="fixed-menu">
        <style> * {margin:0px;padding:0px;}</style>
        <form action="/osintdb/search" method="post"><input type="text" name="keyword"> <input type="submit" value="Search IOC(MD5,IP Etc)" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></form>
        <strong>
        * FireEye HX 에 자동 등록되는 IOC 리스트 (현재시간 기준 한달 내 보고된 IOC)<br>
         <a href="/osintdb/ls" style="text-decoration:none">latest 1000s</a> 
         | <a href="/osintdb/search?keyword=hybrid&field=reference" style="text-decoration:none"> Hybrid Submitted MD5 </a>
         | <a href="/osintdb/search?keyword=app.any.run&field=reference" style="text-decoration:none"> app.any.run Submitted MD5 </a>
         | <a href="/osintdb/search?keyword=shodan&field=reference" style="text-decoration:none"> Shodan RAT C2 </a>
         | <a href="/osintdb/search?keyword=barzaar&field=reference" style="text-decoration:none"> barzaar MD5 </a>
         | <a href="/osintdb/search?keyword=urlhaus&field=reference" style="text-decoration:none"> urlhaus malURL </a>         
         </strong> 
         </div>
         <div id="main-content">
         <table table style="table-layout:fixed;font-size:10px;" border="1" cellspacing="0" backgroundcolor="dark">
        <tr >
        <th>IDX</th><th>Date</th><th>Value</th><th>TAG</th><th>Description</th>
        </tr>
        '''
        for row in rows :
            html += '<tr style="font-size:15px;" onMouseOver=bgColor="#81BEF7" onMouseOut=bgColor="" bgcolor="#FBFAFA">'
            #select idx,date,ioctype,value,tag,description,report_url,reference
            for idx,item in enumerate(row) :
                if idx == 3: html += '<td style="border: 1px solid #81BEF7;" ><font color="black"><a href="%s" target=_blank>%s</font></td>'%(row[6],item) # value link report_url
                elif idx in [2,6,7] : continue
                else : html += '<td style="border: 1px solid #81BEF7;" ><font color="black">' + str(item) + '</font></td>'
            html += '</tr>'
        html += '</table></div></html>'
        return html
        #return render_template('triage_list.html',rows = rows)
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : 월간 수치 그래프 생성 부문
import plotly.graph_objs as go
import pymysql,sqlite3,plotly,sys,re
import collections
import pandas as pd
#import plotly.plotly as py
import chart_studio.plotly as py
'''
#현재 시간 기준 Query
sql_query = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where comment not like "%is팀%테스트%" and event like "%fireeye :%" and request_time > date_add(utc_timestamp(), interval -1 month) group by firstevent order by num desc'
sql_query = 'select computer_name,count(*) as events from reqtriage where comment not like "%is팀%테스트%" and event like "%fireeye :%" and request_time > date_add(utc_timestamp(), interval -1 month) group by computer_name order by events desc'
'''

# 수치고도화 그래프
@app.route('/graph/highgraph',methods=['GET'])
@valid_session_required_maru #maru
def get_high_graph():
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    when = request.args.get('when')
    if when == '' : when = datetime.datetime.today().strftime("%Y-%m")
    os.system('/usr/bin/python /home/apps/hxtool/HXTool-3.0/evtgraph.py %s'%when)
    return redirect('/es_query_result/graph/')

#fireeye hx triage 를 기반으로 월간 수치화 그래프 생성 메인함수
@app.route('/graph/<type>',methods=['GET'])
@valid_session_required_maru #maru
def get_graph(type):
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    dbcon = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
    if os.path.isdir('/home/apps/hxtool/hx_es_daemon/es_query_result/graph') == False : os.mkdir('/home/apps/hxtool/hx_es_daemon/es_query_result/graph')
    where = request.args.get('where')
    if where == '' : 
        where = str(datetime.datetime.now()).split(' ')[0].split('-')
        where = where[0] + '-' + where[1]
    if type == 'osint_ioc_tag' :
        make_bar_OSINT_IOC_TAG(where)
        return redirect('/es_query_result/graph/{0}_ioc_tag.html'.format(where))
    elif type == 'hx_daily_event_num' :
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_hx_daily_event_num.html'.format(where)
        sql_query1 = 'select SUBSTRING_INDEX(request_time, " ", 1) as alerttime , count(*) as num from reqtriage where request_time like "%{0}%" and comment not like "%is팀%테스트%" and event like "%fireeye :%" and comment not like "%noupdate%" group by alerttime'.format(where)
        sql_query2 = 'select SUBSTRING_INDEX(request_time, " ", 1) as alerttime , count(*) as num from reqtriage where request_time like "%{0}%" and comment like "%[ Threat ]%" and event like "%fireeye :%" and comment not like "%noupdate%" group by alerttime'.format(where)
        make_double_bar_graph(where,dbcon,sql_query1,sql_query2,'Day','Num',False,'notsort','Num',' FireeyeHX 일간 발생 이벤트 수 VS 위협으로 확인된 이벤트 수 (총 이벤트 : {0} 건  *테스트 제외* )','','이벤트 개수',report,True,True,'v',1900,1000)
        dbcon.close()
        return redirect('/es_query_result/graph/{0}_hx_daily_event_num.html'.format(where))
    elif type == 'hx_monthly_event_name':
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_hx_monthly_event_name.html'.format(where)
        sql_query = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where request_time like "%{0}%" and comment not like "%is팀%테스트%" and event like "%fireeye :%" and comment not like "%noupdate%" group by firstevent order by num desc'.format(where)
        make_bar_graph(where,dbcon,sql_query,'Num','Event',True,'Num','Event',' FireeyeHX 발생 이벤트 통계  (총 이벤트 : {0} 건  *테스트 제외* )','이벤트 개수','',report,True,False,'h',1900,1000)
        dbcon.close()
        return redirect('/es_query_result/graph/{0}_hx_monthly_event_name.html'.format(where))
    elif type == 'hx_host_num' :
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_hx_host_num.html'.format(where)
        sql_query1 = 'select computer_name,count(*) as events from reqtriage where request_time like "%{0}%" and comment not like "%is팀%테스트%" and event like "%fireeye :%" and comment not like "%noupdate%" group by computer_name order by events desc'.format(where)
        sql_query2 = 'select computer_name,count(*) as events from reqtriage where request_time like "%{0}%" and comment like "%[ Threat ]%" and event like "%fireeye :%" and comment not like "%noupdate%" group by computer_name order by events desc'.format(where)
        make_double_bar_graph(where,dbcon,sql_query1,sql_query2,'User','Num',True,'Num','Num',' FireeyeHX 이벤트 발생 호스트 통계 (총 이벤트 : {0} 건  *테스트 제외* )','','이벤트 개수',report,True,True,'v',1900,1000)
        dbcon.close()
        return redirect('/es_query_result/graph/{0}_hx_host_num.html'.format(where))
    elif type == 'osint_ioc_num' :
        sqlitecon = sqlite3.connect('/home/apps/hxtool/hx_es_daemon/dbosint.db')
        sql_query1 = 'select reference,count(*) as num from osint_ioc where date like "%{0}%" group by reference'.format(where)
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_osint_ioc_num.html'.format(where)
        make_bar_graph(where,sqlitecon,sql_query1,'reference','Num',True,'Num','Num',' FireeyeHX에 자동 등록된 OSINT IOC (Total IOC : {0})','','',report,True,False,'v',600,800)
        sqlitecon.close()
        return redirect('/es_query_result/graph/{0}_osint_ioc_num.html'.format(where))

#osint db에 저장된 ioc의 태그를 split 하여 각 tag 개수를 합산. 상위 50개를 bar graph로 생성하는 함수
def make_bar_OSINT_IOC_TAG(where) :
    if os.path.isfile('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.html'.format(where)):
        os.remove('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.html'.format(where))
    dbcon = sqlite3.connect('/home/apps/hxtool/hx_es_daemon/dbosint.db')
    sql_query = 'select tag from osint_ioc where date like "%{0}%"'.format(where)
    cursor = dbcon.cursor()
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    all_tag = []
    for row in rows :
        tags = re.sub('\[|\]|u\'|\'|"','',row[0]).replace(' ','')
        if tags.find(',') > -1 : tags = tags.split(',')
        for tag in tags : 
            if len(tag) < 3 : continue
            if tag.lower().strip() in ['malware_download','elf','none','exe','bashlite','thisislastitem','32-bit'] : continue   
            all_tag.append(tag.lower())
    tag_group = dict(collections.Counter(all_tag))
    tags ,number_tmp , number =  [] , [] , []
    for tag,num in tag_group.iteritems():
        #tags.append(tag)
        number_tmp.append(num)
    number_tmp.sort(reverse=True)
    for tag,num in tag_group.iteritems():
        if num in number_tmp[0:50] :
            tags.append(tag)
            number.append(num)
    df = pd.DataFrame.from_dict({'Tag':tags,'Num':number})
    df = df.sort_values(['Num'], ascending=[1])
    text = df['Tag'] + ' : ' + df['Num'].map(str)
    title = where + ' Malware TAG Trend TOP 50<br>[ Reference : shodan.io / Hybrid-analysis.com / urlhaus / Barzaar / app.any.run ]'#.format(str(sumnum))
    trace1 = go.Bar(
        x=df['Num'],
        y=df['Tag'],
        text=text,
        textposition = 'auto',
        marker=dict(color='rgb(158,202,225)'),
        orientation = 'h'
    )
    layout = go.Layout(
        title=title,
        xaxis=go.layout.XAxis(title=''),
        yaxis=go.layout.YAxis(title='',visible=False),
        width=1800,
        height=1500,
    )
    data = [trace1] #Data([trace1])
    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig, filename='/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.html'.format(where),auto_open=False)
    #fig.write_image('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.png'.format(where))

# 단일 bar graph 생성함수 (ex : 이벤트명 별 이벤트 개수)
def make_bar_graph(where,dbcon,sql_query,column_x,column_y,issort,sort_column,show_column,title,x_title,y_title,filename,autosize,y_visible,orientation,width,height ) :
    if os.path.isfile(filename):
        os.remove(filename)
    cursor = dbcon.cursor()
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    df = pd.DataFrame( [[ij for ij in i] for i in rows] )
    df.rename(columns={0: column_x , 1: column_y}, inplace=True)
    if issort == True : df = df.sort_values([sort_column], ascending=[1])
    if orientation == 'h' : 
        sumnum = df[column_x].sum()
        text = df[show_column] + ' : ' + df[column_x].map(str)
    else : 
        sumnum = df[column_y].sum()
        text = df[show_column]
    title = where + title.format(str(sumnum))
    trace1 = go.Bar(
        x=df[column_x],
        y=df[column_y],
        text=text,
        #hovertext=test,
        textposition = 'auto',
        marker=dict(color='rgb(158,202,225)'),
        orientation = orientation
    )
    layout = go.Layout(
        title=title,
        xaxis=go.layout.XAxis(title=x_title,tickmode='linear'),
        yaxis=go.layout.YAxis(title=y_title,visible=y_visible,tickmode='linear'),
        width=width,
        height=height,
        autosize=autosize
    )
    data = [trace1] #Data([trace1])
    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig, filename=filename,auto_open=False)
    #fig.write_image(filename.replace('.html','.png'))

# double bar  graph 생성 함수 (ex: 전체 이벤트 vs threat)
def make_double_bar_graph(where,dbcon,sql_query1,sql_query2,column_x,column_y,issort,sort_column,show_column,title,x_title,y_title,filename,autosize,y_visible,orientation,width,height ) :
    if os.path.isfile(filename):
        os.remove(filename)
    cursor = dbcon.cursor()
    cursor.execute(sql_query1)
    rows = cursor.fetchall()
    df1 = pd.DataFrame( [[ij for ij in i] for i in rows] )
    df1.rename(columns={0: column_x , 1: column_y}, inplace=True)
    cursor.execute(sql_query2)
    rows = cursor.fetchall()
    df2 = pd.DataFrame( [[ij for ij in i] for i in rows] )
    df2.rename(columns={0: column_x , 1: column_y}, inplace=True)
    if issort == True : df1 = df1.sort_values([sort_column], ascending=[1])
    text1 = df1[show_column]
    text2 = df2[show_column]
    if orientation == 'h' : 
        sumnum = df1[column_x].sum()
    else : sumnum = df1[column_y].sum()
    title = where + title.format(str(sumnum))
    trace1 = go.Bar(
        x=df1[column_x],
        y=df1[column_y],
        text=text1,
        #hovertext=test,
        textposition = 'auto',
        marker=dict(color='rgb(158,202,225)'),
        orientation = orientation,
        name = 'Total'
    )
    trace2 = go.Bar(
        x=df2[column_x],
        y=df2[column_y],
        text=text2,
        #hovertext=test,
        textposition = 'auto',
        marker=dict(color='rgba(222,45,38,0.8)'),
        orientation = orientation,
        name = 'Threat'
    )
    layout = go.Layout(
        barmode='group',
        title=title,
        xaxis=go.layout.XAxis(title=x_title,tickmode='linear'),
        yaxis=go.layout.YAxis(title=y_title,visible=y_visible,tickmode='linear'),
        width=width,
        height=height,
        autosize=autosize
    )
    data = [trace1,trace2] #Data([trace1])
    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig, filename=filename,auto_open=False)
    #fig.write_image(filename.replace('.html','.png'))

# 텍스트 데이타를 입력 받아 파싱 >> ioc type 별로 수집 >> enterprise search 요청
# ioc type : 'File SHA256 Hash' , 'File SHA1 Hash' , 'File MD5 Hash' , 'Remote IP Address' , 'DNS Hostname' , 'URL'
QUERY_FORMAT = '{"operator": "equals", "field": "%s", "value": "%s"}'
ESFORMAT = '{"host_set": {"_id": 1004},"exhaustive": {"overrides": []},"query": [ %s ]}'  # must modify (1119 test , 1004 allpc)
# search data를 받아 es api 요청
def request_search(search_data):
    maru_restIsSessionValid()
    url = '/hx/api/v3/searches'
    response = request_hx(maru_token['token'],url,'','POST',search_data,'n')
    return response

# 수집한 ioc dic을 받아  type별로 es 요청 
# es search maximum item 개수 = 25개로 그 이상인 경우 나누어서  요청
#텍스트를 입력받는 폼
@app.route('/esfromtext',methods=['GET'])
def esfromtext():
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    html = '<html><title>Enterprise Search</title>텍스트란에 IOC 가 포함된 Text를 입력하세요.<br>Text 에서 Hash , IP Address , Domain , URL 을 수집하여 Enterprise Search 를 자동 요청합니다. <br>*주의 : 300 개 이상의 IOC 값을 넣지 마세요!<br>*최대 15개의 Enterprise Search 동시 진행 가능하며 각 Enterprise Search 에 포함될 수 있는 최대 IOC 수는 25개입니다.<br><form action="/checkioc" method="post"><textarea name="description" cols=130 rows=1 onclick="this.value=\'\'">Enterprise Search 를 진행할 IOC 에 대한 설명을 입력하세요.</textarea><br><textarea name="reference" cols=130 rows=1 onclick="this.value=\'\'">참조한 URL을 입력하세요.</textarea><br><textarea name="ioc" cols="130" rows="20">IOC가 포함된 Text를 입력하세요.\r\n</textarea><div><div style="display:inline;width:200px;"><input type="submit" value="GetIOC" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form>'
    return html


# text에서 ioc를 분류,수집 한 후 textarea 로 edit 가능하도록 출력한다.
@app.route('/checkioc',methods=['POST'])
@valid_session_required_maru #maru
def checkioc():
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    text = request.form['ioc'].lower()
    description = request.form['description']
    reference = request.form['reference']
    ioc_dic = get_ioc_in_text(text)
    ioc_dic_str = ''
    for ioc_type in ioc_dic.keys():
        #if len(ioc_dic[ioc_type]) == 0 : continue
        ioc_dic_str += '[ ' + ioc_type + ' ]' + '\r\n'
        for item in ioc_dic[ioc_type] :
            if ioc_dic_str.find(item) == -1 :
                ioc_dic_str += item + '\r\n'
        ioc_dic_str += '\r\n'
    html = '<html><title>Enterprise Search</title>텍스트에서 찾은 IOC 값을 확인하고 잘못된 IOC를 삭제하거나 추가 할 IOC를 입력하세요<br>수정 후 "Enterprise Search" 버튼을 클릭하면 해당 IOC들을 Enterprise Search 로 검색합니다.<br>"Reservation" 버튼을 클릭하면 업무 시간 외 검색을 진행하도록 예약합니다.<form action="/reqsearch" name="reqform" method="post"><textarea name="description" cols="130" rows="1">{0}</textarea><br><textarea name="reference" cols="130" rows="1">{1}</textarea><br><textarea name="ioc" cols="130" rows="20">{2}</textarea><br><div><div style="display:inline;width:200px;"><input type="button" value="Enterprise Search" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;" onclick="mysubmit(1)"> <input type="button" value="Reservation" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;" onclick="mysubmit(2)"></div></form>'.format(description,reference,str(ioc_dic_str))
    html += '<script>function mysubmit(index) { if(index==1){document.reqform.action = "/reqsearch";}if(index==2){document.reqform.action = "/esioc_reservation";}document.reqform.submit();}</script></html>'
    return html
    
# ioc 검색 예약을 위한 작업 : 파일에 저장
@app.route('/esioc_reservation',methods=['POST'])
def esioc_reservation() :
    #app.logger.info(request.url + ' - User: %s',session['ht_user'])
    reserv_dir = '/home/apps/hxtool/hx_es_daemon/ioces_reserved'
    if os.path.isdir(reserv_dir) == False : os.mkdir(reserv_dir)
    text = request.form['ioc'].lower()
    description = request.form['description']
    reference = request.form['reference']
    ioc_dic = get_ioc_in_text(text)
    with open(os.path.join(reserv_dir,description.replace(' ','_')),'wb') as f :
        f.write(description + '\n')
        f.write(reference + '\n')
        f.write(str(ioc_dic) + '\n')
    return 'IOC Enterprise Search 예약 완료. (0 시 ~ 08 시 검색 예정)'


# hx server 에 enterprise search를 요청한다.
@app.route('/reqsearch',methods=['POST'])
#@valid_session_required_maru #maru
def reqsearch():
    #app.logger.info(request.url + ' - User: %s',session['ht_user'])
    text = request.form['ioc'].lower()
    description = request.form['description']
    reference = request.form['reference']
    ioc_dic = get_ioc_in_text(text)
    return (send_ioc(ioc_dic,description,reference))

def send_ioc(ioc_dic,description,reference) :
    try :
        maru_restIsSessionValid()
        result = ''
        allioc = 0
        no_zero_ioc_type = 0
        response = request_hx(maru_token['token'],'/hx/api/v3/searches','','GET',None,'n')
        # 이전 요청에 의해 N 개 이상의 서치 있으면 중단 / client 가용성 문제
        if response['data']['total'] > 5 :
            return '현재 진행 중인 Enterprise Search가 존재하여 입력한 IOC 들을 검색 할 수 없습니다.'
        for ioc_type in ioc_dic.keys() :
            allioc += len(ioc_dic.get(ioc_type))
            if len(ioc_dic.get(ioc_type)) != 0 : no_zero_ioc_type += 1            
        # 입력받은 ioc 개수를 모두 검색 할 수 있는지 확인
        if (15 * 25) - (response['data']['total'] * 25) < allioc or (15 - response['data']['total'] < no_zero_ioc_type) :
            return '%d 현재 진행 중인 Enterprise Search가 존재하여 입력한 IOC 들을 모두 검색 할 수 없습니다.<br>불필요한 Enterprise Search를 삭제하고 재시도 바랍니다.<br><a href = "https://112.175.67.137:3000/hx/enterprise_search" target=_blank>* HX Enterprise Search Menu</a>'%allioc
        # ioc_type 별로 진행
        for ioc_type in ioc_dic.keys() :
            if len(ioc_dic.get(ioc_type)) == 0 : continue # ioc 갯수가 0 이면 패스
            query , data  = '' , '' 
            for idx,item in enumerate(ioc_dic.get(ioc_type)) : 
                if idx != len(ioc_dic.get(ioc_type)) -1 : # ioc list 마지막 item이 아니고
                    if ((idx+1)%25) != 0  : query += (QUERY_FORMAT)%(ioc_type,item) + ',' # 검색 가능 최대치인 25로 나누어지지 떨어지지 않을 경우 query format 마지막에 , 추가
                    else : query += (QUERY_FORMAT)%(ioc_type,item)  # 25로 나누어질 경우 검색 가능 최대치가 된 것으로 판단하고 query format 을 완성한다.
                else :  # ioc list 마지막일 경우 query format 을 완성한다.
                    query += (QUERY_FORMAT)%(ioc_type,item)
                data = (ESFORMAT)%query
                if ((idx+1)%25) == 0 : # 검색 최대치이면 es 요청 후 DB저장 , 변수 초기화
                    response = request_search(data)
                    result += json.dumps(response) + '<br><br>'
                    search_id = response['data']['_id']
                    request_time = response['data']['create_time']
                    insert_ioc_es(str(search_id),request_time,json.dumps(ioc_dic),description,reference)
                    query , data  = '' , '' 
            if data == '' : continue # 사전에 요청 되어 data가 초기화 되면 패스
            response = request_search(data)
            result += json.dumps(response) + '<br><br>'
            #ioc_es table : search_id , request_time , end_time , ioc_dic , hx_response_json , description , reference , search_result_json , userinfo , es_summary
            search_id = response['data']['_id'] # error point 
            request_time = response['data']['create_time']
            insert_ioc_es(str(search_id),request_time,json.dumps(ioc_dic),description,reference) 
        return '<a href = "https://112.175.67.137:3000/hx/enterprise_search" target=_blank>* HX Enterprise Search Menu</a><br><br><a href = "' + hxtool_srv + '/es_query_result/triage_list/ls">* Triage List View</a><br><br>' + '[ Request Enterprise Search Result ]<br>' + result
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        sendalarm('* HX REQ Triage Error : ' + str(err) + '\r\n\r\n' + str(response) + '\r\n\r\n' + str(data) ,errorreceiver)
        passive_traige_error.error(str(err))


def insert_ioc_es(search_id,request_time,ioc_dic,description,reference) :
    try:
        description = description.replace("'","")
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('insert ignore into ioces values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\')'.format(search_id,request_time,'',ioc_dic,'',description,reference,'','',''))
        con.commit()
        con.close()
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

def forprint(title,arrary):
    if len(arrary) == 0 : return 0
    print '\r\n\r\n' + title
    for i in arrary:
        print i

#전달받은 텍스트에서 정규식을 이용하여 ioc 를 분류,수집한다. ioc_dic 리턴
def get_ioc_in_text(input) :
    URL = input
    #https://data.iana.org/TLD/tlds-alpha-by-domain.txt    (root domain list)
    with open('rootdomainlist.txt','rb') as f :
        rootdomain = f.read()
    rootdomain = rootdomain.split('\n') # linux \n , windows \r\n
    DOT = '(\.|\[dot\]|\[\.\])'
    REPLACEEOF = '(\r\n|\n|<|>|\t)'
    CMD = [' systeminfo','net1.exe ','cmd.exe ','powershell.exe ','wscript.exe ','vbscript.exe ','wmic.exe ',' /c ',' /v ',' /k ',' /v ']
    #file
    contents_tmp = input
    contents_tmp = contents_tmp.split('\r\n')
    # web
    '''
    response = requests.get(URL)
    contents_tmp  = unicode(response.text.decode('utf-8')).encode('utf-8')
    contents_tmp = contents_tmp.split('\r\n')
    contents_tmp =re.sub('<a href.+</a>','',contents_tmp)
    contents_tmp = re.findall(r'>[^<>=\{\}]+<',contents_tmp)
    '''
    contents = ''
    for i in contents_tmp :
        contents += i.replace('>','').replace('<','') + '\n'
    if 1 !=1 : # contents.find('<br>') > -1 or contents.find('<p>') > -1 : 
        type = 'html'
        EOFCHAR = '<'
        HEADCHAR = '>'
    else : 
        type = 'text'
        EOFCHAR = '' #'(\r\n|\n)'
        HEADCHAR = ''
    # Get IOC Functions    
    #IOC List
    ioc_dic = {'File SHA256 Hash':[] , 'File SHA1 Hash':[] , 'File MD5 Hash':[] , 'Remote IP Address':[] , 'DNS Hostname':[] , 'URL':[], 'File Full Path':[],'Process Arguments':[]}

    # get ipaddress
    #tmp = re.findall('((' + HEADCHAR +' \d{1,3}' + DOT + '){3}\d{1,3}' + EOFCHAR + ')',contents)
    tmp = re.findall('((\d{1,3}(\.|\[dot\]|\[\.\])){3}\d{1,3})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        item = list(set(item))
        for i in item :
            i = i.strip()
            if i not in ioc_dic['Remote IP Address'] and len(i) > 5 :
                ioc_dic['Remote IP Address'].append(i)


    #get url
    tmp = re.findall('((http|https|hxxp|hxxps)\:\/\/((\S+\/?)([a-zA-Z0-9\-_]|(\.|\[dot\]|\[\.\]))+){1,5})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip().replace('hxxp','http')
            if i not in ioc_dic['URL'] and len(i) > 5  :
                ioc_dic['URL'].append(i)

                
    # get domain
    tmp = re.findall('([a-zA-Z\-0-9]{3,30}(\.|\[dot\]|\[\.\])[a-zA-Z\-0-9]{3,30}(\.|\[dot\]|\[\.\])[a-zA-Z\-0-9]{5,30}(\.|\[dot\]|\[\.\])[a-zA-Z]{2,30})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if i not in ioc_dic['DNS Hostname'] and len(i) > 5 and i.split('.')[-1].upper() in rootdomain and str(ioc_dic['URL']).find(i) == 1 :
                ioc_dic['DNS Hostname'].append(i)         
    tmp = re.findall('([a-zA-Z\-0-9]{3,30}(\.|\[dot\]|\[\.\])[a-zA-Z\-0-9]{5,30}(\.|\[dot\]|\[\.\])[a-zA-Z]{2,30})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if i not in ioc_dic['DNS Hostname'] and len(i) > 5 and i.split('.')[-1].upper() in rootdomain and str(ioc_dic['URL']).find(i) == 1 :
                ioc_dic['DNS Hostname'].append(i)            
    tmp = re.findall('([a-zA-Z\-0-9]{5,30}(\.|\[dot\]|\[\.\])[a-zA-Z]{2,30})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if i not in ioc_dic['DNS Hostname'] and len(i) > 5 and i.split('.')[-1].upper() in rootdomain and str(ioc_dic['URL']).find(i) == 1 :
                ioc_dic['DNS Hostname'].append(i) 
                
    #get sha256
    tmp = re.findall('[A-Fa-f0-9]{64}'+EOFCHAR,contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item= item.strip()
        if item not in ioc_dic['File SHA256 Hash'] and len(item) > 5 :
            ioc_dic['File SHA256 Hash'].append(item) 
            
     #get sha1
    tmp = re.findall('[A-Fa-f0-9]{40}'+EOFCHAR,contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item= item.strip()
        if item not in  ioc_dic['File SHA1 Hash'] and len(item) > 5 and str(ioc_dic['File SHA256 Hash']).find(item) == -1  :
            ioc_dic['File SHA1 Hash'].append(item)
            
     #get md5
    tmp = re.findall('[A-Fa-f0-9]{32}'+EOFCHAR,contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item= item.strip()
        if item not in ioc_dic['File MD5 Hash'] and len(item) > 5 and str(ioc_dic['File SHA256 Hash']).find(item) == -1 and str(ioc_dic['File SHA1 Hash']).find(item) == -1 :
            ioc_dic['File MD5 Hash'].append(item)   
            
    # get file name
    tmp = re.findall('(((([a-zA-Z]:\\\\)|%)([a-zA-Z\-_0-9\[\]%\s]+)\\\\)+.{1,30}(\.[a-zA-Z_0-9]{3}))',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if bool(re.search('"|\'',i)) == False and i not in ioc_dic['File Full Path'] and len(i) > 5 and i.find(' /') == -1  :
                    ioc_dic['File Full Path'].append(i)
     

    '''
    #get cmdline
    tmp = re.findall('.+\s/[a-z]\s.+',contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        if item not in ioc_dic.values() :
            ioc_dic['Process Arguments'].append(item)
    #get cmdline
    tmp = re.findall('(powershell|cmd|wscript|wmic|bitadmin|tasklist|taskkill|net1)(\.exe)?\s.{10,300}',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            if i not in ioc_dic.values() :
                ioc_dic['Process Arguments'].append(i)
    '''        
    '''
    forprint('[hash_sha256]',ioc_dic['File SHA256 Hash'] )
    forprint('[hash_sha1]',ioc_dic['File SHA1 Hash'])
    forprint('[hash_md5]',ioc_dic['File MD5 Hash'])
    forprint('[domain]',ioc_dic['DNS Hostname'])
    forprint('[ipaddress]',ioc_dic['Remote IP Address'])
    forprint('[filepath]',ioc_dic['File Full Path'])
    forprint('[url]',ioc_dic['URL'])
    #forprint('[cmdline]',ioc_dic['Process Arguments'])
    '''
    return ioc_dic

# 총무팀 pc list 정보 출력
from flask import Response
from bs4 import BeautifulSoup
def get_bonsa_pclist(req_type):
    if req_type.find('testpc') > -1 : url = 'http://general.hanpda.com/test/pclist2.php'
    else : url = 'http://general.hanpda.com/test/pclist.php'
    req=requests.get(url)
    html=req.text
    soup=BeautifulSoup(html,'html.parser')
    columns=soup.select('table.w3-striped > tbody > tr > td')
    newlines = []
    only_ip = []
    line = ''
    for idx,col in enumerate(columns) :
        col = str(col)
        col = col.replace('<td>','').replace('</td>','')
        if (idx + 1) %6 == 0 : 
            #line += ' ' + col
            line = line.split('=split=')
            line = line[0] + '=split=' + line[1] + '=split=' + line[2]
            if req_type.find('testpc') > -1 : 
                if col == 'O' : newlines.append(line)
            else : newlines.append(line)
            line = ''
        elif (idx + 1) %6 == 1 : 
            line +=  'id=' + col + '=split='
        elif (idx + 1) %6 == 2 : 
            line +=  'name=' + col + '=split='
        elif (idx + 1) %6 == 3 : 
            line +=  'ip=' + col + '=split='
        #else : line +=  col + '=split='
        
    newlines.pop(0)
    info_text = ''
    for line in newlines :
        ip = line.split('=split=')[2]
        if ip !='ip=' : only_ip.append(ip)
        line = line.replace('=split=',',')
        if line.find('id=,name=,ip=') > -1 : continue
        info_text += line + '\n'
    
    if req_type.find('iplist') > -1 :
        info_text = ''
        for ip in only_ip :
            info_text += ip + '\n'
    return info_text
    
@app.route('/allpclist',methods=['GET'])
def allpclist():
    info_txt = get_bonsa_pclist('allpclist')
    return Response(info_txt, mimetype='text/plain')

@app.route('/alliplist',methods=['GET'])
def alliplist():
    info_txt = get_bonsa_pclist('alliplist')
    return Response(info_txt, mimetype='text/plain')

@app.route('/alltestpclist',methods=['GET'])
def alltestpclist():
    info_txt = get_bonsa_pclist('alltestpclist')
    return Response(info_txt, mimetype='text/plain')

@app.route('/alltestpciplist',methods=['GET'])
def alltestpciplist():
    info_txt = get_bonsa_pclist('alltestpciplist')
    return Response(info_txt, mimetype='text/plain')

def is_activate_agenttime(last_poll_timestamp):
    now_str = (datetime.datetime.utcnow() + datetime.timedelta(minutes=0)).isoformat()
    now_date = datetime.datetime.strptime(now_str.partition('.')[0], "%Y-%m-%dT%H:%M:%S")                
    last_poll_timestamp_date = datetime.datetime.strptime(last_poll_timestamp.partition('.')[0], "%Y-%m-%dT%H:%M:%S")
    result = now_date - last_poll_timestamp_date # second
    if int(result.days) > 10 :
        return False
    else : return True

# agent 가 설치된 hosts 정보를 수집하여 출력한다.
@app.route('/hosts_info',methods=['GET'])
def hosts_info():
    hostinfof = 'hostinfofiles.html'
    if 'refresh' in request.args or os.path.isfile(hostinfof) == False : 
        host_info_dic , host_info_dic_long = get_all_agent_info()
        #info_txt = 'Total FireeyeHX Agent Num : %d <br>'%len(host_info_dic)
        #info_txt += 'last_poll_ip ; hostname ; initial_agent_checkin ; last_poll_timestamp ; agent_url' + '<br>'
        info_txt = '<html><title>Host Information</title><body style="background-color:#2f2f2f;color:white">'
        info_txt += '<a href="/hosts_info?refresh=true" style="text-decoration:none">Refresh List</a><br>'
        for host_info in host_info_dic_long :
            info_txt += host_info
        info_txt = info_txt.replace('\n','<br>') + '</body></html>'
        with open(hostinfof,'w') as f :
            f.write(info_txt)
    else : 
        info_txt = open(hostinfof).read()
    return Response(info_txt)

# last audit time 24시간 이후이면  agent list 에서 제외   
@app.route('/hosts_info2',methods=['GET'])
def hosts_info2():
    host_info_dic , host_info_dic_long = get_all_agent_info()
    #info_txt = 'Total FireeyeHX Agent Num : %d <br>'%len(host_info_dic)
    #info_txt += 'last_poll_ip ; hostname ; initial_agent_checkin ; last_poll_timestamp ; agent_url' + '<br>'
    info_txt = ''
    #print(host_info_dic)
    for idx,host_info in enumerate(host_info_dic) :
        if is_activate_agenttime(host_info.split(';')[3]) == True :
            info_txt += host_info#.split(' ')[-1].replace('ip=','')
    return Response(info_txt.replace('\r\n','\n'), mimetype='text/plain')

def get_all_agent_info() :
    maru_restIsSessionValid()
    url = '/hx/api/v3/hosts'
    host_info_dic = []
    host_info_dic_long = []
    ip_dic = []
    response = request_hx(maru_token['token'],url,'?limit=10000&sort=last_poll_timestamp+descending','GET',None,'n')
    for entry in response['data']['entries'] :
        try:
            host_info_short = ''
            host_info_long = ''
            host_info_short2 = ''
            host_info_long2 = ''            
            initial_agent_checkin = entry['initial_agent_checkin']
            last_poll_timestamp = entry['last_poll_timestamp']
            if 'last_audit_timestamp' in entry : 
                last_audit_timestamp = entry['last_audit_timestamp']            
                if datetime.datetime.strptime(last_audit_timestamp.partition('.')[0], "%Y-%m-%dT%H:%M:%S") > datetime.datetime.strptime(last_poll_timestamp.partition('.')[0], "%Y-%m-%dT%H:%M:%S") : 
                    last_poll_timestamp = last_audit_timestamp
            agent_url = entry['sysinfo']['url']
            agent_id = entry['_id']
            primary_mac = entry['primary_mac']
            last_poll_ip = entry['last_poll_ip']
            primary_ip = entry['primary_ip_address'] # here
            hostname = entry['hostname']
            if hostname == None : hostname = 'NotFoundHostname'
            host_info_long += last_poll_ip + ';' + '<a href="' + 'https://112.175.67.137:3000/hx/#/hosts/' + agent_id + '" target="_blank" style="color: white">' + hostname + ';' + '</a>' + initial_agent_checkin + ';' + last_poll_timestamp + ';' + agent_url + '\n'
            host_info_long2 += primary_ip + ';' + '<a href="'+ 'https://112.175.67.137:3000/hx/#/hosts/' + agent_id +'" target="_blank" style="color: white">' + hostname + ';' + '</a>' + initial_agent_checkin + ';' + last_poll_timestamp + ';' + agent_url + '\n'
            #host_info_long : 192.168.1.139;judePC-W;2018-09-28T01:58:35.322Z;2018-10-04T03:01:30.620Z;/hx/api/v3/hosts/HBwM3yY2BR7ep9ZFRIlEdY/sysinfo
            #host_info_short += 'id=' + hostname + ' ' + 'ip=' + last_poll_ip + '\n'
            #host_info_short2 += 'id=' + hostname + ' ' + 'ip=' + primary_ip + '\n'
            host_info_short += hostname + ';' + last_poll_ip + ';' + primary_mac + ';' + last_poll_timestamp + '\n'
            host_info_short2 += hostname + ';' + primary_ip + ';' + primary_mac + ';' + last_poll_timestamp + '\n'

            if last_poll_ip + hostname not in ip_dic :
                ip_dic.append(last_poll_ip + hostname)
                if host_info_short not in host_info_dic: host_info_dic.append(host_info_short)
                if host_info_long not in host_info_dic_long: host_info_dic_long.append(host_info_long)
            if last_poll_ip != primary_ip :
                if primary_ip +hostname not in ip_dic :
                    ip_dic.append(primary_ip + hostname)
                    if host_info_short2 not in host_info_dic: host_info_dic.append(host_info_short2)
                    if host_info_long2 not in host_info_dic_long: host_info_dic_long.append(host_info_long2)
                    
            '''
            primary_ip_address = entry['primary_ip_address']
            if primary_ip_address == None : primary_ip_address = 'NotFoundPrimary_ip_address'
            if last_poll_ip != primary_ip_address : 
                print last_poll_ip + ';' + primary_ip_address
            '''
        except Exception as err:
            print err
            continue
    host_info_dic.sort()
    host_info_dic_long.sort()
    return host_info_dic,host_info_dic_long


# Triage 파일 내 md5 를 max cloud antivirus api 로 질의한다. 
# 결과는 쪽지로 전송하고 popen 을 이용하여 독립된 프로세스로 실행한다.
# mans > unzip > make online file > grep > collect md5 value > request max api > send alarm
@app.route('/es_query_result/triage_list/req_maxav',methods=['GET'])
#@valid_session_required_maru #maru
def req_maxav() : 
    try : 
        triage_id = request.args.get('triage_id')
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('select state from reqtriage where triage_id = "%s"'%triage_id)
        row = cursor.fetchone()
        con.close()
        if row[0] != 'COMPLETE' : return '<script>alert("현재 Triage 수집이 완료되지 않았습니다. 상태가 COMPLETE 로 변경되면 다시 시도하세요..");history.back();</script>'
        con = sqlite3.connect('/home/apps/hxtool/HXTool-3.0/hashdb')
        cursor = con.cursor()
        create_hashdb_table = '''
        create table if not exists hashdb(idx integer primary key autoincrement,first_inserted_time text,last_checked_time text,hash_reference text,hash_type text,hash_value text,
        report_type text,report_url text,full_result text,result text,original_line text,checked_filename text,etc1 text,etc2 text,etc3 text)
        '''
        cursor.execute(create_hashdb_table)
        create_hashdb_table = '''
        create table if not exists maxav_alarm(idx integer primary key autoincrement, triage_id text , alarm text , etc1 text , etc2 text , etc3 text)
        '''
        cursor.execute(create_hashdb_table)
        con.commit()
        cursor.execute('select alarm from maxav_alarm where triage_id = "%s"'%triage_id)
        row = cursor.fetchone()
        if row != None :
            if len(row) > 0 : 
                return '<html><title>Triage Summary</title><body style="background-color:#2f2f2f;color:white">' + row[0].replace('\r\n','<br>') + '</body></html>'
        else :                
            path = '/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files'
            mans = path + '/' + triage_id + '.mans'
            onelinefile = path + '/' + triage_id + '.one'
            if os.path.isfile('/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files/%s.one'%triage_id) == False :
                maru_restIsSessionValid()
                response =  download_triage(maru_token['token'],'/hx/api/v3/acqs/triages/{0}.mans'.format(triage_id))
                if response.find('Not Found') == -1 :
                    extract_path = path + '/' + triage_id + '_extract'
                    if os.path.isfile(onelinefile)  == False :
                        if os.path.isfile(mans) :
                            flist = unzip_triage(mans,extract_path)
                            for file in flist :
                                make_oneline(os.path.join(extract_path,file),onelinefile)
                        else :
                            return '"error":"Not Found Triage File"'
            maxav_reserved = '/home/apps/hxtool/HXTool-3.0/maxav_reserved.txt'
            if os.path.isfile(maxav_reserved) == True :
                fread = open(maxav_reserved,'r').read()
                if triage_id not in fread :
                    with open(maxav_reserved,'a') as f :
                        f.write(triage_id + '\n')
            else :
                with open(maxav_reserved,'w') as f :
                    f.write(triage_id + '\n')                         
            return '<script>alert("해당 Triage 파일에 포함된 md5를 추출하여 클라우드 백신 검사를 진행하고 있습니다.검사가 완료되면 쪽지로 결과가 전송됩니다.");history.back();</script>'  
        '''
        check_duplicated = os.popen('ps -ef').read()
        if check_duplicated.find('python /home/apps/hxtool/hx_es_daemon/lib/maxav_for_hxtool_srv.py') > -1 :
            msg = '<script>alert("현재 클라우드 백신 검사가 진행 중인 Triage가 확인되었습니다.잠시 후 다시 시도하세요.");history.back();</script>'
        else :
            msg = '<script>alert("해당 Triage 파일에 포함된 md5를 추출하여 클라우드 백신 검사를 진행하고 있습니다.검사가 완료되면 쪽지로 결과가 전송됩니다.");history.back();</script>'
            os.spawnl(os.P_NOWAIT,'/usr/bin/python','python','/home/apps/hxtool/hx_es_daemon/lib/maxav_for_hxtool_srv.py','triage',onelinefile)
        return msg
        '''
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))
        print(err)

#health check
@app.route('/es_query_result/hxhealth',methods=['GET'])
@valid_session_required_maru #maru
def hxhealth() : 
    try : 
        app.logger.info(request.url + ' - User: %s',session['ht_user'])
        report = health_check_hx()
        return Response(report, mimetype='text/plain')
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#daily report
import security_daily_report
@app.route('/daily_report',methods=['GET'])
@valid_session_required_maru #maru
def daily_report() :
    app.logger.info(request.url + ' - User: %s',session['ht_user'])
    html = '''
    * 파이어아이 일일 이벤트 자동 생성 페이지<br>
    * 레포트에 포함될 이벤트 검색 시작 날짜 입력 (ex : 2019/05/10)<br>
    <form action="/make_daily_report" method="post">
    <input type="text" name="startdate">
    <input type="submit" value="레포트 생성" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;">
    </form>
    '''
    return html
    
@app.route('/make_daily_report',methods=['POST'])
@valid_session_required_maru #maru
def make_daily_report() :
    try :
        startdate = request.form['startdate']
        if startdate != '' :
            report = security_daily_report.report(startdate)
        else : report = 'Report Error'
        #return Response(report, mimetype='text/plain')
        return Response(report)
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))
        
@app.route('/noinstall_alarm',methods=['POST'])
def noinstall_alarm() :
    try :
        pass_user = ['shlee02']
        json_data = json.loads(request.data)
        for device in json_data :
            recv = 'yskim04,chmoon'
            msg = u'#보안프로그램 미설치 알람 : ' + device + '\n'
            if device == 'fireeye' : msg += u'파이어아이 보안프로그램 설치요청\nfireeye agent download 및 설치가이드\nhttps://wiki.simplexi.com/pages/viewpage.action?pageId=1675213928'
            elif device == 'symantec' : msg += u'시만텍 백신 설치요청\n시만텍다운로드 및 설치 링크\nhttps://wiki.simplexi.com/pages/viewpage.action?pageId=1709748302'
            else : continue
            users = json_data[device]
            if len(users) == 0 : continue
            elif len(users) > 15 : 
                msg += u'\n\n미설치 사용자수가 15명 이상으로 쪽지 전송하지 않음\n미설치 사용자수 결과 점검 필요\n'
                sendalarm(msg.encode('utf-8'), recv)
                continue
            msg += u'\n\n*미설치자 목록\n'
            noinstaller = 0
            for user in users :
                user = user.split(',')
                name , gid , ipaddr = user[0] , user[1] , user[2]
                if gid in pass_user : continue
                recv += ',' + gid
                msg += name + ' ' + gid + ' ' + ipaddr + '\n'
                noinstaller += 1
            if noinstaller > 0 : 
                msg += '\n\n해당 프로그램 설치 후 회신 요청드립니다.(fireeye : IS팀 김윤세 / Symantec : IS팀 문찬혁)\n'
                sendalarm(msg.encode('utf-8'), recv)
            time.sleep(0.1)
        return 'send alarm ok - no install user'
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))
        return err

@app.route('/putanyrun',methods=['POST'])
def putanyrun() :        
    try:
        anyrunlog = '/home/apps/hxtool/hx_es_daemon/lib/applog.txt'
        with open(anyrunlog,'a') as f :
            f.write('\r\n' + request.data)
        return 'ok'
    except :
        return 'error'

@app.route('/anymsg',methods=['POST'])
def anymsg() :
    try :
        json_data = json.loads(request.data)
        json_data['users'] += ',yskim04,chmoon'
        if json_data['token'] != 'kakaka5' : return 'Error :' + 'token is not correct'
        if 'team' in json_data : sendalarm(json_data['msg'].encode('utf-8'), json_data['users'].encode('utf-8'), team=json_data['team'])
        else : sendalarm(json_data['msg'].encode('utf-8'), json_data['users'].encode('utf-8'), team='')
        return 'send alarm ok'
    except Exception as err:
        return 'Error : ' + str(err)

#add otp function
#edit interval_length value in /usr/lib/python2.7/site-packages/onetimepass/__init__.py 
import onetimepass as otp
import string,random

TMP_OTP ={}
def gosms(recvphone,msg) :
    sms = sendSms()
    print(sms.sendSms(recvphone, msg, '02-6276-1438'))

def create_otp(user) :
    secret = ''
    for i in range(0,16) :
        secret += random.choice(string.ascii_lowercase)
    otp_token = otp.get_totp(secret)
    TMP_OTP[user] = secret
    f= open('accountphone.txt','r')
    for i in f.readlines():
        if user.lower() not in i.lower() : continue
        phone = i.split(',')[1]
    gosms(phone,'HX OTP : %d'%otp_token)

@app.route('/checkotp',methods=['GET'])
def checkotp():
    otp_token = int(request.args.get('otp'))
    if otp.valid_totp(token=otp_token, secret=TMP_OTP[session['ht_user']]) == True : 
        session['otp'] = True 
        app.logger.info("USER %s OTP OK"%session['ht_user'])
        return redirect('/maruhome')
    else : 
        app.logger.info("USER %s OTP Failed"%session['ht_user'])
        return '<script LANGUAGE=\'JavaScript\'>window.alert("Incorrect OTP Or Timeout. Check New SMS Message And Retry");window.location.href="/otppage";</script>'
    
@app.route('/otppage',methods=['GET'])
def otppage():
    otpvalue = create_otp(session['ht_user'])
    html = '''
        <html>   
    <head>  
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <title> Check OTP </title>  
    <style>   
    Body {  
      font-family: Calibri, Helvetica, sans-serif;  
      background-color: white;  
    }  
    button {   
           background-color: lightblue;   
           width: 100%;  
            color: black;   
            padding: 15px;   
            margin: 10px 0px;   
            border: none;   
            cursor: pointer;   
             }   
     form {   
            border: 3px solid #f1f1f1;   
        }   
     input[type=text], input[type=password] {   
            width: 100%;   
            margin: 8px 0;  
            padding: 12px 20px;   
            display: inline-block;   
            border: 2px solid grey;   
            box-sizing: border-box;   
        }  
     button:hover {   
            opacity: 0.7;   
        }   
     .container {   
            padding: 25px;   
            background-color: lightgrey;  
        }   
    </style>   
    </head>    
    <body>    
        <center> <h1> One Time Password </h1> </center>   
        <form action="/checkotp" method="GET">  
            <div class="container">   
                <input type="text" placeholder="INPUT OTP Number" name="otp" required>  
                <button type="submit">CHECK OTP</button>   
            </div>   
        </form>     
    </body>     
    </html>  
    '''
    return html


###Main ####
############
        
if __name__ == "__main__":
    print DBTYPE
    app.secret_key = crypt_generate_random(32)
    
    app.logger.setLevel(logging.INFO)
    
    # Log early init/failures to stdout
    console_log = logging.StreamHandler(sys.stdout)
    console_log.setFormatter(logging.Formatter('[%(asctime)s] {%(module)s} {%(threadName)s} %(levelname)s - %(message)s'))
    app.logger.addHandler(console_log)
    
    ht_config = hxtool_config('conf.json', logger = app.logger)
    
    # Initialize configured log handlers
    for log_handler in ht_config.log_handlers():
        app.logger.addHandler(log_handler)

    # WSGI request log - when not running under gunicorn or mod_wsgi
    logger = logging.getLogger('werkzeug')
    if logger:
        logger.setLevel(logging.INFO)
        request_log_handler = logging.handlers.RotatingFileHandler('log/access.log', maxBytes=50000, backupCount=15)
        request_log_formatter = logging.Formatter("[%(asctime)s] {%(threadName)s} %(levelname)s - %(message)s")
        request_log_handler.setFormatter(request_log_formatter)
        logger.addHandler(request_log_handler)

    # Start
    app.logger.info('Application starting')

    # Init DB
    ht_db = hxtool_db('hxtool.db', logger = app.logger)
    
    if ht_config['network']['ssl'] == "enabled":
        context = (ht_config['ssl']['cert'], ht_config['ssl']['key'])
        app.run(host=ht_config['network']['listen_address'], port=ht_config['network']['port'], ssl_context=context, threaded=True,debug=True)
    else:
        app.run(host=ht_config['network']['listen_address'], port=ht_config['network']['port'],threaded=True,debug=True)

## running non root 
## su - syslog -c "/usr/bin/python /home/apps/hxtool/HXTool-3.0/hxtool.py &"
'''
# php option monitor (IS-Team)
0 0 * * * /home/apps/php/bin/php -i > /usr/local/checker/www/php/setting.txt

# HXTool Service Check
*/1 * * * * /home/apps/hxtool/checker/hxtool_check.sh > /dev/null 2>&1

# resource check
*/5 * * * * /home/apps/hxtool/checker/resource_check.sh > /dev/null 2>&1
##*/10 * * * * /usr/bin/python /home/apps/hxtool/hx_es_daemon/lib/get_appanyrun_websocket.py > /dev/null 2>&1

# es_daemon restart (daily)
0 11 * * * /usr/bin/python /home/apps/hxtool/hx_es_daemon/es_daemon.0.2.py stop > /dev/null 2>&1
2 11 * * * /usr/bin/python /home/apps/hxtool/hx_es_daemon/es_daemon.0.2.py start > /dev/null 2>&1

# move triage temp file (daily)
0 4 * * * /usr/bin/find /home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files -type f -exec mv -f {} /home/_trash/deleted \;
0 9 * * * /usr/bin/python /home/apps/hxtool/hx_es_daemon/delagents.py
0 */1 * * * /usr/bin/python /home/apps/hxtool/hx_es_daemon/alienvault_cron.py
50 11 * * * /usr/bin/python /home/apps/hxtool/HXTool-3.0/portable_security_daily_report.py
0 3 * * * /usr/bin/find /home/apps/hxtool/hx_es_daemon/es_query_result/filtered_files/ -type f -mtime 60 -exec mv -f {} /home/_trash/deleted \;
*/55 * * * * /usr/bin/python /home/apps/hxtool/HXTool-3.0/make_wordcloud.py
'''