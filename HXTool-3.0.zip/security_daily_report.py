#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
from atlassian import Confluence
from jira import JIRA
import bz2,sys,datetime
import json,os,re
from alarmpol import AlarmSMSAPIClient, GroupwareAlarmAPIClient, sendSms
import logging
import pymysql
logging.basicConfig
reload(sys)
sys.setdefaultencoding('utf-8')
encp = 'BZh91AY&SYR\x85\xd1o\x00\x00\x00\x19\x80 \x00\x10\x00\x05\x07\x1a\x00 \x00"\x03#!\x000\xa4\xc0[\x91\xc9\xf8\xbb\x92)\xc2\x84\x82\x94.\x8bx'
enci = 'BZh91AY&SY\xe8\x1c\x9a\x13\x00\x00\x03\t\x80D\x00\x00*\x08  \x00!\x89\x84!\x80\x8a[\xb7\x8b\xb9"\x9c(Ht\x0eM\t\x80'
dncp = bz2.decompress(encp)
dnci = bz2.decompress(enci)
cafe24_wiki = 'https://wiki.simplexi.com/'
alarm_receiver = 'yskim04'
alarm_receiver = 'yskim04,chlee,jjchoi,yccheon,mhkim10,hjlee,shkim28,celee,chmoon,ghseol'

def check_jira(jira_type,jira_issue,search_keyword,startdate,enddate):
    try :
        jira = JIRA('https://jira.simplexi.com',auth=(dnci,dncp))
        #jql = 'issuekey in childIssuesOf("{}") and reporter = currentUser() and created >= "{} 12:00" and created <= "{} 12:00" and text ~ "{}" order by created desc'.format(jira_issue,startdate,enddate,search_keyword)
        jql = 'reporter = currentUser() and created >= "{} 12:00" and created <= "{} 12:00" and text ~ "{}" order by created desc'.format(startdate,enddate,search_keyword)
        jira_threats , jira_noproblem = [] , []
        for issue in jira.search_issues(jql, maxResults=100):
            coms = jira.comments(issue)
            com_body = ''
            for com in coms :
                if len(com.body) > 500 : continue
                com_body += com.body.encode('utf-8') + ' / '
            line = u'<a href="https://jira.simplexi.com/browse/{}">{}</a> {} [처리내역] : {}<br/>'.format(issue.key,issue.key,issue.fields.summary,com_body.replace('\n','<br/>'))
            if line.find('*Threat*') > -1 : jira_threats.append(line)
            else : jira_noproblem.append(line)
        wiki_body = '<p>[{}]<br/>* 일시 {} 12:00 ~ {} 12:00 <br/>'.format(jira_type,startdate,enddate)
        wiki_body += '# 총 %d건<br/>+ 위협 : %d건<br/>'%(len(jira_threats)+ len(jira_noproblem),len(jira_threats))
        alarm_text = wiki_body
        for line in jira_threats :
            wiki_body += line
            line = line.split(u' [처리내역] :')
            for idx,con in enumerate(line) :
                if idx != 0 : alarm_text += '= ' + con
        wiki_body += '- 비위협 : %d건<br/>'%len(jira_noproblem)
        alarm_text += '<br/>- 비위협 : %d건<br/>'%len(jira_noproblem)
        for line in jira_noproblem:
            wiki_body += line
            line = line.split(u' [처리내역] :')
            for idx,con in enumerate(line) :
                if idx != 0 : alarm_text += '= ' + con
        return wiki_body + '</p><br/>',alarm_text
    except Exception as err :
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        print err

def check_db(startdate,enddate):
    try :
        db_threats , db_noproblem = [] , []
        con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
        cursor = con.cursor()
        rows = cursor.execute('select rule , summary , spenttime , comment ,computer_name from reqtriage where rule IS NOT NULL and summary IS NOT NULL and event_time > \'{0}\''.format(startdate.replace('/','-')))
        rows = cursor.fetchall()
        for row in rows :
            comment = row[0].encode('utf-8') + ' / ' + row[1].encode('utf-8') + ' / '
            if row[3].find('[ Threat ]') > -1 : db_threats.append(comment)
            else : db_noproblem.append(comment)
        wiki_body = '<p>[ Event ]<br/>* 일시 {} 12:00 ~ {} 12:00 <br/>'.format(startdate,enddate)
        wiki_body += '# 총 %d건<br/>+ 위협 : %d건<br/>'%(len(db_threats)+ len(db_noproblem),len(db_threats))
        alarm_text = wiki_body
        for line in db_threats :
            wiki_body += line + '<br/>'
            alarm_text += '= ' + line
        wiki_body += '- 비위협 : %d건<br/>'%len(db_noproblem)
        alarm_text += '- 비위협 : %d건<br/>'%len(db_noproblem)
        for line in db_noproblem:
            wiki_body += line + '<br/>'
            alarm_text += '= ' + line
        return wiki_body.replace('<br>','<br/>') + '</p><br/>', alarm_text.replace('= ','\n= ')
    except Exception as err :
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        print err

def make_alarm_text(startdate,enddate,device,wiki_url,alarm_text):
    alarm_rpt = '# {}~{}_일일_이벤트_보고서({}) \n'.format(startdate,enddate,device)
    alarm_rpt += alarm_text.replace('<br/>','\n').replace('</p>','\n').replace('<p>','\n') + '\nWiki URL %s'%wiki_url
    alarm_rpt = re.sub('<.{1,10}>','',alarm_rpt)
    return alarm_rpt

def sendalarm(msg, user_id, team=''):
    try:
        user_id = user_id.replace(' ', '')
        team = team.replace(' ', '')
        msg = msg.replace('\\','/')
        #logger.info("sendGroupwareAlarm receiver:{receiver}".format(receiver=user_id))
        # print msg
        if team == '':
            client = GroupwareAlarmAPIClient('yskim04', user_id, msg)
        else:
            client = GroupwareAlarmAPIClient('yskim04', 'dept', msg, team)
        client.request()
    except Exception as err :
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        print err

def report(startdate):
    try :
        confluence = Confluence(url=cafe24_wiki,username=dnci,password=dncp)
        enddate = datetime.datetime.today().strftime("%Y/%m/%d")
        if startdate == 'portable' :
            startdate = (datetime.date.today() - datetime.timedelta(1)).strftime('%Y/%m/%d')
            startdate = raw_input('start date (ex) 2019/04/11: ')
        # config 파일에서 읽어오도록 변경하기
        event_issue = 'SECURITY-32283' # 매 년 생성하는 event 처리 지라 키
        es_ioc_issue = 'SECURITY-27609' # 매 년 생성하는 ioc enterprsie search  지라 키
        wiki_parent = '1616439512' # 매 월 생성하는 위키 페이지 소스코드의 "ajs-page-id" 값
        device = 'fireeye'
        wiki_body ,wiki_tmp,alarm_text,alarm_tmp = '','','',''
        #wiki_tmp, alarm_tmp = check_jira('이벤트 분석 결과',event_issue,'\\\\[securityevent\\\\]',startdate,enddate)
        wiki_tmp, alarm_tmp = check_db(startdate,enddate)
        wiki_body += wiki_tmp
        alarm_text += alarm_tmp
        wiki_tmp, alarm_tmp = check_jira('IOC Enterprise Search 결과',es_ioc_issue,'\\\\[IOC HX 검색\\\\]',startdate,enddate)
        wiki_body += wiki_tmp
        alarm_text += alarm_tmp
        wiki_body = wiki_body.replace('&','-').replace('?','').replace("'","")
        response = confluence.create_page('is', u'%s_DailyReport [Fireeye]'%enddate, wiki_body.replace(';',''), parent_id=wiki_parent, type='page')
        #print response
        # input/output error
        '''
        if 1==1 : # startdate == 'portable' :
            print wiki_body
            print json.dumps(response,indent=2)
        '''
        wiki_url = 'https://wiki.simplexi.com/pages/viewpage.action?pageId=%s'%(response['body']['storage']['_expandable']['content'].split('/')[-1])
        alarm_text = make_alarm_text(startdate,enddate,device,wiki_url,alarm_text).replace(';','')
        sendalarm(alarm_text.encode('utf-8'),alarm_receiver)
        return wiki_body
    except Exception as err :
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        return wiki_body + '\n<br>' + err + '\n<br>' + json.dumps(response)
        return err

#print report('portable')

'''
jira issue 의 fields 값
#dir(issue.fields)
['__class__', '__delattr__', '__dict__', '__doc__', '__format__', '__getattribute__', '__hash__', '__init__', '__module__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__', u'aggregateprogress', u'aggregatetimeestimate', u'aggregatetimeoriginalestimate', u'aggregatetimespent', u'assignee', u'components', u'created', u'creator', u'customfield_10002',커스텀필드 중간생략,u'customfield_36200', u'description', u'duedate', u'environment', u'fixVersions', u'issuelinks', u'issuetype', u'labels', u'lastViewed', u'parent', u'priority', u'progress', u'project', u'reporter', u'resolution', u'resolutiondate', u'security', u'status', u'subtasks', u'summary', u'timeestimate', u'timeoriginalestimate', u'timespent', u'updated', u'versions', u'votes', u'watches', u'workratio']
'''
# atlassian python api : https://atlassian-python-api.readthedocs.io/en/latest/confluence.html
# jara api : https://jira.readthedocs.io/en/latest/examples.html?highlight=search
#sudo pip install atlassian-python-api
#sudo pip install jira


# is팀 space_key in cafe24 html <meta id="confluence-space-key" name="confluence-space-key" content="is">
# page_id in cafe24 html <meta name="ajs-page-id" content="1377472370">

#page_id 로 page 가 속해있는 space 확인하기
#print(confluence.get_page_space('881068647'))

#page_id로 하위 페이지 정보 가져오기 , page_id 1377472370 = 201904 일일이벤트보고 wiki
#print(json.dumps(confluence.get_page_child_by_type('1377472370', type='page', start=None, limit=None),indent=2,ensure_ascii = False ))

# Create page from scratch , confluence.create_page(space, title, body, parent_id=None, type='page')
#print (json.dumps(confluence.create_page('is', 'daily event report fireeyehx automatic test2', 'test', parent_id='1377472370', type='page'),indent=2,ensure_ascii = False ))

#remove page , confluence.remove_page(page_id, status=None)
#print(confluence.remove_page('1387308501', status=None))

# jira assinee 변경 , 결과값 true,false
# print(json.dumps(jira.assign_issue('SECURITY-30301', 'yskim04')))

#http://domain.com/rest/api/2/search?jql=reporter=ram and created &gt;= "2013/01/01" and created &lt;= "2013/03/15"

#wiki body 입력 시 태그에 주의 ex: <br> tag 삽입 시 에러


