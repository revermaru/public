#!/usr/bin/env python
# -*- coding: utf-8 -*-

# marucode + original
##################################################
# hxTool - 3rd party user-interface for FireEye HX 
#
# Henrik Olsson
# henrik.olsson@fireeye.com
#
# For license information see the 'LICENSE' file
##################################################

# Core python imports
import base64
import sys
import logging
import json
import io
import os
import datetime
import threading
import time
from functools import wraps
import xml.etree.ElementTree as ET
from string import Template
from xml.sax.saxutils import escape as xmlescape
import re
from flask_autoindex import AutoIndex

reload(sys)
sys.setdefaultencoding('utf-8')

try:
    import StringIO
except ImportError:
    # Running on Python 3.x
    from io import StringIO
    from io import BytesIO

# Flask imports
try:
    from flask import Flask, request, Response, session, redirect, render_template, send_file, g, url_for, abort
    from jinja2 import evalcontextfilter, Markup, escape
except ImportError:
    print("hxtool requires the 'Flask' module, please install it.")
    exit(1)
    
# pycryptodome imports
try:
    from Crypto.Cipher import AES
    from Crypto.Protocol.KDF import PBKDF2
    from Crypto.Hash import HMAC, SHA256
except ImportError:
    print("hxtool requires the 'pycryptodome' module, please install it.")
    exit(1)
    
# hx_tool imports
from hx_lib import *
from hxtool_formatting import *
from hxtool_db import *
from hxtool_process import *
from hxtool_config import *
from hxtool_data_models import *


#app = Flask(__name__, static_url_path='/static')
app = Flask(__name__, static_url_path='/static')
RESULT_DIR = '/home/apps/hxtool/hx_es_daemon/es_query_result'
AutoIndex(app, RESULT_DIR,add_url_rules=True)
HXTOOL_API_VERSION = 1

ht_config = None
ht_db = None

def valid_session_required(f):
    @wraps(f)
    def is_session_valid(*args, **kwargs):
        if (session and 'ht_user' in session and 'ht_api_object' in session):
            o = HXAPI.deserialize(session['ht_api_object'])
            if o.restIsSessionValid():
                kwargs['hx_api_object'] = o
                return f(*args, **kwargs)
            else:
                app.logger.info("The HX API token for the current session has expired, redirecting to the login page.")
        return redirect(url_for('login', redirect_uri = request.full_path))    
    return is_session_valid

### Flask/Jinja Filters
####################################

_newline_re = re.compile(r'(?:\r\n|\r|\n){1,}')
@app.template_filter()
@evalcontextfilter
def nl2br(eval_ctx, value):
    result = '<br />\n'.join(escape(p) for p in _newline_re.split(value or ''))
    if eval_ctx.autoescape:
        result = Markup(result)
    return result

# Dashboard page
################

@app.route('/')
@valid_session_required
def index(hx_api_object):
    if not 'render' in request.args:
        return render_template('ht_index_ph.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port))
    else:
    
        mytime = "today"
        time_matrix = {
            "today"    :    datetime.datetime.now(),
            "week"    :    datetime.datetime.now() - datetime.timedelta(days=7),
            "2weeks":    datetime.datetime.now() - datetime.timedelta(days=14),
            "30days":    datetime.datetime.now() - datetime.timedelta(days=30),
            "60days":    datetime.datetime.now() - datetime.timedelta(days=60),
            "90days":    datetime.datetime.now() - datetime.timedelta(days=90),
            "182days":    datetime.datetime.now() - datetime.timedelta(days=182),
            "365days":    datetime.datetime.now() - datetime.timedelta(days=365)
        }
        
        if 'time' in request.args and request.args.get('time') in time_matrix:
            mytime = request.args.get('time')
        
        starttime = time_matrix.get(mytime)
        
        interval_select = ""
        for i in ["today", "week", "2weeks", "30days", "60days", "90days", "182days", "365days"]:
                interval_select += '<option value="/?time={0}"{1}>{2}</option>'.format(i, ' selected="selected"' if i == mytime else '', i)
            
        base = datetime.datetime.today()
    
        (ret, response_code, response_data) = hx_api_object.restGetAlertsTime(starttime.strftime("%Y-%m-%d"), base.strftime("%Y-%m-%d"))
        
        nr_of_alerts = len(response_data)
        
        # Recent alerts
        alerts = formatDashAlerts(response_data, hx_api_object)
        
        stats = [{'value': 0, 'label': 'Exploit'}, {'value': 0, 'label': 'IOC'}, {'value': 0, 'label': 'Malware'}]
        if nr_of_alerts > 0:
            stats[0]['value'] = len([_ for _ in response_data if _['source'] == "EXD"])
            stats[1]['value'] = len([_ for _ in response_data if _['source'] == "IOC"])
            stats[2]['value'] = len([_ for _ in response_data if _['source'] == "MAL"])
            
            stats[0]['value'] = round((stats[0]['value'] / float(nr_of_alerts)) * 100)
            stats[1]['value'] = round((stats[1]['value'] / float(nr_of_alerts)) * 100)
            stats[2]['value'] = round((stats[2]['value'] / float(nr_of_alerts)) * 100)

        # Event timeline last 30 days
        talert_dates = {}
    
        
        delta = (base - starttime)
        
        date_list = [base - datetime.timedelta(days=x) for x in range(0, delta.days + 1)]
        for date in date_list:
            talert_dates[date.strftime("%Y-%m-%d")] = 0

        ioclist = []
        exdlist = []
        mallist = []
        
        for talert in response_data:
            if talert['source'] == "IOC":
                if not talert['agent']['_id'] in ioclist:
                    ioclist.append(talert['agent']['_id'])
                
            if talert['source'] == "EXD":
                if not talert['agent']['_id'] in exdlist:
                    exdlist.append(talert['agent']['_id'])
            
            if talert['source'] == "MAL":
                if not talert['agent']['_id'] in mallist:
                    mallist.append(talert['agent']['_id'])            
            
            date = talert['event_at'][0:10]
            if date in talert_dates.keys():
                talert_dates[date] = talert_dates[date] + 1

        ioccounter = len(ioclist)
        exdcounter = len(exdlist)
        malcounter = len(mallist)
        
        talerts_list = []
        for key in talert_dates:
            talerts_list.append({"date": str(key), "count": talert_dates[key]})

        # Info table
        (ret, response_code, response_data) = hx_api_object.restListHosts()
        hostcounter = len(response_data['data']['entries']);
        contcounter = len([_ for _ in response_data['data']['entries'] if _['containment_state'] != "normal"]);

        (ret, response_code, response_data) = hx_api_object.restListSearches()
        searchcounter = len([_ for _ in response_data['data']['entries'] if _['state'] == "RUNNING"])

        (ret, response_code, response_data) = hx_api_object.restListBulkAcquisitions()
        blkcounter = len([_ for _ in response_data['data']['entries'] if _['state'] == "RUNNING"]);

        return render_template('ht_index.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), alerts=alerts, iocstats=json.dumps(stats), timeline=json.dumps(talerts_list), contcounter=str(contcounter), hostcounter=str(hostcounter), malcounter=str(malcounter), searchcounter=str(searchcounter), blkcounter=str(blkcounter), exdcounter=str(exdcounter), ioccounter=str(ioccounter), iselect=interval_select)
            
### Jobdash
##########

@app.route('/jobdash', methods=['GET', 'POST'])
@valid_session_required
def jobdash(hx_api_object):
    blk = restListBulkAcquisitions(session['ht_token'], session['ht_ip'], session['ht_port'])
    jobsBulk = formatBulkTableJobDash(c, conn, blk, session['ht_profileid'])

    s = restListSearches(session['ht_token'], session['ht_ip'], session['ht_port'])
    jobsEs = formatListSearchesJobDash(s)
    
    
    return render_template('ht_jobdash.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), jobsBulk=jobsBulk, jobsEs=jobsEs)

### Hosts
##########

@app.route('/hosts', methods=['GET', 'POST'])
@valid_session_required
def hosts(hx_api_object):
    # Host investigation panel
    if 'host' in request.args.keys():
        (ret, response_code, response_data) = hx_api_object.restGetHostSummary(request.args.get('host'))
        myhosthtml = formatHostInfo(response_data, hx_api_object)
        return render_template('ht_hostinfo.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), hostinfo=myhosthtml)
    
    # Host search returns table of hosts
    elif 'q' in request.args.keys():
        (ret, response_code, response_data) = hx_api_object.restFindHostsBySearchString(request.args.get('q'))
        myhostlist = formatHostSearch(response_data, hx_api_object)
        return render_template('ht_hostsearch.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), myhostlist=myhostlist)
        
    # Contain a host
    elif 'contain' in request.args.keys():
        (ret, response_code, response_data) = hx_api_object.restRequestContainment(request.args.get('contain'))
        if ret:
            app.logger.info('Containment request issued - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('contain'))
            (ret, response_code, response_data) = hx_api_object.restApproveContainment(request.args.get('contain'))
            if ret:
                app.logger.info('Containment request approved - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('contain'))
        return redirect(request.args.get('url'), code=302)
    
    # Uncontain a host
    elif 'uncontain' in request.args.keys():
        (ret, response_code, response_data) = hx_api_object.restRemoveContainment(request.args.get('uncontain'))
        if ret:
            app.logger.info('Uncontained issued - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('uncontain'))
        return redirect(request.args.get('url'), code=302)
    
    # Approve containment
    elif 'appcontain' in request.args.keys():
        (ret, response_code, response_data) = hx_api_object.restApproveContainment(request.args.get('appcontain'))
        if ret:
            app.logger.info('Containment approval - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('appcontain'))
        return redirect(request.args.get('url'), code=302)
        
    # Requests triage
    elif 'triage' in request.args.keys():
    
        # Standard triage
        if request.args.get('type') == "standard":
            (ret, response_code, response_data) = hx_api_object.restAcquireTriage(request.args.get('triage'))
            if ret:
                app.logger.info('Standard Triage requested - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('triage'))
        
        # Triage with predetermined time
        elif request.args.get('type') in ("1", "2", "4", "8"):
                mytime = datetime.datetime.now() - timedelta(hours = int(request.args.get('type')))
                (ret, response_code, response_data) = hx_api_object.restAcquireTriage(request.args.get('triage'), mytime.strftime('%Y-%m-%d %H:%M:%S'))
                if ret:
                    app.logger.info('Triage requested around timestamp - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('triage'))
        
        # Triage with custom timestamp
        elif request.args.get('type') == "timestamp":
            (ret, response_code, response_data) = hx_api_object.restAcquireTriage(request.args.get('triage'), request.args.get('timestampvalue'))
            if ret:
                app.logger.info('Triage requested around timestamp - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('triage'))
            
        return redirect(request.args.get('url'), code=302)
        
    # File acquisition request
    elif 'fileaq' in request.args.keys():
        if request.args.get('type') and request.args.get('filepath') and request.args.get('filename'):
            
            if request.args.get('type') == "API":
                mode = True
            if request.args.get('type') == "RAW":
                mode = False
                
            (ret, response_code, response_data) = hx_api_object.restAcquireFile(request.args.get('fileaq'), request.args.get('filepath'), request.args.get('filename'), mode)
            if ret:
                app.logger.info('File acquisition requested - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('fileaq'))
            
        return redirect(request.args.get('url'), code=302)
    elif 'acq' in request.form.keys():

        fc = request.files['script']                
        myscript = fc.read()
        
        (ret, response_code, response_data) = hx_api_object.restNewAcquisition(request.form.get('acq'), request.form.get('name'), myscript)
        if ret:
            app.logger.info('Data acquisition requested - User: %s@%s:%s - host: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('acq'))

        return redirect(request.form.get('url'), code=302)
    else:
        return redirect('/', code=302)
            

### Triage popup
@app.route('/triage', methods=['GET'])
@valid_session_required
def triage(hx_api_object):
    triageid= request.args.get('host')
    url = request.args.get('url')
    mytime = datetime.datetime.now()
    return render_template('ht_triage.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), triageid=triageid, url=url, now=mytime.strftime('%Y-%m-%d %H:%M:%S'))

        
### File acquisition popup
@app.route('/fileaq', methods=['GET'])
@valid_session_required
def fileaq(hx_api_object):
    hostid = request.args.get('host')
    url = request.args.get('url')
    return render_template('ht_fileaq.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), hostid=hostid, url=url)

        
### Acquisition popup
@app.route('/acq', methods=['GET'])
@valid_session_required
def acq(hx_api_object):
    hostid = request.args.get('host')
    url = request.args.get('url')
    return render_template('ht_acq.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), hostid=hostid, url=url)
        
### Alerts Page
###################

@app.route('/alerts', methods=['GET', 'POST'])
@valid_session_required
def alerts(hx_api_object):
        
    if request.method == "POST" and 'annotateText' in request.form:
        # We have a new annotation
        ht_db.alertCreate(session['ht_profileid'], request.form['annotateId'])
        ht_db.alertAddAnnotation(session['ht_profileid'], request.form['annotateId'], request.form['annotateText'], request.form['annotateState'], session['ht_user'])
        app.logger.info('New annotation - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/alerts?acount=30", code=302)
    
    if not 'render' in request.args:
        return render_template('ht_alerts_ph.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port))
    else:
        if 'acount' in request.args and request.args['acount']:
            acount = int(request.args['acount'])
        else:
            acount = 50
    
        acountselect = ""
        for i in [10, 20, 30, 50, 100, 250, 500, 1000]:
            acountselect += '<option value="/alerts?acount={0}"{1}>Last {2} Alerts</option>'.format(i, ' selected="selected"' if i == acount else '', i)
                
        (ret, response_code, response_data) = hx_api_object.restGetAlerts(acount)
        alertshtml = formatAlertsTable(response_data, hx_api_object, session['ht_profileid'], ht_db)
        return render_template('ht_alerts.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), alerts=alertshtml, acountselect=acountselect)
        
@app.route('/annotatedisplay', methods=['GET'])
@valid_session_required
def annotatedisplay(hx_api_object):    
    if 'alertid' in request.args:
        alert = ht_db.alertGet(session['ht_profileid'], request.args.get('alertid'))
        an = None
        if alert:
            an = alert['annotations']
        annotatetable = formatAnnotationTable(an)

    return render_template('ht_annotatedisplay.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), annotatetable=annotatetable)


#### Enterprise Search
#########################

@app.route('/search', methods=['GET', 'POST'])
@valid_session_required
def search(hx_api_object):    
    # If we get a post it's a new sweep
    if request.method == 'POST':
        f = request.files['newioc']
        rawioc = f.read()
        (ret, response_code, response_data) = hx_api_object.restSubmitSweep(rawioc, request.form['sweephostset'])
        app.logger.info('New Enterprise Search - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)

    (ret, response_code, response_data) = hx_api_object.restListSearches()
    searches = formatListSearches(response_data)
    
    (ret, response_code, response_data) = hx_api_object.restListHostsets()
    hostsets = formatHostsets(response_data)
    
    return render_template('ht_searchsweep.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), searches=searches, hostsets=hostsets)

@app.route('/searchresult', methods=['GET'])
@valid_session_required
def searchresult(hx_api_object):
    if request.args.get('id'):
        (ret, response_code, response_data) = hx_api_object.restGetSearchResults(request.args.get('id'))
        res = formatSearchResults(response_data)
        return render_template('ht_search_dd.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), result=res)
            
@app.route('/searchaction', methods=['GET'])
@valid_session_required
def searchaction(hx_api_object):
    if request.args.get('action') == "stop":
        (ret, response_code, response_data) = hx_api_object.restCancelJob('searches', request.args.get('id'))
        app.logger.info('User access: Enterprise Search action STOP - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/search", code=302)

    if request.args.get('action') == "remove":
        (ret, response_code, response_data) = hx_api_object.restDeleteJob('searches', request.args.get('id'))
        app.logger.info('User access: Enterprise Search action REMOVE - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/search", code=302)
        
#### Build a real-time indicator
####################################

@app.route('/buildioc', methods=['GET', 'POST'])
@valid_session_required
def buildioc(hx_api_object):
    # New IOC to be created
    if request.method == 'POST':
    
        if request.form['platform'] == "all":
            myplatforms = ['win', 'osx']
        else:
            myplatforms = request.form['platform'].split(",")
            
        (ret, response_code, response_data) = hx_api_object.restAddIndicator(session['ht_user'], request.form['iocname'], myplatforms, request.form['cats'])
        app.logger.info('New indicator created - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        
        ioc_guid = response_data['data']['_id']

        condEx = []
        condPre = []

        for fieldname, value in request.form.items():
            if "cond_" in fieldname:
                condComp = fieldname.split("_")
                if (condComp[2] == "presence"):
                    condPre.append(value.rstrip(","))
                elif (condComp[2] == "execution"):
                    condEx.append(value.rstrip(","))

        for data in condPre:
            data = """{"tests":[""" + data + """]}"""
            data = data.replace('\\', '\\\\')
            (ret, response_code, response_data) = hx_api_object.restAddCondition(request.form['cats'], ioc_guid, 'presence', data)
            
        for data in condEx:
            data = """{"tests":[""" + data + """]}"""
            data = data.replace('\\', '\\\\')
            (ret, response_code, response_data) = hx_api_object.restAddCondition(request.form['cats'], ioc_guid, 'execution', data)
            
    (ret, response_code, response_data) = hx_api_object.restListIndicatorCategories()
    cats = formatCategoriesSelect(response_data)
    return render_template('ht_buildioc.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), cats=cats)

### Manage Indicators
#########################

@app.route('/indicators', methods=['GET', 'POST'])
@valid_session_required
def indicators(hx_api_object):
    if request.method == 'POST':
        
        # Export selected indicators
        iocs = []
        for postvalue in request.form:
            if postvalue.startswith('ioc___'):
                sval = postvalue.split("___")
                iocname = sval[1]
                ioccategory = sval[2]
                platforms = sval[3]
                iocs.append({'uuid':request.form.get(postvalue), 'name':iocname, 'category':ioccategory, 'platforms':platforms})
        
        ioclist = {}
        for ioc in iocs:
            #Data structure for the conditions
            ioclist[ioc['uuid']] = {}
            ioclist[ioc['uuid']]['execution'] = []
            ioclist[ioc['uuid']]['presence'] = []
            ioclist[ioc['uuid']]['name'] = ioc['name']
            ioclist[ioc['uuid']]['category'] = ioc['category']
            ioclist[ioc['uuid']]['platforms'] = ioc['platforms']

            #Grab execution indicators
            (ret, response_code, response_data) = hx_api_object.restGetCondition(ioc['category'], ioc['uuid'], 'execution')
            for item in response_data['data']['entries']:
                ioclist[ioc['uuid']]['execution'].append(item['tests'])

            #Grab presence indicators
            (ret, response_code, response_data) = hx_api_object.restGetCondition(ioc['category'], ioc['uuid'], 'presence')
            for item in response_data['data']['entries']:
                ioclist[ioc['uuid']]['presence'].append(item['tests'])
                    
        ioclist_json = json.dumps(ioclist, indent=4)
        
        if len(iocs) == 1:
            iocfname = iocs[0]['name'] + ".ioc"
        else:
            iocfname = "multiple_indicators.ioc"
        
        try:
            buffer = BytesIO()
        except NameError:
            # Python 2.x, try StringIO
            buffer = StringIO()
        buffer.write(ioclist_json.encode('utf-8'))
        buffer.seek(0)
        app.logger.info('Indicator(s) exported - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return send_file(buffer, attachment_filename=iocfname, as_attachment=True)

    (ret, response_code, response_data) = hx_api_object.restListIndicators()
    indicators = formatIOCResults(response_data)
    return render_template('ht_indicators.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), indicators=indicators)

@app.route('/indicatorcondition')
@valid_session_required
def indicatorcondition(hx_api_object):
    uuid = request.args.get('uuid')
    category = request.args.get('category')

    (ret, response_code, condition_class_presence) = hx_api_object.restGetCondition(category, uuid, 'presence')
    (ret, response_code, condition_class_execution) = hx_api_object.restGetCondition(category, uuid, 'execution')
    
    conditions = formatConditions(condition_class_presence, condition_class_execution)

    return render_template('ht_indicatorcondition.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), conditions=conditions)

        

@app.route('/categories', methods=['GET', 'POST'])
@valid_session_required
def categories(hx_api_object):
    if request.method == 'POST':
        catname = request.form.get('catname')
        (ret, response_code, response_data) = hx_api_object.restCreateCategory(str(catname))
        app.logger.info('New indicator category created - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)


    (ret, response_code, response_data) = hx_api_object.restListIndicatorCategories()
    categories = formatCategories(response_data)
    
    return render_template('ht_categories.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), categories=categories)

@app.route('/import', methods=['POST'])
@valid_session_required
def importioc(hx_api_object):
    if request.method == 'POST':
    
        fc = request.files['iocfile']
        iocs = json.loads(fc.read())
        
        for iockey in iocs:
            myplatforms = iocs[iockey]['platforms']
            if ',' in myplatforms:
                myplatforms = myplatforms.split(",")
    
            (ret, response_code, response_data) = hx_api_object.restAddIndicator(session['ht_user'], iocs[iockey]['name'], myplatforms, iocs[iockey]['category'])

            ioc_guid = response_data['data']['_id']
            
            for p_cond in iocs[iockey]['presence']:
                data = json.dumps(p_cond)
                data = """{"tests":""" + data + """}"""
                (ret, response_code, response_data) = hx_api_object.restAddCondition(iocs[iockey]['category'], ioc_guid, 'presence', data)

            for e_cond in iocs[iockey]['execution']:
                data = json.dumps(e_cond)
                data = """{"tests":""" + data + """}"""
                (ret, response_code, response_data) = hx_api_object.restAddCondition(iocs[iockey]['category'], ioc_guid, 'execution', data)
        
        app.logger.info('New indicator imported - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
    
    return redirect("/indicators", code=302)



### Bulk Acqusiitions
#########################

@app.route('/bulk', methods=['GET', 'POST'])
@valid_session_required
def listbulk(hx_api_object):
    if request.method == 'POST':
        f = request.files['bulkscript']
        bulk_acquisition_script = f.read()
        (ret, response_code, response_data) = hx_api_object.restListHostsInHostset(request.form['bulkhostset'])
        hosts = [{'_id' : host['_id']} for host in response_data['data']['entries']]
        (ret, response_code, response_data) = hx_api_object.restNewBulkAcq(bulk_acquisition_script, hosts = hosts, comment = json.dumps({'hostset_id' : str(request.form['bulkhostset'])}))
        app.logger.info('New bulk acquisition - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)

    (ret, response_code, response_data) = hx_api_object.restListBulkAcquisitions()
    bulktable = formatBulkTable(ht_db, response_data, session['ht_profileid'])
    
    (ret, response_code, response_data) = hx_api_object.restListHostsets()
    hostsets = formatHostsets(response_data)
    
    return render_template('ht_bulk.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), bulktable=bulktable, hostsets=hostsets)
    
@app.route('/bulkdetails', methods = ['GET'])
@valid_session_required
def bulkdetails(hx_api_object):
    if request.args.get('id'):

        (ret, response_code, response_data) = hx_api_object.restListBulkHosts(request.args.get('id'))
        bulktable = formatBulkHostsTable(response_data)

        return render_template('ht_bulk_dd.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), bulktable=bulktable)
    else:
        abort(404)


# TODO: These two functions should be merged at some point
@app.route('/bulkdownload', methods = ['GET'])
@valid_session_required
def bulkdownload(hx_api_object):
    if request.args.get('id'):
        (ret, response_code, response_data) = hx_api_object.restDownloadFile(request.args.get('id'))
        if ret:
            app.logger.info('Bulk acquisition download - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
            app.logger.info('Acquisition download - User: %s@%s:%s - URL: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('id'))
            flask_response = Response(iter_chunk(response_data))
            flask_response.headers['Content-Type'] = response_data.headers['Content-Type']
            flask_response.headers['Content-Disposition'] = response_data.headers['Content-Disposition']
            return flask_response
        else:
            return "HX controller responded with code {0}: {1}".format(response_code, response_data)
    else:
        abort(404)

        
@app.route('/download')
@valid_session_required
def download(hx_api_object):
    if request.args.get('id'):
        if request.args.get('content') == "json":
            (ret, response_code, response_data) = hx_api_object.restDownloadFile(request.args.get('id'), accept = "application/json")
        else:
            (ret, response_code, response_data) = hx_api_object.restDownloadFile(request.args.get('id'))
        if ret:
            app.logger.info('Acquisition download - User: %s@%s:%s - URL: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('id'))
            flask_response = Response(iter_chunk(response_data))
            flask_response.headers['Content-Type'] = response_data.headers['Content-Type']
            flask_response.headers['Content-Disposition'] = response_data.headers['Content-Disposition']
            return flask_response
        else:
            return "HX controller responded with code {0}: {1}".format(response_code, response_data)
    else:
        abort(404)        

@app.route('/download_file')
@valid_session_required
def download_multi_file_single(hx_api_object):
    if 'mf_id' in request.args and 'acq_id' in request.args:
        multi_file = ht_db.multiFileGetById(request.args.get('mf_id'))
        if multi_file:
            file_records = list(filter(lambda f: int(f['acquisition_id']) == int(request.args.get('acq_id')), multi_file['files']))
            if file_records and file_records[0]:
                path = get_download_full_path(hx_api_object.hx_host, request.args.get('mf_id'), 'multi_file', file_records[0]['hostname'], request.args.get('acq_id'))
                app.logger.info('Acquisition download - User: %s@%s:%s - URL: %s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, request.args.get('acq_id'))
                return send_file(path, attachment_filename=path.rsplit('/',1)[-1], as_attachment=True)
        else:
            return "HX controller responded with code {0}: {1}".format(response_code, response_data)
    abort(404)        

@app.route('/bulkaction', methods=['GET'])
@valid_session_required
def bulkaction(hx_api_object):

    if request.args.get('action') == "stop":
        (ret, response_code, response_data) = hx_api_object.restCancelJob('acqs/bulk', request.args.get('id'))
        app.logger.info('Bulk acquisition action STOP - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/bulk", code=302)
        
    if request.args.get('action') == "remove":
        (ret, response_code, response_data) = hx_api_object.restDeleteJob('acqs/bulk', request.args.get('id'))
        app.logger.info('Bulk acquisition action REMOVE - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/bulk", code=302)    
        
    if request.args.get('action') == "download":
        (ret, response_code, response_data) = hx_api_object.restListBulkHosts(request.args.get('id'))
        hosts = { host['host']['_id'] : {'downloaded' : False, 'hostname' :  host['host']['hostname']} for host in response_data['data']['entries'] }
        
        hostset_id = -1
        (ret, response_code, response_data) = hx_api_object.restGetBulkDetails(request.args.get('id'))
        if ret and response_data['data']['comment'] and 'hostset_id' in response_data['data']['comment']:
            hostset_id = int(json.loads(response_data['data']['comment'])['hostset_id'])
            
        ret = ht_db.bulkDownloadCreate(session['ht_profileid'], request.args.get('id'), hosts, hostset_id = hostset_id)
        app.logger.info('Bulk acquisition action DOWNLOAD - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/bulk", code=302)
        
    if request.args.get('action') == "stopdownload":
        ret = ht_db.bulkDownloadStop(session['ht_profileid'], request.args.get('id'))
        # Delete should really be done by the background processor
        ret = ht_db.bulkDownloadDelete(session['ht_profileid'], request.args.get('id'))
        app.logger.info('Bulk acquisition action STOP DOWNLOAD - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/bulk", code=302)
                
### Reports
############

@app.route('/reports')
@valid_session_required
def reports(hx_api_object):
    return render_template('ht_reports.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port))

@app.route('/reportgen')
@valid_session_required
def reportgen(hx_api_object):
    if request.args.get('id'):
        if request.args.get('id') == "1":
            reportFrom = request.args.get('startDate')
            reportTo = request.args.get('stopDate')
            (ret, response_code, response_data) = hx_api_object.restGetAlertsTime(reportFrom, reportTo)
            
            if request.args.get('type') == "csv":
                reportdata = str(formatAlertsCsv(response_data, hx_api_object))
                fname = 'report.csv'
                
        if request.args.get('id') == "2":
            reportFrom = request.args.get('startDate')
            reportTo = request.args.get('stopDate')        
            # add code here for report type 2
        
        return send_file(io.BytesIO(reportdata), attachment_filename=fname, as_attachment=True)

def submit_bulk_job(hx_api_object, hostset, script_xml, handler=None):
    (ret, response_code, response_data) = hx_api_object.restListHostsInHostset(hostset)
    hosts = []
    bulk_download_entry_hosts = {}
    for host in response_data['data']['entries']:
        hosts.append({'_id' : host['_id']})
        bulk_download_entry_hosts[host['_id']] = {'downloaded' : False, 'hostname' : host['hostname']}
    (ret, response_code, response_data) = hx_api_object.restNewBulkAcq(script_xml, hosts = hosts)
    if ret:
        bulkid = response_data['data']['_id']
        # Store Job Record
        #TODO: Implement bulkDownloadCreate
        bulk_job_entry = ht_db.bulkDownloadCreate(session['ht_profileid'], bulkid, bulk_download_entry_hosts, hostset, post_download_handler = handler)
        return bulkid
    return None

@app.route('/multifile', methods=['GET', 'POST'])
@valid_session_required
def multifile(hx_api_object):
    profile_id = session['ht_profileid']
    if request.args.get('stop'):
        mf_job = ht_db.multiFileGetById(request.args.get('stop'))
        if mf_job:
            success = True
            #TODO: Stop each file acquisition or handle solely in remove?
            if success:
                ht_db.multiFileStop(mf_job.eid)
                app.logger.info('MultiFile Job ID {0} action STOP - User: {1}@{2}:{3}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, mf_job.eid))

    elif request.args.get('remove'):
        mf_job = ht_db.multiFileGetById(request.args.get('remove'))
        if mf_job:
            success = True
            for f in mf_job['files']:
                uri = 'acqs/files/{0}'.format(f['acquisition_id'])
                (ret, response_code, response_data) = hx_api_object.restDeleteFile(uri)
                #TODO: Replace with delete of file from record
                if not f['downloaded']:
                    self._ht_db.multiFileUpdateFile(self.profile_id, f.eid, f['acquisition_id'])
                if not ret:
                    app.logger.error("Failed to remove file acquisition {0}".format(f['acquisition_id']))
                    success = False
            if success:
                ht_db.multiFileDelete(mf_job.eid)
                app.logger.info('MultiFile Job ID {0} action REMOVE - User: {1}@{2}:{3}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, mf_job.eid))

    #TODO: Make Configurable both from GUI and config file?
    elif request.method == 'POST':
        MAX_FILE_ACQUISITIONS = 50
        
        display_name = ('display_name' in request.form) and request.form['display_name'] or "{0} job at {1}".format(session['ht_user'], datetime.datetime.now())
        use_api_mode = ('use_raw_mode' not in request.form)

        # Collect User Selections
        file_jobs, choices, listing_ids = [], {}, set([])
        choice_re = re.compile('^choose_file_(\d+)_(\d+)$')
        for k, v in list(request.form.items()):
            m = choice_re.match(k)
            if m:
                fl_id = int(m.group(1))
                listing_ids.add(fl_id)
                choices.setdefault(fl_id, []).append(int(m.group(2)))
        if choices:
            choice_files, agent_ids = [], {}
            for fl_id, file_ids in list(choices.items()):
                # Gather the records for files to acquire from the file listing
                file_listing = ht_db._db.table('file_listing').get(eid=int(fl_id))
                if not file_listing:
                    app.logger.warn('File Listing %s does not exist - User: %s@%s:%s', session['ht_user'], fl_id, hx_api_object.hx_host, hx_api_object.hx_port)
                    continue
                choice_files = [file_listing['files'][i] for i in file_ids if i <= len(file_listing['files'])]
                multi_file_id = ht_db.multiFileCreate(session['ht_user'], profile_id, display_name=display_name, file_listing_id=file_listing.eid, api_mode=use_api_mode)
                # Create a data acquisition for each file from its host
                for cf in choice_files:
                    if cf['hostname'] in agent_ids:
                        agent_id = agent_ids[cf['hostname']]
                    else:
                        (ret, response_code, response_data) = hx_api_object.restFindHostsBySearchString(cf['hostname'])
                        agent_id = agent_ids[cf['hostname']] = response_data['data']['entries'][0]['_id']
                    path, filename = cf['FullPath'].rsplit('\\', 1)
                    (ret, response_code, response_data) = hx_api_object.restAcquireFile(agent_id, path, filename, use_api_mode)
                    if ret:
                        acq_id = response_data['data']['_id']
                        job_record = {
                            'acquisition_id' : int(acq_id),
                            'hostname': cf['hostname'],
                            'path': cf['FullPath'],
                            'downloaded': False
                        }
                        ht_db.multiFileAddJob(multi_file_id, job_record)
                        app.logger.info('File acquisition requested from host %s at path %s- User: %s@%s:%s - host: %s', cf['hostname'], cf['FullPath'], session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, agent_id)
                        file_jobs.append(acq_id)
                        if len(file_jobs) >= MAX_FILE_ACQUISITIONS:
                            break
                    else:
                        #TODO: Handle fail
                        pass
            if file_jobs:
                app.logger.info('New Multi-File Download requested (profile %s) - User: %s@%s:%s', profile_id, session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        
    (ret, response_code, response_data) = hx_api_object.restListHostsets()
    hostsets = formatHostsets(response_data)
    return render_template('ht_multifile.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), hostsets=hostsets)

@app.route('/file_listing', methods=['GET', 'POST'])
@valid_session_required
def file_listing(hx_api_object):
    if request.args.get('stop'):
        fl_job = ht_db.fileListingGetById(request.args.get('stop'))
        if fl_job:
            (ret, response_code, response_data) = hx_api_object.restCancelJob('acqs/bulk', fl_job['bulk_download_id'])
            if ret:
                ht_db.fileListingStop(fl_job.eid)
                ht_db.bulkDownloadStop(session['ht_profileid'], fl_job['bulk_download_id'])
                app.logger.info('File Listing ID {0} action STOP - User: {1}@{2}:{3}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, fl_job.eid))
        return redirect("/multifile", code=302)

    elif request.args.get('remove'):
        fl_job = ht_db.fileListingGetById(request.args.get('remove'))
        if fl_job:
            (ret, response_code, response_data) = hx_api_object.restDeleteJob('acqs/bulk', fl_job['bulk_download_id'])
            if ret:
                ht_db.fileListingDelete(fl_job.eid)
                ht_db.bulkDownloadDelete(session['ht_profileid'], fl_job['bulk_download_id'])
                app.logger.info('File Listing ID {0} action REMOVE - User: {1}@{2}:{3}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port, fl_job.eid))
        return redirect("/multifile", code=302)

    elif request.method == 'POST':
        # Get Acquisition Options from Form
        display_name = xmlescape(request.form['listing_name'])
        regex = xmlescape(request.form['listing_regex'])
        path = xmlescape(request.form['listing_path'])
        hostset = xmlescape(request.form['hostset'])
        use_api_mode = ('use_raw_mode' not in request.form)
        depth = '-1'
        # Build a script from the template
        script_xml = None
        try:
            if regex:
                re.compile(regex)
            else:
                app.logger.warn("Regex is empty!!")
                regex = ''
            if use_api_mode:
                template_path = 'templates/api_file_listing_script_template.xml'
            else:
                template_path = 'templates/file_listing_script_template.xml'
            with open(template_path) as f:
                t = Template(f.read())
                script_xml = t.substitute(regex=regex, path=path, depth=depth)
            if not display_name:
                display_name = 'hostset: {0} path: {1} regex: {2}'.format(hostset, path, regex)
        except re.error:
            #TODO: Handle invalid regex with response. (Inline AJAX?)
            raise
        if script_xml:
            bulkid = submit_bulk_job(hx_api_object, hostset, script_xml.encode('utf-8'), handler="file_listing")
            ret = ht_db.fileListingCreate(session['ht_profileid'], session['ht_user'], bulkid, path, regex, depth, display_name, api_mode=use_api_mode)
            app.logger.info('New File Listing - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
            return redirect("/multifile", code=302)
        else:
            # TODO: Handle this condition 
            abort(404)

    #TODO: Modify template and move to Ajax
    fl_id = request.args.get('id')
    file_listing = ht_db.fileListingGetById(fl_id)
    fl_results = file_listing['files']
    display_fields = ['FullPath', 'Username', 'SizeInBytes', 'Modified', 'Sha256sum'] 

    return render_template('ht_file_listing.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), file_listing=file_listing, fl_results=fl_results, display_fields=display_fields)

@app.route('/_multi_files')
@valid_session_required
def get_multi_files(hx_api_object):
    profile_id = session['ht_profileid']
    data_rows = []
    for mf in ht_db.multiFileList(profile_id):
        job = dict(mf)
        hosts_completed = len([_ for _ in job['files'] if _['downloaded']])
        job.update({
            'id': mf.eid,
            'state': ("STOPPED" if job['stopped'] else "RUNNING"),
            'file_count': len(job['files']),
            'mode': ('api_mode' in job and job['api_mode']) and 'API' or 'RAW'
        })

        # Completion rate
        job_progress = (int(job['file_count']) > 0) and  int(hosts_completed / float(job['file_count']) * 100) or 0
        job['progress'] = "<div class='htMyBar htBarWrap'><div class='htBar' id='multi_file_prog_" + str(job['id']) + "' data-percent='" + str(job_progress) + "'></div></div>"
        
        # Actions
        job['actions'] = "<a href='/multifile?stop=" +  str(job['id']) + "' style='margin-right: 10px;' class='tableActionButton'>stop</a>"
        job['actions'] += "<a href='/multifile?remove=" +  str(job['id']) + "' style='margin-right: 10px;' class='tableActionButton'>remove</a>"
        data_rows.append(job)
    return json.dumps({'data': data_rows})

@app.route('/_file_listings')
@valid_session_required
def get_file_listings(hx_api_object):
    profile_id = session['ht_profileid']
    data_rows = []
    for j in ht_db.fileListingList(profile_id):
        job = dict(j)
        job.update({'id': j.eid})
        job['state'] = ("STOPPED" if job['stopped'] else "RUNNING")
        job['file_count'] = len(job.pop('files'))

        # Completion rate
        bulk_download = ht_db.bulkDownloadGet(profile_id, job['bulk_download_id'])
        if bulk_download:
            hosts_completed = len([_ for _ in bulk_download['hosts'] if bulk_download['hosts'][_]['downloaded']])
            job_progress = int(hosts_completed / float(len(bulk_download['hosts'])) * 100)
            if 'display_name' not in job:
                job['display_name'] = 'hostset {0}, path: {1} regex: {2}'.format(bulk_download['hostset_id'] , job['cfg']['path'], job['cfg']['regex'])
        else:
            job_progress = job['file_count'] > 1 and 100 or 0
            if 'display_name' not in job:
                job['display_name'] = 'path: {0} regex: {1}'.format(job['cfg']['path'], job['cfg']['regex'])
        
        job['progress'] = "<div class='htMyBar htBarWrap'><div class='htBar' id='file_listing_prog_" + str(job['id']) + "' data-percent='" + str(job_progress) + "'></div></div>"
        
        # Actions
        job['actions'] = "<a href='/file_listing?stop=" +  str(job['id']) + "' style='margin-right: 10px;' class='tableActionButton'>stop</a>"
        job['actions'] += "<a href='/file_listing?remove=" +  str(job['id']) + "' style='margin-right: 10px;' class='tableActionButton'>remove</a>"
        if job_progress > 0:
            job['actions'] += "<a href='/file_listing?id=" +  str(job['id']) + "' style='margin-right: 10px;' class='tableActionButton'>view</a>"
        data_rows.append(job)
    return json.dumps({'data': data_rows})

### Stacking
##########
@app.route('/stacking', methods=['GET', 'POST'])
@valid_session_required
def stacking(hx_api_object):
    if request.args.get('stop'):
        stack_job = ht_db.stackJobGetById(request.args.get('stop'))
        if stack_job:
            (ret, response_code, response_data) = hx_api_object.restCancelJob('acqs/bulk', stack_job['bulk_download_id'])
            if ret:
                ht_db.stackJobStop(stack_job.eid)
                ht_db.bulkDownloadStop(session['ht_profileid'], stack_job['bulk_download_id'])
                app.logger.info('Data stacking action STOP - User: {0}@{1}:{2}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port))
        return redirect("/stacking", code=302)

    if request.args.get('remove'):
        stack_job = ht_db.stackJobGetById(request.args.get('remove'))
        if stack_job:
            (ret, response_code, response_data) = hx_api_object.restDeleteJob('acqs/bulk', stack_job['bulk_download_id'])
            if ret:
                ht_db.stackJobDelete(stack_job.eid)
                ht_db.bulkDownloadDelete(session['ht_profileid'], stack_job['bulk_download_id'])
                app.logger.info('Data stacking action REMOVE - User: {0}@{1}:{2}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port))
        return redirect("/stacking", code=302)

        
    if request.method == 'POST':
        stack_type = hxtool_data_models.stack_types.get(request.form['stack_type'])
        if stack_type:
            with open(os.path.join('scripts', stack_type['script']), 'rb') as f:
                script_xml = f.read()
                hostset_id = request.form['stackhostset']
                app.logger.info('Data stacking: New bulk acquisition - User: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
                bulk_id = submit_bulk_job(hx_api_object, hostset_id, script_xml, handler="stacking")
                ret = ht_db.stackJobCreate(session['ht_profileid'], bulk_id, request.form['stack_type'])
                app.logger.info('New data stacking job - User: {0}@{1}:{2}'.format(session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port))
        return redirect("/stacking", code=302)
    
    (ret, response_code, response_data) = hx_api_object.restListHostsets()
    hostsets = formatHostsets(response_data)
    
    stacktable = formatStackTable(ht_db, session['ht_profileid'], response_data)
    
    return render_template('ht_stacking.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), stacktable=stacktable, hostsets=hostsets, stack_types = hxtool_data_models.stack_types)


@app.route('/stackinganalyze', methods=['GET', 'POST'])
@valid_session_required
def stackinganalyze(hx_api_object):
    return render_template('ht_stacking_analyze.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), stack_id = request.args.get('id'))
        
            
### Settings
############
            
@app.route('/settings', methods=['GET', 'POST'])
@valid_session_required
def settings(hx_api_object):
    if request.method == 'POST':
        key = HXAPI.b64(session['key'], True)
        # Generate a new IV - must be 16 bytes
        iv = crypt_generate_random(16)
        encrypted_password = crypt_aes(key, iv, request.form['bgpass'])
        salt = HXAPI.b64(session['salt'], True)
        out = ht_db.backgroundProcessorCredentialCreate(session['ht_profileid'], request.form['bguser'], HXAPI.b64(iv), HXAPI.b64(salt), encrypted_password)
        app.logger.info("Background Processing credentials set profileid: %s by user: %s@%s:%s", session['ht_profileid'], session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        start_background_processor(session['ht_profileid'], request.form['bguser'], request.form['bgpass'])
    if request.args.get('unset'):
        out = ht_db.backgroundProcessorCredentialRemove(session['ht_profileid'])
        app.logger.info("Background Processing credentials unset profileid: %s by user: %s@%s:%s", session['ht_profileid'], session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        return redirect("/settings", code=302)
    
    bgcreds = formatProfCredsInfo((ht_db.backgroundProcessorCredentialGet(session['ht_profileid']) is not None))
    
    return render_template('ht_settings.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), bgcreds=bgcreds)


            
### Custom Configuration Channels
########################
@app.route('/channels', methods=['GET', 'POST'])
@valid_session_required
def channels(hx_api_object):
    (ret, response_code, response_data) = hx_api_object.restCheckAccessCustomConfig()
    if ret:
    
        if (request.method == 'POST'):
            (ret, response_code, response_data) = hx_api_object.restNewConfigChannel(request.form['name'], request.form['description'], request.form['priority'], request.form.getlist('hostsets'), request.form['confjson'])
            app.logger.info("New configuration channel on profile: %s by user: %s@%s:%s", session['ht_profileid'], session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        
        if request.args.get('delete'):
            (ret, response_code, response_data) = hx_api_object.restDeleteConfigChannel(request.args.get('delete'))
            app.logger.info("Configuration channel delete on profile: %s by user: %s@%s:%s", session['ht_profileid'], session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
            return redirect("/channels", code=302)
        
        (ret, response_code, response_data) = hx_api_object.restListCustomConfigChannels()
        channels = formatCustomConfigChannels(response_data)
        
        (ret, response_code, response_data) = hx_api_object.restListHostsets()
        hostsets = formatHostsets(response_data)
        
        return render_template('ht_configchannel.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port), channels=channels, hostsets=hostsets)
    else:
        return render_template('ht_noaccess.html', user=session['ht_user'], controller='{0}:{1}'.format(hx_api_object.hx_host, hx_api_object.hx_port))
            

@app.route('/channelinfo', methods=['GET'])
@valid_session_required
def channelinfo(hx_api_object):
    (ret, response_code, response_data) = hx_api_object.restCheckAccessCustomConfig()
    if ret:
        # TODO: finish
        (ret, response_code, response_data) = hx_api_object.restGetConfigChannelConfiguration(request.args.get('id'))
        return render_template('ht_configchannel_info.html', channel_json = json.dumps(response_data, sort_keys = True, indent = 4))
    else:
        return render_template('ht_noaccess.html')
        
#### Authentication
#######################

@app.route('/login', methods=['GET', 'POST'])
def login():
    
    if (request.method == 'POST'):
        if 'ht_user' in request.form:
            ht_profile = ht_db.profileGet(request.form['controllerProfileDropdown'])
            if ht_profile:    

                hx_api_object = HXAPI(ht_profile['hx_host'], hx_port = ht_profile['hx_port'], proxies = ht_config['network'].get('proxies'), headers = ht_config['headers'], cookies = ht_config['cookies'], logger = app.logger)

                (ret, response_code, response_data) = hx_api_object.restLogin(request.form['ht_user'], request.form['ht_pass'])
                if ret:
                    # Set session variables
                    session['ht_user'] = request.form['ht_user']
                    session['ht_profileid'] = ht_profile['profile_id']
                    session['ht_api_object'] = hx_api_object.serialize()
                    
                    # Decrypt background processor credential if available
                    # TODO: this could probably be better written
                    iv = None
                    salt = crypt_generate_random(32)
                    background_credential = ht_db.backgroundProcessorCredentialGet(ht_profile['profile_id'])
                    if background_credential:
                        salt = HXAPI.b64(background_credential['salt'], True)
                        iv = HXAPI.b64(background_credential['iv'], True)
                        
                    key = crypt_pbkdf2_hmacsha256(salt, request.form['ht_pass'])
                    
                    if iv and salt:
                        try:
                            decrypted_background_password = crypt_aes(key, iv, background_credential['hx_api_encrypted_password'], decrypt = True)
                            start_background_processor(ht_profile['profile_id'], background_credential['hx_api_username'], decrypted_background_password)
                        except UnicodeDecodeError:
                            app.logger.error("Failed to decrypt background processor credential! Did you recently change your password? If so, please unset and reset these credentials under Settings.")
                        finally:
                            decrypted_background_password = None

                    session['key']= HXAPI.b64(key)
                    session['salt'] = HXAPI.b64(salt)

                    app.logger.info("Successful Authentication - User: %s@%s:%s", session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
                    redirect_uri = request.args.get('redirect_uri')
                    if not redirect_uri:
                        redirect_uri = "/?time=today"
                    return redirect(redirect_uri, code=302)
                else:
                    return render_template('ht_login.html', fail=response_data)        
        return render_template('ht_login.html', hx_default_port = HXAPI.HX_DEFAULT_PORT, fail = "Invalid profile id.")
    else:    
        return render_template('ht_login.html', hx_default_port = HXAPI.HX_DEFAULT_PORT)
        
@app.route('/logout', methods=['GET'])
def logout():
    if session and session['ht_api_object']:
        hx_api_object = HXAPI.deserialize(session['ht_api_object'])
        hx_api_object.restLogout()    
        app.logger.info('User logged out: %s@%s:%s', session['ht_user'], hx_api_object.hx_host, hx_api_object.hx_port)
        session.pop('ht_user', None)
        session.pop('ht_api_object', None)
        hx_api_object = None
    return redirect("/login", code=302)
    

####################################
#
#    HXTool API
#    
####################################    
    
####################
# Profile Management
####################
@app.route('/api/v{0}/profile'.format(HXTOOL_API_VERSION), methods=['GET', 'PUT'])
def profile():
    if request.method == 'GET':
        profiles = ht_db.profileList()
        return json.dumps({'data_count' :  len(profiles), 'data' : profiles})
    elif request.method == 'PUT':
        request_json = request.json
        if validate_json(['hx_name', 'hx_host', 'hx_port'], request_json):
            if ht_db.profileCreate(request_json['hx_name'], request_json['hx_host'], request_json['hx_port']):
                app.logger.info("New controller profile added")
                return make_response_by_code(200)
        else:
            return make_response_by_code(400)
            
@app.route('/api/v{0}/profile/<profile_id>'.format(HXTOOL_API_VERSION), methods=['GET', 'PUT', 'DELETE'])
def profile_by_id(profile_id):
    if request.method == 'GET':
        profile_object = ht_db.profileGet(profile_id)
        if profile_object:
            return json.dumps({'data' : profile_object})
        else:
            return make_response_by_code(404)
    elif request.method == 'PUT':
        request_json = request.json
        if validate_json(['profile_id', 'hx_name', 'hx_host', 'hx_port'], request_json):
            if ht_db.profileUpdate(request_json['_id'], request_json['hx_name'], request_json['hx_host'], request_json['hx_port']):
                app.logger.info("Controller profile %d modified.", profile_id)
                return make_response_by_code(200)
    elif request.method == 'DELETE':
        if ht_db.profileDelete(profile_id):
            app.logger.info("Controller profile %s deleted.", profile_id)
            return make_response_by_code(200)
        else:
            return make_response_by_code(404)

#####################
# Stacking Results
#####################
@app.route('/api/v{0}/stacking/<int:stack_id>/results'.format(HXTOOL_API_VERSION), methods=['GET'])
@valid_session_required
def stack_job_results(hx_api_object, stack_id):
    stack_job = ht_db.stackJobGetById(stack_id)
    
    if stack_job is None:
        return make_response_by_code(404)

    if session['ht_profileid'] != stack_job['profile_id']:
        return make_response_by_code(401)
        
    ht_data_model = hxtool_data_models(stack_job['stack_type'])
    return ht_data_model.stack_data(stack_job['results'])    
        
        
####################
# Utility Functions
####################

def validate_json(keys, j):
    for k in keys:
        if not k in j or not j[k]:
            return False    
    return True
        
def make_response_by_code(code):
    code_table = {200 : {'message' : 'OK'},
                400 : {'message' : 'Invalid request'},
                404 : {'message' : 'Object not found'}}
    return (json.dumps(code_table.get(code)), code)

"""
Generate a random byte string for use in encrypting the background processor credentails
"""
def crypt_generate_random(length):
    return os.urandom(length)

"""
Return a PBKDF2 HMACSHA256 digest of a salt and password
"""
def crypt_pbkdf2_hmacsha256(salt, data):
    return PBKDF2(data, salt, dkLen = 32, count = 100000, prf = lambda p, s: HMAC.new(p, s, SHA256).digest())

"""
AES-256 operation
"""
def crypt_aes(key, iv, data, decrypt = False, base64_coding = True):
    cipher = AES.new(key, AES.MODE_OFB, iv)
    if decrypt:
        if base64_coding:
            data = HXAPI.b64(data, True)
        data = cipher.decrypt(data).decode('utf-8')
        # Implement PKCS7 de-padding
        pad_length = ord(data[-1:])
        if 1 <= pad_length <= 15:
            if all(c == chr(pad_length) for c in data[-pad_length:]):
                data = data[:len(data) - pad_length:]
        return data
    else:
        # Implement PKCS7 padding
        pad_length = 16 - (len(data) % 16)
        if pad_length < 16:
            data += (chr(pad_length) * pad_length)
        data = data.encode('utf-8')            
        data = cipher.encrypt(data)
        if base64_coding:
            data = HXAPI.b64(data)
        return data
    
"""
Iter over a Requests response object
and yield the chunk
"""
def iter_chunk(r, chunk_size = 1024):
    for chunk in r.iter_content(chunk_size = chunk_size):
        yield chunk
    
### background processing 
#################################
def start_background_processor(profile_id, hx_api_username, hx_api_password):
    p = hxtool_background_processor(ht_config, ht_db, profile_id, logger = app.logger)
    p.start(hx_api_username, hx_api_password)
    app.logger.info('Background processor started.')    


#################################
# Add Function for Request Passive Triage (by soccermaru)
# todolist : make event message from post request
# event 컬럼 사용 시 event 컬럼의 <br> 로 구분자 사용함에 주의 (event 컬럼 추가 시 <br> 최소 한 개 입력해야함)
#################################
def crypt_generate_random(length):
    return os.urandom(length)

from flask_restful import Resource, Api
from flask_restful import reqparse
from test_reqhx import request_hx,get_token,download_triage,hxlogger,BUG,health_check_hx
import sys,time,datetime,sqlite3,os
import threading
import urllib2
import ssl
import re
from alarmpol import AlarmSMSAPIClient, GroupwareAlarmAPIClient, sendSms

passive_traige_error = hxlogger('passive_traige_error')
passive_traige_request = hxlogger('passive_traige_request')
HXSRV_HOSTS = '/hx/api/v3/hosts'
HXSRV_ACQS = '/hx/api/v3/acqs/triages'
HXSRV_TRIAGE_LIST = '/hx/api/v3/acqs/triages'
PASSIVE_TRIAGE_DBFILE = '/home/apps/hxtool/HXTool-3.0/passive_triage.db'
#app = Flask(__name__)

# must modify
DBTYPE = 'mariadb'
#DBTYPE = 'sqlite'
#hxtool_srv = 'https://localhost:9000' 
hxtool_srv = 'https://hx-tool.hanpda.com'
errorreceiver = 'yskim04'
alarmreceiver = 'yskim04,chlee,yccheon,jjchoi,ywkim02' # must modify
#alarmreceiver = 'yskim04'
SYMANTEC_IOC = '.VBN File Written Event(ccSvcHst.exe)'
RE_TAG = '(heur|miner|pua|pup|suspicious|reputation|adv|android|securityrisk|adware)'
#RE_TAG = '(bot|rat|apt|operation|steal|ddos|shell|cve-|exploit|expkit|trojan|fireeye|netcat|hack|mimikatz|ransom|scan|backdoor)' 
IGNORED_TAG = ['ezadmin','sellmate','/pimz/','.+\\pimz\\.+','cafe24printeragent_setup','ws.reputation.1','EICAR Test String','SUMMARIZED DATA',
'.*NESSUSD.EXE.*Intrusion.*ip_addr1_text": "123.140.249.97"','.*NTP.*Scan.*"remote_host_ip_text": "123.140.249.97"','Tracking Cookies','filepath.+Cookie.+@',
'.*NESSUSD.EXE.*Intrusion.*ip_addr1_text": "1.209.128.245"','.*NTP.*Scan.*"remote_host_ip_text": "1.209.128.245"',
'uws.*cafe24.*com','/home/.*www/.*','.*NESSUSD.EXE.*Intrusion.*ip_addr1_text": "10.5.1.10"','cafe24security(_admin)*\\.exe','Adware','Malicious Domain Request',
'Malicious Domains Request','Malicious Browser Plugin Activity','Fake Tech Support Domains','Web Attack'
]
# triage 정보수집 기능 외 (비)활성화
ISDISABLE = 'FALSE'

api = Api(app)

if DBTYPE == 'mariadb' :
    import pymysql
    con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
    cursor = con.cursor()
    # create reqtriage table
    create_reqtriage_table = '''
    create table if not exists reqtriage(triage_id varchar(100) primary key,req_type varchar(100),state varchar(100),downlink varchar(300),device varchar(100),category varchar(100),event_time varchar(100),alertdatetime1 varchar(100),request_time varchar(100),computer_name varchar(100),user_name varchar(100),ipaddress varchar(100),agent_id varchar(100),req_success varchar(100),event text,comment text)  DEFAULT CHARSET=utf8mb4
    '''
    cursor.execute(create_reqtriage_table)
    # create waitreqtriage table
    cursor.execute('''
    create table if not exists waitreqtriage(postbody text) DEFAULT CHARSET=utf8mb4
    ''')
    # create ioc enterprise search table
    create_ioc_es_table = '''
    create table if not exists ioces(search_id varchar(100) primary key, request_time varchar(100), end_time varchar(100), ioc_dic text, hx_response_json text, description text, reference text, search_result_json text, userinfo text, es_summary text) DEFAULT CHARSET=utf8mb4
    '''
    cursor.execute(create_ioc_es_table)
    con.commit()
    con.close()
else :
    con = sqlite3.connect(PASSIVE_TRIAGE_DBFILE)
    cursor = con.cursor()
    create_reqtriage_table = '''
    create table if not exists reqtriage(triage_id text primary key,req_type text,state text,downlink text,device text,category text,event_time text,alertdatetime1 text,request_time text,computer_name text,user_name text,ipaddress text,agent_id text,req_success text,event text,comment text)
    '''
    cursor.execute(create_reqtriage_table)
    cursor.execute('''
    create table if not exists waitreqtriage(postbody text primary key)
    ''')
    con.commit()
    con.close()


maru_token = {}
maru_token['token'] = get_token()
maru_token['grant_timestamp'] = str(datetime.datetime.utcnow())
maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
token = maru_token['token']

CHECK_TRIAGE_STATE_TIME = 30
MAX_DURATION = 6
MAX_QUEUE =101
MAX_VIEW_LIST_NUM = 300

#description : db 접속 함수 (초기 테스트 시 sqlite를 사용,현재는 mariadb 사용)
def dbconn() :
    if DBTYPE == 'mariadb' : con = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
    else : con = sqlite3.connect(PASSIVE_TRIAGE_DBFILE)
    return con


#description : token timeout 점검 함수
def maru_restIsSessionValid():
    try:
        current_token = maru_token
        if current_token:
            last_use_delta = (datetime.datetime.utcnow() - datetime.datetime.strptime(current_token['last_use_timestamp'], '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
            grant_time_delta = (datetime.datetime.utcnow() - datetime.datetime.strptime(current_token['grant_timestamp'], '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
            if (last_use_delta < 13 and grant_time_delta < 110) :
                maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
                token = maru_token['token']
            else : 
                reset_token()
        else:
            reset_token()
        # print maru_token['token']
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : token 허용시간이 지났을 경우 token 재생성
def reset_token():
    try:
        maru_token['token'] = get_token()
        maru_token['grant_timestamp'] = str(datetime.datetime.utcnow())
        maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
        token = maru_token['token']
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description :  time format을 통일시키기 위한 함수
def convert_timeformat(timestr) :
    timestr = str(timestr).replace('Z','').replace('T',' ').split('.')[0]
    return timestr

#description :  주기적으로 triage stat 업데이트 및 auto triage 추가
NOT_COMPLETE = []
def check_triage_state():
    global NOT_COMPLETE
    try:
        es_daemon = os.popen('ps -ef').read()
        if es_daemon.find('es_daemon.0.2.py start') == -1 and ISDISABLE == 'FALSE' :
            os.system('cd /home/apps/hxtool/hx_es_daemon; /usr/bin/python /home/apps/hxtool/hx_es_daemon/es_daemon.0.2.py start &')
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('select count(*) from reqtriage')
        rows = cursor.fetchall()[0][0]
        maru_restIsSessionValid()
        if int(rows) < 10 :
            limittriage = 10000
            limitalerts = 10000
        else:
            limittriage = 100
            limitalerts = 1000
        triage_list = request_hx(maru_token['token'],HXSRV_TRIAGE_LIST,'?&sort=request_time+descending&limit=%d'%limittriage,'GET',None)
        #print json.dumps(triage_list)
        checked_host = []
        for item in triage_list['data']['entries'] :
            device = ''
            alerts = ''
            event = ''
            event_time = ''
            alertdatetime1 = ''
            request_time = ''
            dupl_alert = []
            agent_id = item['host']['_id']
            req_type = item['request_actor']['username']

            #if req_type.find('automatic') > -1 : print str(request_hx(maru_token['token'],item['indicator']['url'],'','GET',None)['data']) #['display_name']   

            triage_id = str(item['_id'])
            request_time = convert_timeformat(item['request_time'])
            state = item['state']
            cursor.execute('select state from reqtriage where triage_id = "%s"'%triage_id)
            rows = cursor.fetchall()
            # 이미 테이블에 triage_id가 존재한다면 state만 체크 및 업데이트
            if len(rows) > 0 :
                if rows[0][0] != state :
                    cursor.execute('update reqtriage set state = \'{0}\' where triage_id = \'{1}\''.format(state,triage_id))
                    con.commit()
                    cursor.execute('select event from reqtriage where triage_id = \'{0}\''.format(triage_id))
                    event_row = cursor.fetchall()
                    event_row = event_row[0][0].replace('<br>','\r\n')
                    con.close()
                    if state == 'COMPLETE' :
                        hostinfo = request_hx(maru_token['token'],'/hx/api/v3/hosts/',agent_id,'GET',None)
                        computer_name = hostinfo['data']['hostname']
                        ipaddress = hostinfo['data']['last_poll_ip']
                        if event_row.find('Fireeye Manual') > -1 and req_type == 'isteam_api' : alarmtitle = 'Fireye Addition'
                        else : alarmtitle = event_row.split('\r\n')[0]
                        sendalarm('[Fireeye HX] Triage Completed ({0})\r\n computer_name : {1}\r\n IPAddress : {2}\r\n triage_type : {3}\r\n downlink : {4}'.format(alarmtitle,computer_name,ipaddress,req_type,'{0}/es_query_result/stored_triage_files/{1}\r\n\r\n {2}\r\n\r\n Triage 요청 예외 항목 : {3}'.format(hxtool_srv,triage_id,event_row,str(IGNORED_TAG))),alarmreceiver)

                        # fireeye autotriage 인 경우 complete 된 이 후 수동으로 triage 재요청
                        if req_type.find('automatic') > -1 and ISDISABLE == 'FALSE' : #print 'must modify'
                            retriage = request_hx(maru_token['token'],HXSRV_HOSTS,'/' + agent_id + '/triages','POST',None)
                        # fireeeye event auto triage 완료 시 maxav 자동점검 요청
                        #if alarmtitle.find('Fireeye : ') > -1 : response = requests.get('http://localhost:8080/es_query_result/triage_list/req_maxav?triage_id=%s'%triage_id)
                continue
            if req_type.find('automatic') > -1: 
                try :
                    indicator =  request_hx(maru_token['token'],item['indicator']['url'],'','GET',None)
                    display_name = indicator['data']['display_name'] 
                    if display_name != None : indicator = display_name + '<br>'
                    else : indicator = item['indicator']['url'].split('/')[-1] + '<br>'
                    # if symantec event 
                    if indicator.find(SYMANTEC_IOC) > -1 :
                        device = 'symantec'
                        #alerts = str(request_hx(maru_token['token'],item['alert']['url'],'','GET',None)['data']['event_values']['fileWriteEvent/textAtLowestOffset'])
                        alerts_dic = request_hx(maru_token['token'],'/hx/api/v3/alerts?sort=event_at+d&limit=%d'%limitalerts,'','GET',None)
                        for alert in alerts_dic['data']['entries'] :
                            if alert['agent']['_id'] == agent_id :
                                alertdatetime1 = convert_timeformat(alert['event_at'])
                                event_time = alertdatetime1
                                if alert['event_values'].has_key('fileWriteEvent/textAtLowestOffset'):
                                    checkduplication = alert['event_values']['fileWriteEvent/textAtLowestOffset'].replace('.','').lower()
                                if checkduplication not in dupl_alert :
                                    alerts += alert['event_values']['fileWriteEvent/textAtLowestOffset'] + '<br>'
                                    dupl_alert.append(checkduplication)
                                else : 
                                    continue
                    else : 
                        device = 'FireEyeHX'
                        alerts = request_hx(maru_token['token'],item['alert']['url'],'','GET',None)
                        alertdatetime1 = convert_timeformat(alerts['data']['event_at'])
                        event_time = alertdatetime1
                        alert_dic =  alerts['data']['event_values']
                        alerts = ''
                        for key,value in alert_dic.items():
                            alerts += str(key) + ' : ' + str(value).replace('<','[').replace('>',']') + '<br>'
                    alerts = alerts.replace(',','<br>').replace("'",'"').replace('u"','"')
                    event = 'Fireeye : {0}'.format(indicator)
                    event += '<a href="https://112.175.67.137:3000/hx/hosts/{0}/alerts/" target="_blank">상세보기</a><br>{1}'.format(agent_id,alerts)
                except Exception as err: 
                    #passive_traige_error.error(str(err))
                    pass
            else :
                if req_type == 'isteam_api' : 
                    event = 'Fireeye Addition : HX 이벤트 발생에 따른 추가 Triage 자동 요청<br>'
                else : 
                    event = 'Fireeye Manual : 사용자 수동 수집<br>'
                req_type = 'passive'
                event_time = request_time
                alertdatetime1 = event_time
                device = 'FireEyeHX'
                
            if triage_id.find('Null') > -1 : continue
            #device = 'FireEyeHX'
            category = 'threats'
            hostinfo = request_hx(maru_token['token'],'/hx/api/v3/hosts/',agent_id,'GET',None)
            computer_name = hostinfo['data']['hostname']
            user_name,comment = '','<font color="white">NotYet</font>'
            if triage_id.find('Null') > -1 : downlink = 'Null'
            elif triage_id.find('.') > -1 : downlink = 'Null'
            else: downlink = '<a href ="{0}/es_query_result/stored_triage_files/{1}" target="_blank"><font color="black">{2}.mans</font></a>'.format(hxtool_srv,triage_id,triage_id)
            NOT_COMPLETE = list(set(NOT_COMPLETE))
            if computer_name not in checked_host :
                if state == 'COMPLETE' and computer_name in NOT_COMPLETE :  NOT_COMPLETE.remove(computer_name)
                    #sendalarm('[Fireeye HX] Triage Completed\r\n computer_name : {0}\r\n triage_type : {1}\r\n device : {2}\r\n downlink : {3}'.format(computer_name,req_type,device,'{0}/es_query_result/stored_triage_files/{1}'.format(hxtool_srv,triage_id)),alarmreceiver)
                elif state != 'COMPLETE' and computer_name not in NOT_COMPLETE : NOT_COMPLETE.append(computer_name)
                checked_host.append(computer_name)
            else : continue
            ipaddress = hostinfo['data']['last_poll_ip']
            req_success = 'true'
            sql = 'select triage_id from reqtriage where triage_id = \'{0}\''.format(triage_id)
            cursor.execute(sql)
            rows = cursor.fetchall()
            if len(rows) == 0 :
                if DBTYPE == 'mariadb' :
                    event = event.replace('\\','/')
                    sql = 'insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment)
                    if req_type.find('automatic') > -1 :
                        if containment(agent_id,event,maru_token['token']) == 'Created' :
                            sendalarm('[Fireeye HX] Containment Completed ({0})\r\n computer_name : {1}\r\n IPAddress : {2}\r\n triage_type : {3}\r\n downlink : {4}'.format('!',computer_name,ipaddress,req_type,'{0}/es_query_result/stored_triage_files/{1}\r\n\r\n {2}\r\n'.format(hxtool_srv,triage_id,event.replace('<br>','\n'))),alarmreceiver)
                else :
                    sql = 'insert or ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment)
                    
                cursor.execute(sql)
                con.commit()
            cursor.execute('update reqtriage set state = \'{0}\' where triage_id = \'{1}\''.format(state,triage_id)) 
            con.commit()
        con.close()
        time.sleep(CHECK_TRIAGE_STATE_TIME)
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))
        
# desc : special event and seoulpc => auto containment
def containment(agent_id,event,token):
    try : 
        CONTAINMENT_EVENT = ['net1.+group.+\/domain']
        #agent_id = 'DXxSqEaw4z4dcVhdL2QIpU' # 'h5l06sdPJx6gfN4kxgDfWL'
        is_contain = False
        result = 'false'
        hostset_uri = '/hx/api/v3/host_sets/1000/hosts?search=%s&limit=1'%agent_id 
        hostset_info = request_hx(token,hostset_uri,'','GET','')
        if hostset_info['data']['total'] == 0 : return result # is seoul pc ?
        for i in CONTAINMENT_EVENT :
            if bool(re.search(i.lower(),event.lower())) == True :
                is_contain = True
                break
        if is_contain == False : return result
        print '[ Start Containment ]'
        containment_uri = '/hx/api/v3/hosts/%s/containment'%agent_id
        request_hx(token,containment_uri,'','POST','')
        time.sleep(1)
        #u'message': u'Created'
        result = request_hx(token,containment_uri,'','PATCH','{"state":"contain"}')
        result = result['message']
        #print json.dumps(request_hx(token,containment_uri,'','GET',''),indent=2)
        #print request_hx(token,containment_uri,'','DELETE','')
        return result
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))


#description : alarm 전송 함수
import fastbox_alarmpol
def sendalarm(msg, user_id, team=''):
    try:
        user_id = user_id.replace(' ', '')
        team = team.replace(' ', '')
        msg = msg.replace('\\','/')
        if msg.find('192.168.22.') > -1 : # if fbox group 
            fastbox = fastbox_alarmpol.GroupwareAlarmAPIClient('yskim04','yskim04,sykim01',msg)
            fastbox.request()
        if team == '':
            client = GroupwareAlarmAPIClient('isteamalarm', user_id, msg)
        else:
            client = GroupwareAlarmAPIClient('isteamalarm', 'dept', msg, team)
        client.request()
    except Exception as err :
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}


def check_interesting_event(event) :
    if bool(re.search(RE_TAG,event.lower())) == False :return '<strong><font color="red">' + event + '</font></strong>' 
    else : return '<strong>' + event + '</strong>'

sys.path.insert(0, '/home/apps/hxtool/hx_es_daemon/lib')
import reqvirustotal

#description : ReqTriage 클래스    
class ReqTriage(Resource):
    def sendalarm(self,msg, user_id, team=''):
        try:
            user_id = user_id.replace(' ', '')
            team = team.replace(' ', '')
            msg = msg.replace('\\','/')
            #logger.info("sendGroupwareAlarm receiver:{receiver}".format(receiver=user_id))
            # print msg
            if team == '':
                client = GroupwareAlarmAPIClient('isteamalarm', user_id, msg)
            else:
                client = GroupwareAlarmAPIClient('isteamalarm', 'dept', msg, team)
            client.request()
        except Exception as err :
            err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
            #sendalarm('* HX REQ Triage Error : ' + err,errorreceiver) 
            passive_traige_error.error(str(err))
    ''''
    # 파라미터 정의
    parser = reqparse.RequestParser()
    parser.add_argument('device',type=str,required=True)
    parser.add_argument('category',type=str,required=True)
    parser.add_argument('event_time', type=str)
    parser.add_argument('begin_time', type=str)
    parser.add_argument('alertdatetime1', type=str)
    parser.add_argument('computer_name', type=str)
    parser.add_argument('user_name', type=str)
    parser.add_argument('ipaddress', type=str)
    parser.add_argument('event', type=str)
    '''
    #description :  running 갯수 제한에 의해 waitreqtriage 테이블에 저장되어 있던 triage를 재요청 한 후 삭제 & call check_triage_state 
    def re_req_triage():
        while True :
            try :
                check_triage_state()
                req_triage_uri = hxtool_srv + '/reqtriage'
                handler = urllib2.HTTPHandler()
                opener = urllib2.build_opener(handler)
                urllib2.install_opener(opener)
                con = dbconn()
                cursor = con.cursor()
                rows = cursor.execute('select postbody from waitreqtriage')
                rows = cursor.fetchall()
                for row in rows :
                    try:
                        data=str(row[0])
                        request = urllib2.Request(req_triage_uri , data=data)
                        context = ssl._create_unverified_context()
                        request.add_header('Content-Type', 'application/json')
                        request.get_method = lambda: 'POST'
                        response = urllib2.urlopen(request, context=context)
                    except urllib2.HTTPError as e:
                        msg = 'err : ' + str(e.read())
                        print msg
                        continue
                    if response.read().find('"message": "Created"') > -1 :
                        cursor.execute('delete from waitreqtriage where postbody = \'%s\' '%str(row[0]))
                con.commit()
                con.close()
                time.sleep(120)
            except Exception as err :
                err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
                #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
                passive_traige_error.error(str(err))
                #time.sleep(60)
                continue
    t1 = threading.Thread(target=re_req_triage)
    t1.daemon = True
    t1.start()
    

    def create_condition_for_detected_file_by_symantec(self,filepath,sha256) :
        #return 0
        try:
            print 'create_condition_for_detected_file_by_symantec'
            maru_restIsSessionValid()
            if filepath.find('/') > -1 : filepath = filepath.replace('/','\\')
            # check compressed file type (compressed file : include ">>" character in symantec log)
            # 압축파일 내 악성코드인 경우 full path 를 알 수 없어 filename으로 룰조건을 생성할 경우 대량의 오탐 가능성이 존재함
            # 따라서 filepath 에 ">>"가 포함된 경우 룰을 생성하지 않는다.
            # 압축이 해제 된 후에도 탐지가 되므로 압축해제 후 탐지되는 full path로 룰조건을 생성하기로함
            iscompressed = False
            if filepath.find('>>') > -1 : iscompressed = True #filepath = filepath.split('>>')[-1]
            iname = 'Malware_Execution_Event_By_Symantec'
            new_indicator_uri = '/hx/api/v3/indicators/cafe24'
            uriname_file = '/home/apps/hxtool/HXTool-3.0/Malware_Execution_Event_By_Symantec'
            if os.path.isfile(uriname_file) :
                f = open(uriname_file,'r')
                indicator_uri_name = f.read().replace('\n','')
                f.close()
                response = request_hx(maru_token['token'],'/hx/api/v3/indicators/cafe24/',indicator_uri_name,'GET',None,'n')
                if str(response).lower().find('indicator not found') > -1 :
                    new_indicator_data = '{"display_name":"%s","create_text":"isteam_api_bot","description":"Malware Execution Event(Symantec)"}'%(iname)
                    response_indicator = request_hx(maru_token['token'],new_indicator_uri,'','POST',new_indicator_data,'n')
                    indicator_uri_name = response_indicator['data']['_id']
                    f = open(uriname_file,'w')
                    f.write(indicator_uri_name)
                    f.close()
            else :
                #if indicator is not exists Create Indicator For filepath / searching indicator is too much spent time
                # indicator 주기적 삭제는 es_daemon.py 의 interval 모드에 추가 : 23시간 이후 삭제
                #del_response = request_hx(maru_token['token'],'/hx/api/v3/indicators/cafe24/',indicator_uri_name,'DELETE',None,'no')
                new_indicator_data = '{"display_name":"%s","create_text":"isteam_api_bot","description":"Malware Execution Event(Symantec)"}'%(iname)
                response_indicator = request_hx(maru_token['token'],new_indicator_uri,'','POST',new_indicator_data,'n')
                indicator_uri_name = response_indicator['data']['_id']
                f = open(iname,'w')
                f.write(indicator_uri_name)
                f.close()
            # create conditions
            filepath = filepath.replace('\\','\\\\')
            create_conditions_uri = '/hx/api/v3/indicators/cafe24/%s/conditions/execution' %indicator_uri_name
            if iscompressed == False :
                processpath_condition_format = u'{"tests": [{"operator": "contains","token": "processEvent/processPath", "type": "text", "value": "%s"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "ccSvcHst.exe"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "bandizip.exe"}]}'%filepath
                cmdline_condition_format = u'{"tests": [{"operator": "contains","token": "processEvent/processCmdLine","type": "text", "value": "%s"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "ccSvcHst.exe"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "bandizip.exe"},{"operator": "contains","negate": true, "token": "processEvent/processCmdLine", "type": "text", "value": "AcroEdit\\AcroEdit.exe"},{"operator": "contains","negate": true, "token": "processEvent/processCmdLine", "type": "text", "value": "system32\\notepad.exe"}]}'%filepath
                imageload_condition_format = u'{"tests": [{"operator": "contains","token": "imageLoadEvent/fullPath","type": "text", "value": "%s"},{"operator": "equal","negate": true, "token": "imageLoadEvent/process", "type": "text", "value": "ccSvcHst.exe"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "bandizip.exe"}]}'%filepath
                response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',processpath_condition_format.encode('utf-8'),'n')
                #print json.dumps(response_new_condition) + '\n'
                response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',cmdline_condition_format.encode('utf-8'),'n')
                #print json.dumps(response_new_condition) + '\n'
                response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',imageload_condition_format.encode('utf-8'),'n')
                #print json.dumps(response_new_condition) + '\n' 
            if sha256 != '' :
                vt_result = reqvirustotal.convert_sha256_to_md5_from_vt(sha256) 
                if vt_result != 'Not Found VTReport' :
                    processmd5_condition_format = u'{"tests": [{"operator": "equal","token": "processEvent/md5", "type": "md5", "value": "%s"},{"operator": "equal","negate": true, "token": "processEvent/process", "type": "text", "value": "ccSvcHst.exe"}]}'%vt_result
                    response_new_condition = request_hx(maru_token['token'],create_conditions_uri,'','POST',processmd5_condition_format.encode('utf-8'),'n')
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err


    #description :  logstat에서 전달 받은 symantec 로그 파싱 함수
    def parsing_symantec(self,device,category,args):
        try:

            if 'filepath' in args :
                sha256 = ''
                if 'hash' in args : sha256 = args['hash']
                elif 'app_hash' in args : sha256 = args['app_hash']
                if 1==2 :
                #if len(args['filepath']) > 10 and args['filepath'].lower().find('windows/system32') == -1 and args['filepath'].lower().find('windows\\system32') == -1: 
                    self.create_condition_for_detected_file_by_symantec(args['filepath'],sha256)   
            
            if category.lower() == 'threats' :
                event_time = convert_timeformat(args['time'])
                alertdatetime1 = convert_timeformat(args['alertdatetime1'])
                computer_name = args['computer_name']
                user_name = args['user_name']
                ipaddr = args['ip_addr1_text']
                event = ('Symantec THREATS : ' + args['virusname'] + '<br>')
                event += 'app_hash : ' + '<a href="https://www.virustotal.com/#/file/%s/detection" target=_blank>'%args['app_hash']  + args['app_hash'] + '</a><br>'  + 'filepath : ' + args['filepath'] + '<br>' 
                event += 'downloader : ' + args['downloader'] + '<br>' + 'url : ' + args['url'] + '<br>'
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            elif category.lower() == 'ntp' :
                if args['event_name'].lower().find('port scan') > -1 :
                    if args['traffic_direction'].lower().find('inbound') > -1: ipaddr = args['remote_host_ip_text']
                    else : ipaddr = args['ip_addr1_text']
                elif args['event_name'].lower().find('active response') > -1 :
                    return  {"state":"error","message":"nothing_matches"}
                else : #args['event_name'].lower().find('intrusion') > -1 :
                    if args['event_desc'].lower().find('bruteforce attempt') > -1 and args['traffic_direction'].lower().find('inbound') > -1 : 
                        ipaddr = args['remote_host_ip_text']
                    else : ipaddr = args['ip_addr1_text']
                event_time = convert_timeformat(args['time'])
                alertdatetime1 = convert_timeformat(args['begin_time'])
                computer_name = args['computer_name']
                user_name = args['user_name']
                if args['event_name'].find('Port Scan') > -1 : event = ('Symantec NTP : ' + args['str_cids_sign_id'] + ' Port Scan<br>' )
                else : event = ('Symantec NTP : ' + args['str_cids_sign_id'] + '<br>')
                event += 'event_name : ' + args['event_name'] + '<br>' + 'remoteIP : ' + args['remote_host_ip_text'] + '<br>' + 'traffic_direction : ' + args['traffic_direction'] + '<br>'  
                event += 'app_name : ' + args['app_name'] + '<br>' + 'event_desc : ' + args['event_desc'] + '<br>' + 'intrusion_url : ' + args['intrusion_url'] + '<br>'
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            elif category.lower() == 'sonar' :
                event_time = convert_timeformat(args['time'])
                alertdatetime1 = convert_timeformat(args['alertdatetime1'])
                computer_name = args['computer_name']
                user_name = args['user_name']
                # ipaddr = args['source_computer_ip_text'] # why all values was 0.0.0.0 ?
                ipaddr = ''
                event = ('Symantec SONAR : ' + args['virusname_help'] + '<br>')
                event += 'app_name : ' + args['app_name'] + '<br>' +  'web_domain : ' + args['web_domain'] + '<br>' 
                event += 'filepath : ' + args['filepath'] + '<br>' + 'hash : ' + '<a href="https://www.virustotal.com/#/file/%s/detection" target=_blank>'%args['hash']  + args['hash'] + '</a><br>' + 'downloader : ' + args['downloader'] + '<br>' + 'url : ' + args['url'] + '<br>'
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            else : 
                result = {"state":"okay","message":"nothing_matches"}
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err


    #description : fortinet antivirus 로그 파싱 함수 / fortinet 로그는 es_daemon.py 에서 주기적으로 요청
    def parsing_fortinet(self,device,category,args):
        try :            
            event_time = convert_timeformat(args['date'] + 'T' + args['time'] + '.00')
            alertdatetime1 = event_time
            computer_name = ''
            user_name = ''
            event = 'Fortinet AntiVirus : '
            ipaddr = args['srcip']
            if 'virus' in args : event +=  args['virus'] + '<br>'
            if 'url' in args : event += 'url : ' + args['url'] + '<br>' 
            if 'filename' in args : event += 'filename : ' + args['filename'] + '<br>' 
            if 'direction' in args : event += 'direction : ' + args['direction'] + '<br>' #here
            event += 'src ip / port : ' + args['srcip'] + ' : ' + args['srcport'] +'<br>'
            event += 'dst ip / port : ' + args['dstip'] + ' : ' + args['dstport'] +'<br>'
            if 'action' in args : event += 'action : ' + args['action'] + '<br>' 
            if 'service' in args : 'service : ' + args['service'] + '<br>'
            if 'reference' in args : event += 'reference : ' + args['ref'] + '<br>'
            if self.isduplicated_event(device,alertdatetime1,event,ipaddr) == True : 
                return {"state":"okay","message":"same event was exists"}
            result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event)
            if str(result).find('not_found') > -1 :
                result = self.request_triage(device,category,event_time,alertdatetime1,computer_name,user_name,args['dstip'],event)
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err
    
    def isduplicated_event(self,device,alertdatetime1,event,ipaddr):
        con = dbconn()
        cursor = con.cursor()
        rows = cursor.execute('select * from reqtriage where device = \'{}\' and alertdatetime1 = \'{}\' and event = \'{}\' and ipaddress = \'{}\''.format(device,alertdatetime1,event,ipaddr))
        rows = cursor.fetchall()
        if len(rows) > 0 : return True
        else : return False

    #description :  post 메소드 정의
    def post(self):
        try:
            request.data = re.sub(r'null','""',request.data)
            passive_traige_request.info(str(request.data))
            bypass_category = []
            if  bool(re.search("'",request.data)) : request.data = request.data.replace("'",'') #return {"state":"error","message":"do not include single quote"}
            #args = self.parser.parse_args()
            #restful 에서 request.data 으로 변경
            device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event = '','','','','','','',''
            args = json.loads(request.data,encoding='utf-8')
            if 'device' in args : device = args['device']
            else : device = 'symantec'
            category = args['category']
            if category.lower() in bypass_category : return {"state":"okay","message":"Bypass category %s"%category}
            # device 추가 시 해당 device event log parsing 작업 추가필요
            if device == 'symantec' and ISDISABLE == 'FALSE' : 
                result = self.parsing_symantec(device,category,args)
            elif device == 'fortinet' and ISDISABLE == 'FALSE' :
                if 'srcip' not in args or 'dstip' not in args or 'direction' not in args or 'srcport' not in args or 'dstport' not in args :
                    result = {"state":"error","message":"not found fortinet important fields"}
                else : result = self.parsing_fortinet(device,category,args)
            else : 
                result = {"state":"error","message":"not defind device %s"%device}
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
            return err

    #description : computer_name , ipaddress 를 받아 Triage 요청
    def request_triage(self,device,category,event_time,alertdatetime1,computer_name,user_name,ipaddr,event):
        try :
            for i in IGNORED_TAG :
                if bool(re.search(i.lower(),event.lower())) == True :
                    comment = '<font color="white"><strong>Ignored Event</strong></font>'
                    self.insert_triage(str(datetime.datetime.utcnow()),'','','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,'Null','false',event,comment)
                    return {"state":"okay","message":"This Event Was Passed"}
            maru_restIsSessionValid()
            # (state: '<NEW|ERROR|QUEUED|RUNNING|COMPLETE|FAILED>')
            # new (이미 요청을 한 호스트를 다시 triage 요청한 경우) , queued (requested) , running (acquring) 
            aquaring = request_hx(maru_token['token'],HXSRV_ACQS,'?sort=request_time+descending&limit=100','GET',None)
            queued = 0
            for host in aquaring['data']['entries'] :
                if host['state'] in ['QUEUED','RUNNING','NEW'] :
                    # print host['state']
                    queued += 1
            # 전달받은 computer_name & ipaddress 의 두 조건이 모두 일치하는지 확인하여 agent_id 리턴
            #print device + category + computer_name + ipaddr
            agent_id = self.check_host(maru_token['token'],device,category,computer_name,ipaddr)
            # 대상 host에 triage 생성 요청
            if str(agent_id).find('false') == -1 :
                if queued < MAX_QUEUE :
                    maru_restIsSessionValid()
                    result = request_hx(maru_token['token'],HXSRV_HOSTS,'/' + agent_id + '/triages','POST',None)
                    triage_id = str(result['data']['_id'])
                    # for bulktest must modify
                    #result = str(datetime.datetime.now())
                    #triage_id = result
                    
                    maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
                    # insert db req_success = "true"
                    self.insert_triage(triage_id,'passive','QUEUED','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,agent_id,'true',event,'<font color="white">NotYet</font>')
                else : 
                    self.insert_waitreqtriage(request.data)
                    result =  {"state":"okay","message":"limited_running_state_false"}
            else : # not found agent_id , send sms?
                comment = ''
                if str(agent_id).find('not_found') > -1 : 
                    comment = '<font color="red"><strong>NotFoundAgent</strong></font>'
                    self.insert_triage(str(datetime.datetime.utcnow()),'','','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,'Null','false',event,comment)
                elif str(agent_id).find('duplicated') > -1 : 
                    # if duplicated , add row ?  or add only event message ? 
                    '''
                    con = dbconn()
                    cursor = con.cursor()
                    rows = cursor.execute('select event,triage_id from reqtriage where computer_name = \'{0}\' order by request_time desc limit 1'.format(computer_name))
                    rows = cursor.fetchall()
                    before = rows[0][0]
                    triage_id = rows[0][1]
                    event = event.replace('\r\n','<br>')
                    if before.find(event) == - 1:
                        event = before + '<br>' + event
                        cursor.execute('update reqtriage set event = \'{0}\' where triage_id = \'{1}\''.format(event,triage_id))
                    con.commit()
                    con.close()
                    '''
                    comment = '<font color="white">duplicated request</strong></font>'
                    self.insert_triage(str(datetime.datetime.utcnow()),'','','',device,category,event_time,alertdatetime1,convert_timeformat(str(datetime.datetime.utcnow())),computer_name,user_name,ipaddr,'Null','false',event,comment)
                result = agent_id
            return result
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

    #description : 전달받은 computer_name or ipaddress 로 Triage_ID 를 검색
    # api 로 computer_name 검색 시 equal 이 아닌 like 옵션이 적용되어 검색값이 여러 개 나올 수 있어 ip address 체크 (X)
    # 또는 검색 결과 리스트의 hostname을 computer_name 과 같은지 다시 체크 (O)
    # 동일한 computer_name 이 존재 할 수 있어 last audit time 옵션 설정
    def check_host(self,token,device,category,computer_name,ipaddr):
        check_only_ipaddress = ['ntp','fortinet'] # IP로 검색해야 하는 카테고리
        try:
            iplist = []
            result = {"state":"okay","message":"not_found_agent_false"}
            if device.lower() != 'fireeye' and ISDISABLE != 'FALSE' : return result
            maru_restIsSessionValid()
            # get agent_id from computer_name or ipaddress 
            if computer_name != '' and category.lower() not in check_only_ipaddress : 
                response = request_hx(token,HXSRV_HOSTS,'?search=' + computer_name + '&sort=last_audit_timestamp+descending&limit=100','GET',None)
                if response['data']['total'] == 0 : 
                    return {"state":"okay","message":"not_found_agent_false"}
                for entry in response['data']['entries'] :
                    if computer_name.lower() == entry['hostname'].lower() :
                        if self.check_last_triage_time(entry['_id'],device,category) == True : 
                            result = entry['_id']
                        else : result = {"state":"okay","message":"req_duplicated_false"}
                        break
                    else : result = {"state":"okay","message":"not_found_agent_false"}
            elif ipaddr != '' :
                response = request_hx(token,HXSRV_HOSTS,'?search=' + ipaddr + '&sort=last_audit_timestamp+descending&limit=200','GET',None)
                #print json.dumps(response,indent=4)
                if response['data']['total'] == 0 : 
                    return {"state":"okay","message":"not_found_agent_false"} 
                for entry in response['data']['entries'] :
                    if ipaddr == entry['last_poll_ip'] :
                        if self.check_last_triage_time(entry['_id'],device,category) == True : 
                            result = entry['_id']
                        else : result = {"state":"okay","message":"req_duplicated_false"}
                        break
                    else : result = {"state":"okay","message":"not_found_agent_false"}
                '''
                for netinfo in sysinfo['data']['networkArray']['networkInfo'] :
                    if netinfo.has_key('ipArray') :
                        if netinfo['ipArray'].has_key('ipInfo') :
                            for ipinfo in netinfo['ipArray']['ipInfo'] :
                                if ipinfo.has_key('ipAddress') :
                                    ip = ipinfo['ipAddress']
                                    if ip.find('127.0.0.1') == -1 and ip.find('169.254') == -1 :
                                        iplist.append(ip)
                if ipaddr in iplist :
                    if self.check_last_triage_time(entry['_id'],device,category) == True :
                        result = entry['_id']
                else : result = 'check_last_triage_time_false'
                '''
            return result
            #allhost = request_hx(maru_token,HXSRV_HOSTS,'?limit=10000','GET',None,'yes')
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

    # 특정 시간 동안 동일 호스트의 Passive Triage 를 요청하는 케이스 제한 (not use hx server request_time)
    def check_last_triage_time(self,agent_id,device,category):
        try:
            #response = request_hx(maru_token['token'],'/hx/api/v3/acqs/triages','?sort=request_time+descending&search={0}&limit=1'.format(agent_id),'GET',None)
            #maru_token['last_use_timestamp'] = str(datetime.datetime.utcnow())
            if 1==2 : #response['data']['total'] == 0 :
                return True
            else :
                #reqtime = response['data']['entries'][0]['request_time'].replace('T',' ').replace('Z','')
                reqtime = self.get_reqtime(agent_id,device,category)
                if reqtime.find('false') > -1 : return True
                reqtime = convert_timeformat(reqtime)
                #duration = (datetime.datetime.utcnow() - datetime.datetime.strptime(reqtime, '%Y-%m-%d %H:%M:%S.%f')).seconds / 60
                duration = (datetime.datetime.utcnow() - datetime.datetime.strptime(reqtime, '%Y-%m-%d %H:%M:%S')).seconds / 60
                #print 'duration %s' %str(duration)
                return(duration > MAX_DURATION)
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

    #description :  insert triage info 
    def insert_triage(self,triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment):
        try:
            if triage_id.find('Null') > -1 : downlink = ''
            elif triage_id.find('.') > -1 : downlink = ''
            else: downlink = '<a href ="{0}/es_query_result/stored_triage_files/{1}" target="_blank">{2}.mans</a>'.format(hxtool_srv,triage_id,triage_id) 
            con = dbconn()
            cursor = con.cursor()
            if DBTYPE == 'mariadb':
                event = event.replace('\\','/')
                cursor.execute('insert ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment))
            else :
                cursor.execute('insert or ignore into reqtriage values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\',\'{10}\',\'{11}\',\'{12}\',\'{13}\',\'{14}\',\'{15}\')'.format(triage_id,req_type,state,downlink,device,category,event_time,alertdatetime1,request_time,computer_name,user_name,ipaddress,agent_id,req_success,event,comment))
                
            con.commit()
            con.close()
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
    #description :  insert wait req , 최대치 triage 요청인 경우 table 저장 후 다시 요청
    def insert_waitreqtriage(self,postbody) :
        try:
            con = dbconn()
            cursor = con.cursor()
            if DBTYPE == 'mariadb' :cursor.execute('insert ignore into waitreqtriage values(\'{0}\')'.format(postbody))
            else : cursor.execute('insert or ignore into waitreqtriage values(\'{0}\')'.format(postbody))
            con.commit()
            con.close()
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))
    
    # category : db에서 triage request time 검색
    def get_reqtime(self,agent_id,device,category):
        try: 
            con = dbconn()
            cursor = con.cursor()
            # 동일 device , category 이벤트가 특정시간 동안 여러개 triage 요청 들어오면 이벤트 컬럼만 업데이트 하고 triage 요청하지 않음 (현재는 device , 시간만 체크로 변경)
            #rows = cursor.execute('select request_time from reqtriage where (agent_id = \'{0}\' and req_success = "true" and device = \'{1}\' and category = \'{2}\') order by request_time desc limit 1'.format(agent_id,device,category))
            rows = cursor.execute('select request_time from reqtriage where (agent_id = \'{0}\' and req_success = "true" and device = \'{1}\') order by request_time desc limit 1'.format(agent_id,device))
            rows = cursor.fetchall()
            con.close()
            if len(rows) == 0 :
                return 'get_reqtime_false'
            else :
                return rows[0][0]
            con.close()
        except Exception as err:
            err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
            #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
            passive_traige_error.error(str(err))

api.add_resource(ReqTriage, '/reqtriage')

# maru flask area
# triage 파일 다운로드 함수
@app.route('/es_query_result/stored_triage_files/<triageid>')
def get_passive_triage_file(triageid):
    try:
        maru_restIsSessionValid()
        response =  download_triage(maru_token['token'],'/hx/api/v3/acqs/triages/{0}.mans'.format(triageid))
        if response.find('Not Found') == -1 :
            response = response.split('/')[-1]
            result = '<a href= "{0}/es_query_result/passive_triage_files/{1}">Download {2}</a>'.format(hxtool_srv,response,response)
            result += '<br><a href= "{0}/es_query_result/passive_triage_files/">All Passive Files In HXTools Server</a>'.format(hxtool_srv)
            #return result
            return redirect('{0}/es_query_result/passive_triage_files/{1}'.format(hxtool_srv,response,response))
        else : return response
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : triage list view 메인페이지
@app.route('/es_query_result/triage_list/<type>',methods=['POST','GET'])
def triage_list(type) :
    try:
        html = '<html>'
        con = dbconn()
        cursor = con.cursor()
        if type == 'ls' :
            html += '<script>setTimeout("location.reload()",600000)</script>'
            #rows = cursor.execute('select triage_id,req_type,state,downlink,device,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where req_success = "true" order by cast(triage_id as unsigned) desc limit %d'%MAX_VIEW_LIST_NUM)
            rows = cursor.execute('select triage_id,req_type,state,downlink,device,request_time,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage  order by request_time desc limit %d'%MAX_VIEW_LIST_NUM)
            rows = cursor.fetchall()
            con.close()
        elif type == 'search' :
            if request.method == 'POST':
                keyword = request.form['keyword']
                field = 'event'
            else : keyword , field = request.args.get('keyword') , request.args.get('field')
            #search_sql = 'select triage_id,req_type,state,downlink,device,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where {0} like \'%{1}%\' order by cast(triage_id as unsigned) desc limit {2}'.format(field,keyword,MAX_VIEW_LIST_NUM)
            search_sql = 'select triage_id,req_type,state,downlink,device,request_time,alertdatetime1,computer_name,ipaddress,event,comment from reqtriage where {0} like \'%{1}%\' order by request_time desc limit {2}'.format(field,keyword,MAX_VIEW_LIST_NUM)
            rows = cursor.execute(search_sql)
            rows = cursor.fetchall()
            con.close()
        # html style
        html += '''
        <title>Threat Hunting - Cafe24</title>
        <style>body {margin: 0;}
        #fixed-menu{
        width: 100%;
        background-color: #ffffff;
        position: fixed;
        top: 0px;
        left: 0px;
        }
        #main-content {
        width: 100%;
        margin-top: 120px;
        }
        #fixed-menu li {
        display: inline-block;
        margin-right: 30px;
        }
        img {
        max-width: 100%;
        }
        </style>
        <div id="fixed-menu">
        <style> * {margin:0px;padding:0px;}</style>
        <form action="/es_query_result/triage_list/search" method="post"><input type="text" name="keyword"> <input type="submit" value="Search Event" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></form>
        [ All Search Result Maximum Rows : 300  Order By Triage Request Time ] <br>
        <strong>
         <a href="/es_query_result/triage_list/ls" style="text-decoration:none">latest 300s</a> 
         | <a href="/es_query_result/triage_list/search?keyword=%5B+Threat+%5D&field=comment" style="text-decoration:none"> Threat </a>
         | <a href="/es_query_result/triage_list/search?keyword=noproblem&field=comment" style="text-decoration:none"> NoProblem </a> 
         | <a href="/es_query_result/triage_list/search?keyword=NotYet&field=comment" style="text-decoration:none"> 미확인 </a> 
         |  <a href="/es_query_result/triage_list/search?keyword=NotFoundAgent&field=comment" style="text-decoration:none"> Not Found Agent </a> 
         | <a href="/es_query_result/triage_list/search?keyword=fireeyehx&field=device" style="text-decoration:none">FireeyeHX </a>
         | <a href="/es_query_result/triage_list/search?keyword=Symantec&field=device" style="text-decoration:none">Symantec</a>
         | <a href="/es_query_result/triage_list/search?keyword=fortinet&field=device" style="text-decoration:none">Fortinet</a>
         | <a href="/es_query_result/topusers" style="text-decoration:none" target=_blank>Users</a>
         | <a href="/es_query_result/events" style="text-decoration:none" target=_blank>Events</a>
         | <a href="/osintdb/ls" style="text-decoration:none" target=_blank>OSINTDB</a>
         | <a href="/esfromtext" style="text-decoration:none" target=_blank>ES With IOC</a>
         | <a href="/es_query_result/hxhealth" style="text-decoration:none" target=_blank>HXHealth</a>
         | <a href="/hosts_info" style="text-decoration:none" target=_blank>hosts</a>
         | <a href="/daily_report" style="text-decoration:none" target=_blank>dailyRPT</a>
         | <a href="/es_query_result/search_triage" style="text-decoration:none" target=_blank>Search From Triage</a><br>
         월간보고 그래프 : 
         <a href="/graph/hx_daily_event_num?where=" style="text-decoration:none" target=_blank>DailyEvent</a>
         | <a href="/graph/hx_monthly_event_name?where=" style="text-decoration:none" target=_blank>EventName</a>
         | <a href="/graph/hx_host_num?where=" style="text-decoration:none" target=_blank>Host</a>
         | <a href="/graph/osint_ioc_num?where=" style="text-decoration:none" target=_blank>OSINT</a>
         | <a href="/graph/osint_ioc_tag?where=" style="text-decoration:none" target=_blank>MalTrend</a>
         </strong>
         </div>
         <div id="main-content">
         <table table style="table-layout:fixed;font-size:12px;" border="1" cellspacing="0" backgroundcolor="dark">
        <tr >
        <th>TriageID</th><th>Req Info</th><th>Download</th><th>Device</th><th>RequestTime(utc0)</th><th>AlertTime(utc0)</th><th>User Info</th><th>Event Message</th><th>Comment</th>
        </tr>
        '''
        for row in rows :
            html += '<tr style="font-size:12px;" onMouseOver=bgColor="#81BEF7" onMouseOut=bgColor="" bgcolor="#FBFAFA">'
            for idx,item in enumerate(row) :
                if idx == len(row) - 1 : # last index = submit comment / row[0] = triage_id
                    html += ' <td  style="word-break:break-all;border: 1px solid #81BEF7;">{0}<br><form action="{1}" method="get" target="print_popup" onsubmit="window.open(\'about:blank\',\'print_popup\',\'width=1100,height=800\');"><div><div style="display:inline;width:200px;"> <input type="submit" value="Write" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form></td>'.format(item,hxtool_srv + '/write_proc/%s'%row[0])

                    #html += ' <td  style="word-break:break-all;border: 1px solid #81BEF7;">{0}<br><form action="{1}" method="get"><div><div style="display:inline;width:200px;"> <input type="submit" value="Write" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form></td>'.format(item,hxtool_srv + '/write_proc/%s'%row[0])
                elif idx== len(row) -2 : # event message
                    eventname = item.split('<br>')[0] + '<br>'
                    tmp = check_interesting_event(eventname)
                    item = item.replace(eventname,tmp)
                    html += '<td width=600 style="word-break:break-all;border: 1px solid #81BEF7;">' + item + '</td>' 
                elif idx == 1: html += '<td style="border: 1px solid #81BEF7;" ><a href = "/es_query_result/triage_list/search?keyword=%s&field=req_type" style="text-decoration:none"><font color="black">'%item + item + '</font></a>' #req_type
                elif idx == 2: html += '<br><a href = "/es_query_result/triage_list/search?keyword=%s&field=state" style="text-decoration:none"><font color="black">'%item + item + '</font></a></td>' # state
                elif idx == 4: html += '<td style="border: 1px solid #81BEF7;" ><a href = "/es_query_result/triage_list/search?keyword=%s&field=device" style="text-decoration:none"><font color="black">'%item + item + '</font></a></td>' #device
                elif idx == 5 : html += '<td style="border: 1px solid #81BEF7;" ><font color="black">' + item.replace(' ','T') + '</font></td>' # request_time
                elif idx == 6: html += '<td style="border: 1px solid #81BEF7;" ><font color="black">' + item.replace(' ','T') + '</font></td>' # alertdatetime1
                elif idx == 7: html += '<td style="border: 1px solid #81BEF7;" ><a href = "/es_query_result/triage_list/search?keyword=%s&field=computer_name" style="text-decoration:none"><font color="black">'%item + item + '</font></a>' #computer_name
                elif idx == 8: html += '<br><a href = "/es_query_result/triage_list/search?keyword=%s&field=ipaddress" style="text-decoration:none"><font color="black">'%item + item + '</font></a></td>' # ipaddress
                #elif idx == 0: html += '<td style="border: 1px solid #81BEF7;" ><br><a href = "/es_query_result/triage_list/req_maxav?triage_id=%s" style="text-decoration:none" title="check md5 in triage with maxav"><font color="black">'%item + item + '</font></a></td>' # if click > query maxav 
                else : html += '<td style="border: 1px solid #81BEF7;" ><font color="black">' + item+ '</font></td>'
            html += '</tr>'
        html += '</table></div></html>'
        return html
        #return render_template('triage_list.html',rows = rows)
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : 지라 생성 함수 (이벤트 처리 지라의 하위 지라로 생성)
from jira import JIRA
def create_event_jira(report):
    try :
        SPLITTAG = '\r\n'
        now = datetime.datetime.today().strftime("%Y-%m-%d")
        #EVENT_ISSUE = 'SECURITY-23447' # 2018
        EVENT_ISSUE = 'SECURITY-32283' #2019
        USER = 'yskim04'
        jira = JIRA('https://jira.simplexi.com',auth=(USER,BUG))
        report_lines = report.split(SPLITTAG)
        print len(report_lines)
        summary , description , labels = '[SecurityEvent] ' , u'이벤트 발생 - ' , [u'is팀','SecurityEvent']
        for idx,line in enumerate(report_lines) :
            if idx == 0 : 
                if line.find('Threat') > -1 : 
                    summary += '*Threat* '
                    labels.append('threats')
                else : 
                    summary += '*NoProblem* '
                    labels.append('noproblem')
                summary += now + ' '
            elif line.find('Indicator') > -1 :
                line = line.replace('Indicator    :','')
                summary += line + ' '
                description += line
            elif line.find('ComputerName') > -1 : summary += line.replace('ComputerName :','')
        # create subtask
        subtask = {
            'project' : { 'key' : 'SECURITY' },
            'summary' : summary, # 변수
            'description' : description, # 변수
            'labels' : labels, # 변수
            'issuetype' : { 'name' : u'Sub_보안이슈' },
            'parent' : { 'key' : EVENT_ISSUE },
            'assignee' : { 'name' : USER },
            'reporter' : {'name' : USER },
            'customfield_15313' : now,
            'customfield_15314' : now,
            'duedate' : now
        }
        issue = jira.create_issue(fields=subtask)
        #print("created child: " + issue.key)
        # worklog 추가
        jira.add_worklog(issue, timeSpent="5m", user=USER, comment= '확인완료\r\n' + report)
        #jira.add_comment(issue,checked) # comment 추가
        #issue.update(status="Closed")   # 상태 업데이트 (X)
        return issue.key
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))        

@app.route('/write_proc/<triage_id>',methods=['GET'])
def write_proc(triage_id) :
    html = '<html><title>Write Comment</title>이벤트 처리 내역을 기입한 후 "쪽지&지라생성" 버튼을 클릭하세요.<br><br><form action="/write_comment" method="post"><input type="radio" name="result" value="[ Threat ];위협">위협<input type="radio" name="result" value="[ NoProblem ];비위협">비위협<input type="radio" name="result" value="[ Threat ];정책위반">정책위반<input type="radio" name="result" value="[ NoProblem ];IS팀테스트">IS팀테스트<br><br><textarea name="comment" cols="130" rows="20">[ 발생원인 ]\r\n\r\n\r\n[ 확인내역 ]\r\n\r\n\r\n[ 처리 내역 ]\r\n\r\n\r\n[ 처리 상태 ]\r\n완료/대기\r\n\r\n</textarea><div><div style="display:inline;width:200px;"><input type="hidden" name="triage_id" value="%s"><input type="submit" value="쪽지&지라생성" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form>'%triage_id
    return html
#description : 처리내역  & 지라 생성,삭제 함수
@app.route('/write_comment',methods=['POST'])
def write_comment() :
    try:
        con = dbconn()
        cursor = con.cursor()
        #comment = re.escape(request.form['comment'])
        triage_id = request.form['triage_id']
        result_form = request.form['result'].split(';') # .replace('yyy','<font color="red">[ Threat ]</font>').replace('nnn','<font color="blue">[ NoProblem ]</font>')
        result = result_form[0].replace('[ Threat ]','<font color="red">[ Threat ]</font>').replace('[ NoProblem ]','<font color="blue">[ NoProblem ]</font>')
        desc = result_form[1]
        comment = request.form['comment'].replace('\\','/')
        comment = result + u'\r\n[ 결과 ]\r\n' + desc + '\r\n\r\n' + comment
        if bool(re.search("'",comment)) == False and len(comment) < 2000 :
            rows = cursor.execute('select comment from reqtriage where triage_id = \'{0}\''.format(triage_id))
            rows = cursor.fetchall()
            before = rows[0][0]
            cursor.execute('update reqtriage set comment = \'{0}\' where triage_id = \'{1}\''.format(comment.replace('\r\n','<br>'),triage_id)) #.format(before + '<br>' + comment.replace('\r\n','<br>'),triage_id))
            con.commit()
            if comment.find('noupdate') > -1 : return '<script>window.close();</script>'
            rows = cursor.execute('select * from reqtriage where triage_id = \'{0}\''.format(triage_id))
            rows = cursor.fetchall()
            if comment.find('[ Threat ]') > -1 : msg = '[ Fireeye HX ] 처리내역 업데이트 알람 (Threat)\r\n\r\n'
            else : msg = '[ Fireeye HX ] 처리내역 업데이트 알람 (NoProblem)\r\n\r\n'
            for row in rows :
                alarm_event = re.sub('" target=.*</a>','',re.sub('<a href="',u'상세보기:',row[14].replace('<br>','\r\n')))
                msg += 'Comment      :' + comment + '\r\n' + '\r\n'
                msg += 'Indicator    :' + alarm_event + '\r\n' + '\r\n'
                msg += 'Triage ID    :' + row[0] + '\r\n' + '\r\n'
                msg += 'Device       :' + row[4] + '\r\n' + '\r\n'
                msg += 'AlertTime    :' + row[7] + '\r\n' + '\r\n'
                msg += 'ComputerName :' + row[9] + '\r\n' + '\r\n'
                msg += 'IPAddress    :' + row[11] + '\r\n' + '\r\n'
                msg += '사용자 Event 목록 : https://hx-tool.hanpda.com/es_query_result/triage_list/search?keyword={0}&field=computer_name'.format(row[9])
            jira_key = create_event_jira(str(msg))
            msg += '\r\n\r\n' + '자동생성 지라 URL : ' + 'https://jira.simplexi.com/browse/' + jira_key
            sendalarm(str(msg).replace('<br>',''),alarmreceiver)
            con.close()
        else : return {'error':'do not include single quote or limit 2000byte input size'}
        #return redirect(url_for('triage_list',type='ls'))
        return '<script>window.close();</script>'
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

@app.route('/es_query_result/delete_comment/<triage_id>',methods=['POST','GET'])
def delete_comment(triage_id):
    try:
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('update reqtriage set comment = \'{0}\' where triage_id = \'{1}\''.format('',triage_id))
        con.commit()
        con.close()
        return redirect(url_for('triage_list',type='ls'))
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

 #description : 사용자 통계페이지 (24시간,한달)
@app.route('/es_query_result/topusers')
def topusers():
    con = dbconn()
    cursor = con.cursor()
    reqtime = convert_timeformat(str(datetime.datetime.utcnow())).split(' ')[0]
    if DBTYPE == 'sqlite' :
        sql1 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date("now", "-1 day") group by computer_name order by events desc'
        sql2 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date("now", "-1 month") group by computer_name order by events desc'
    else : 
        sql1 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 day) group by computer_name order by events desc'
        sql2 = 'select count(*) as events ,computer_name  from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 month) group by computer_name order by events desc'
    cursor.execute(sql1)
    rows = cursor.fetchall()
    html = '<html><title>Event Summary</title><strong>최근 24시간 이벤트 발생 사용자 목록</strong><br>'
    for row in rows :
        if len(row[1]) <  5 : continue
        html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=computer_name" style="text-decoration:none">{1}</a><br>'.format(row[1],row[1])
    cursor.execute(sql2)
    rows = cursor.fetchall()
    html += '<br><strong>최근 30일 이벤트 발생 사용자 목록</strong><br>'
    for row in rows :
        if len(row[1]) <  5 : continue
        html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=computer_name" style="text-decoration:none">{1}</a><br>'.format(row[1],row[1])
    html += '</html>'
    return html 

#description : 이벤트 통계 페이지 (24시간,한달)
@app.route('/es_query_result/events')
def events():
    con = dbconn()
    cursor = con.cursor()
    reqtime = convert_timeformat(str(datetime.datetime.utcnow())).split(' ')[0]
    html ='<html><title>Event Summary</title>* Red != {0}<br>* Triage 요청 예외 항목 : {1}<br><br>'.format(RE_TAG,str(IGNORED_TAG))
    html += '<strong>Daily Events (최근 24시간)</strong><br>'
    if DBTYPE == 'sqlite' :
        sql1 = 'select count(*) as num,substr(event,1,pos-1) as firstevent from (select *,instr(event,"<br>") as pos from reqtriage where alertdatetime1 > date("now", "-1 day")) group by firstevent order by num'
        sql2 = 'select count(*) as num,substr(event,1,pos-1) as firstevent from (select *,instr(event,"<br>") as pos from reqtriage where alertdatetime1 > date("now", "-1 month")) group by firstevent order by num'
    else :  
        sql1 = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 day) group by firstevent order by num'
        sql2 = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where alertdatetime1 > date_add(utc_timestamp(), interval -1 month) group by firstevent order by num'
    cursor.execute(sql1)
    rows = cursor.fetchall()
    for row in rows :
        msg = row[1].split('>')[-1]
        if bool(re.search(RE_TAG,msg.lower())) == False :
                if len(msg) <  5 : continue
                html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none"><strong><font color="red">{1}</font></strong></a><br>'.format(msg,msg)
        else :html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none">{1}</a><br>'.format(msg,msg)
    cursor.execute(sql2)
    rows = cursor.fetchall()
    html += '<br><strong>Monthly Events (최근 30일)</strong><br>'
    for row in rows :
        msg = row[1].split('>')[-1]
        if bool(re.search(RE_TAG,msg.lower())) == False :
                if len(msg) <  5 : continue
                html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none"><strong><font color="red">{1}</font></strong></a><br>'.format(msg,msg)
        else :html += str(row[0]) +' : ' + '<a href = "/es_query_result/triage_list/search?keyword={0}&field=event" style="text-decoration:none">{1}</a><br>'.format(msg,msg)
    return html 


#description : triage analyzer
import os,sys,time,shutil,re
import xml.etree.ElementTree as ET
import zipfile

@app.route('/es_query_result/search_triage',methods=['GET'])
def search_triage():
    html = '''
            <title>Search Keyword From Triage - Cafe24</title>
            <frameset rows="7%,*"> 
            <frame src="/es_query_result/search_triage_bar"></frame>
            <frame name="search_triage_result_frame"></frame>
            </frameset>
            '''
    return html

@app.route('/es_query_result/search_triage_bar',methods=['GET'])
def search_triage_bar():
    html = '''
    * Triage 파일에서 지정한 키워드를 grep 명령어로 검색합니다. grep 명령어의 대상 파일명은 검색 할 "triageid 번호" + ".one" 확장자입니다. (ex : grep -i "malware\.exe" 6000.one | grep -v "test")<br>
    <form action="/es_query_result/timeline" method="post" target="search_triage_result_frame"><input type="text" name="keyword" style="width:700px">
    <input type="submit" value="Search" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;">
    <input type="radio" name="beautify" value="yes" checked="checked">beautify
    <input type="radio" name="beautify" value="no">rawdata | 
    <input type="radio" name="bypass" value="yes" checked="checked">Bypass Reg,ImgLoad,ProcMem
    <input type="radio" name="bypass" value="no">Check Reg,ImgLoad,ProcMem
    </form>
    '''
    return html

@app.route('/es_query_result/timeline',methods=['POST'])
def get_timeline():
    try:
        filter = request.form['keyword']
        '''
        cmd_result = os.popen(filter).read()
        if len(cmd_result) / (1024 *1024) > 31 : return ('Too Much Result Text')
        return Response(cmd_result, mimetype='text/plain')
        '''
        triage_id = re.findall('[0-9]{1,20}\.one',filter)[0].replace('.one','')
        #print triage_id
        path = '/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files'
        mans = path + '/' + triage_id + '.mans'
        onelinefile = path + '/' + triage_id + '.one'
        extract_path = path + '/' + triage_id + '_extract'
        temp = extract_path + '/' + filter.split(' ')[0].replace('"','') + '_' + triage_id  + '_temp.txt'
        grep_re = extract_path + '/' + filter.split(' ')[0].replace('"','') + '_' + triage_id  + '.txt'
        if os.path.isfile(onelinefile)  == False :
            if os.path.isfile(mans)  == False:
                maru_restIsSessionValid()
                response =  download_triage(maru_token['token'],'/hx/api/v3/acqs/triages/{0}.mans'.format(triage_id))
                if response.find('Not Found') > -1 :  return '"error":"Not Found Triage File"'
            flist = unzip_triage(mans,extract_path)
            for file in flist :
                make_oneline(os.path.join(extract_path,file),onelinefile)
            
        #os.system('grep -i  "%s" %s | grep -iv "regkeyevent\\|imageload\\|processitem" > %s ' %(filter,onelinefile,temp))
        filter = re.sub('[%;&><`!\\\$]','',filter)
        cmdline = re.sub('[0-9]{1,20}\.one',os.path.join(path, triage_id + '.one'),filter)
        if request.form['bypass'] == 'yes' : 
            cmdline = cmdline + ' | grep -iv "regkeyevent\\|imageload\\|processitem\\|registryitem" > ' + temp
            #print cmdline
            sec_flag = check_command_injection(cmdline)
            if sec_flag == False : return 'Bad Request. Try Again'
            os.system(cmdline)
        else : 
            sec_flag = check_command_injection(cmdline)
            if sec_flag == False : return 'Bad Request. Try Again'
            os.system('%s > %s ' %(cmdline , temp))
        if 1==1 : # os.path.isfile(grep_re) == False:
            if os.path.getsize(temp) > (1024*1024 *30 ) : return '"error":"result  size bigger than 30MBytes"'
            elif os.path.getsize(temp) == 0 : return 'No Matched. Try Again'
            f = open(grep_re,'wb')
            result = open(temp,'rb')
            for line in result.readlines() : 
                line = line.replace('\n','\n' + '-' *200 + '\n').replace('<','\n<')
                line = line.replace('\n<value>',' : ').replace('<name>','')
                f.write(line)
            f.close()
            result.close()
        if request.form['beautify'] == 'yes' :  
            with open(grep_re,'r') as resultf :
                resultf = resultf.read().replace('<','').replace('>',' : ')
                #re.sub(filter,'<font color ="red">filter</font>',resultf)
        else :
            with open(temp,'r') as resultf :
                resultf = resultf.read()
        return Response(resultf, mimetype='text/plain')
    
    except Exception as err :
        #return 'Bad Request. Try Again'
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        return str(err)

def check_command_injection(cmdline):
    cmdline = cmdline.replace('\\|','nosplit')
    sec_flag = True
    cmdline_dic = cmdline.split('|')
    for cmd in cmdline_dic :
        #print 'split value : %s'%cmd
        if bool(re.search('^(\s*(grep|sort|uniq|awk))',cmd)) == False : 
            sec_flag = False
            break
    return sec_flag


 
# triage 파일 압축 해제 
def unzip_triage(filename,extract_path):
    if os.path.isdir(extract_path):
        shutil.rmtree(extract_path)
    os.mkdir(extract_path)
    triage = zipfile.ZipFile(filename)
    triage.extractall(extract_path)
    triage.close()
    os.system('rm {0}/*.json;rm {1}/script.xml'.format(extract_path,extract_path))
    flist = os.listdir(extract_path)
    return flist
    
# 압축 해제된 triage 파일을 이벤트별로 한 라인으로 변경하는 함수(기본 xml 형식으로 여러 라인으로 분할되어 있음)
def make_oneline(filename,onelinefile):
    ALLLINE = open(onelinefile,'ab')
    one = ''
    with open(filename,'rb') as ori :
        for line in ori.xreadlines():
            line = line.replace('\n','').replace('\r\n','').replace('&amp;','&')
            if bool(re.search('^ {1}</',line)) :
                one += line
                one = one.replace('  ','').replace('\t','') + '\n'
                one = one.replace('<details>','').replace('<detail>','')
                one = re.sub('((</\w{1,40}>)|(<\w{1,30}/>))','',one)
                #one = re.sub(' uid=".*"','',one)
                ALLLINE.write(one)
                #print one
                one = ''
            #elif line.find(' <') > -1: one += line
            #elif line.find('Host:') > -1 : one += line
            else : one += line
    ALLLINE.close()

#description : test api 함수
@app.route('/health_check',methods=['GET'])
def health_check() :
    return 'alive'

@app.route('/bulktest',methods=['POST'])
def bulktest():
    data = request.data
    print data
    return str(data)

@app.route('/byebye',methods=['GET'])
def byebye():
    triage_id = request.args.get('triage_id')
    if triage_id.find('maru') == -1 : return 'test page'
    con = dbconn()
    cursor = con.cursor()
    cursor.execute('delete from reqtriage where triage_id = "{0}"'.format(triage_id.replace('maru','')))
    con.commit()
    con.close()
    return redirect(url_for('triage_list',type='ls'))
#description : hx에  등록된 이력이 있는 osint ioc database view page
#hx 등록은 현재 시간 기준 한달 내 보고된 ioc만 등록
@app.route('/osintdb/<type>',methods=['POST','GET'])
def osintdb(type) :
    try:
        html = '<html>'
        osintdb = '/home/apps/hxtool/hx_es_daemon/dbosint.db'
        con = sqlite3.connect(osintdb)
        cursor = con.cursor()
        if type == 'ls' :
            rows = cursor.execute('select idx,date,ioctype,value,tag,description,report_url,reference from osint_ioc order by idx desc limit 1000')
            rows = cursor.fetchall()
            con.close()
        elif type == 'search' :
            if request.method == 'POST':
                keyword = request.form['keyword']
                field = 'value'
            else : keyword , field = request.args.get('keyword') , request.args.get('field')
            search_sql = 'select idx,date,ioctype,value,tag,description,report_url,reference from osint_ioc where {0} like \'%{1}%\' order by idx desc limit 1000'.format(field,keyword)
            rows = cursor.execute(search_sql)
            rows = cursor.fetchall()
            con.close()
        # html style
        html += '''
        <title>OSINT DB - Cafe24</title>
        <style>body {margin: 0;}
        #fixed-menu{
        width: 100%;
        background-color: #ffffff;
        position: fixed;
        top: 0px;
        left: 0px;
        }
        #main-content {
        width: 100%;
        margin-top: 120px;
        }
        #fixed-menu li {
        display: inline-block;
        margin-right: 30px;
        }
        img {
        max-width: 100%;
        }
        </style>
        <div id="fixed-menu">
        <style> * {margin:0px;padding:0px;}</style>
        <form action="/osintdb/search" method="post"><input type="text" name="keyword"> <input type="submit" value="Search IOC(MD5,IP Etc)" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></form>
        <strong>
        * FireEye HX 에 자동 등록되는 IOC 리스트 (현재시간 기준 한달 내 보고된 IOC)<br>
         <a href="/osintdb/ls" style="text-decoration:none">latest 1000s</a> 
         | <a href="/osintdb/search?keyword=hybrid&field=reference" style="text-decoration:none"> Hybrid Submitted MD5 </a>
         | <a href="/osintdb/search?keyword=app.any.run&field=reference" style="text-decoration:none"> app.any.run Submitted MD5 </a>
         | <a href="/osintdb/search?keyword=shodan&field=reference" style="text-decoration:none"> Shodan RAT C2 </a>
         </strong>
         </div>
         <div id="main-content">
         <table table style="table-layout:fixed;font-size:12px;" border="1" cellspacing="0" backgroundcolor="dark">
        <tr >
        <th>IDX</th><th>Date</th><th>Value</th><th>TAG</th><th>Description</th>
        </tr>
        '''
        for row in rows :
            html += '<tr style="font-size:12px;" onMouseOver=bgColor="#81BEF7" onMouseOut=bgColor="" bgcolor="#FBFAFA">'
            #select idx,date,ioctype,value,tag,description,report_url,reference
            for idx,item in enumerate(row) :
                if idx == 3: html += '<td style="border: 1px solid #81BEF7;" ><font color="black"><a href="%s" target=_blank>%s</font></td>'%(row[6],item) # value link report_url
                elif idx in [2,6,7] : continue
                else : html += '<td style="border: 1px solid #81BEF7;" ><font color="black">' + str(item) + '</font></td>'
            html += '</tr>'
        html += '</table></div></html>'
        return html
        #return render_template('triage_list.html',rows = rows)
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#description : 월간 수치 그래프 생성 부문
import plotly.graph_objs as go
import pymysql,sqlite3,plotly,sys,re
import collections
import pandas as pd
import plotly.plotly as py

'''
#현재 시간 기준 Query
sql_query = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where comment not like "%is팀%테스트%" and event like "%fireeye :%" and request_time > date_add(utc_timestamp(), interval -1 month) group by firstevent order by num desc'
sql_query = 'select computer_name,count(*) as events from reqtriage where comment not like "%is팀%테스트%" and event like "%fireeye :%" and request_time > date_add(utc_timestamp(), interval -1 month) group by computer_name order by events desc'
'''
#fireeye hx triage 를 기반으로 월간 수치화 그래프 생성 메인함수
@app.route('/graph/<type>',methods=['GET'])
def get_graph(type):
    dbcon = pymysql.connect(host='localhost',port=3306, user='security',passwd='security',db='security_event', charset='utf8mb4',autocommit=True)
    if os.path.isdir('/home/apps/hxtool/hx_es_daemon/es_query_result/graph') == False : os.mkdir('/home/apps/hxtool/hx_es_daemon/es_query_result/graph')
    where = request.args.get('where')
    if where == '' : 
        where = str(datetime.datetime.now()).split(' ')[0].split('-')
        where = where[0] + '-' + where[1]
    if type == 'osint_ioc_tag' :
        make_bar_OSINT_IOC_TAG(where)
        return redirect('/es_query_result/graph/{0}_ioc_tag.html'.format(where))
    elif type == 'hx_daily_event_num' :
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_hx_daily_event_num.html'.format(where)
        sql_query1 = 'select SUBSTRING_INDEX(request_time, " ", 1) as alerttime , count(*) as num from reqtriage where request_time like "%{0}%" and comment not like "%is팀%테스트%" and event like "%fireeye :%" group by alerttime'.format(where)
        sql_query2 = 'select SUBSTRING_INDEX(request_time, " ", 1) as alerttime , count(*) as num from reqtriage where request_time like "%{0}%" and comment like "%[ Threat ]%" and event like "%fireeye :%" group by alerttime'.format(where)
        make_double_bar_graph(where,dbcon,sql_query1,sql_query2,'Day','Num',False,'notsort','Num',' FireeyeHX 일간 발생 이벤트 수 VS 위협으로 확인된 이벤트 수 (총 이벤트 : {0} 건  *테스트 제외* )','','이벤트 개수',report,True,True,'v',1900,1000)
        dbcon.close()
        return redirect('/es_query_result/graph/{0}_hx_daily_event_num.html'.format(where))
    elif type == 'hx_monthly_event_name':
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_hx_monthly_event_name.html'.format(where)
        sql_query = 'select count(*) as num,SUBSTRING_INDEX(event, "<br>", 1) as firstevent from reqtriage where request_time like "%{0}%" and comment not like "%is팀%테스트%" and event like "%fireeye :%" group by firstevent order by num desc'.format(where)
        make_bar_graph(where,dbcon,sql_query,'Num','Event',True,'Num','Event',' FireeyeHX 발생 이벤트 통계  (총 이벤트 : {0} 건  *테스트 제외* )','이벤트 개수','',report,True,False,'h',1900,1000)
        dbcon.close()
        return redirect('/es_query_result/graph/{0}_hx_monthly_event_name.html'.format(where))
    elif type == 'hx_host_num' :
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_hx_host_num.html'.format(where)
        sql_query1 = 'select computer_name,count(*) as events from reqtriage where request_time like "%{0}%" and comment not like "%is팀%테스트%" and event like "%fireeye :%" group by computer_name order by events desc'.format(where)
        sql_query2 = 'select computer_name,count(*) as events from reqtriage where request_time like "%{0}%" and comment like "%[ Threat ]%" and event like "%fireeye :%" group by computer_name order by events desc'.format(where)
        make_double_bar_graph(where,dbcon,sql_query1,sql_query2,'User','Num',True,'Num','Num',' FireeyeHX 이벤트 발생 호스트 통계 (총 이벤트 : {0} 건  *테스트 제외* )','','이벤트 개수',report,True,True,'v',1900,1000)
        dbcon.close()
        return redirect('/es_query_result/graph/{0}_hx_host_num.html'.format(where))
    elif type == 'osint_ioc_num' :
        sqlitecon = sqlite3.connect('/home/apps/hxtool/hx_es_daemon/dbosint.db')
        sql_query1 = 'select reference,count(*) as num from osint_ioc where date like "%{0}%" group by reference'.format(where)
        report = '/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_osint_ioc_num.html'.format(where)
        make_bar_graph(where,sqlitecon,sql_query1,'reference','Num',True,'Num','Num',' FireeyeHX에 자동 등록된 OSINT IOC (Total IOC : {0})','','',report,True,False,'v',600,800)
        sqlitecon.close()
        return redirect('/es_query_result/graph/{0}_osint_ioc_num.html'.format(where))

#osint db에 저장된 ioc의 태그를 split 하여 각 tag 개수를 합산. 상위 50개를 bar graph로 생성하는 함수
def make_bar_OSINT_IOC_TAG(where) :
    if os.path.isfile('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.html'.format(where)):
        os.remove('/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.html'.format(where))
    dbcon = sqlite3.connect('/home/apps/hxtool/hx_es_daemon/dbosint.db')
    sql_query = 'select tag from osint_ioc where date like "%{0}%"'.format(where)
    cursor = dbcon.cursor()
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    all_tag = []
    for row in rows :
        tags = re.sub('\[|\]|u\'|\'|"','',row[0]).replace(' ','')
        if tags.find(',') > -1 : tags = tags.split(',')
        for tag in tags : 
            if len(tag) < 3 : continue
            all_tag.append(tag.lower())
    tag_group = dict(collections.Counter(all_tag))
    tags ,number_tmp , number =  [] , [] , []
    for tag,num in tag_group.iteritems():
        #tags.append(tag)
        number_tmp.append(num)
    number_tmp.sort(reverse=True)
    for tag,num in tag_group.iteritems():
        if num in number_tmp[0:50] :
            tags.append(tag)
            number.append(num)
    df = pd.DataFrame.from_dict({'Tag':tags,'Num':number})
    df = df.sort_values(['Num'], ascending=[1])
    text = df['Tag'] + ' : ' + df['Num'].map(str)
    title = where + ' Malware TAG Trend TOP 50<br>[ Reference : shodan.io / Hybrid-analysis.com / app.any.run ]'#.format(str(sumnum))
    trace1 = go.Bar(
        x=df['Num'],
        y=df['Tag'],
        text=text,
        textposition = 'auto',
        marker=dict(color='rgb(158,202,225)'),
        orientation = 'h'
    )
    layout = go.Layout(
        title=title,
        xaxis=go.layout.XAxis(title=''),
        yaxis=go.layout.YAxis(title='',visible=False),
        width=1800,
        height=1500,
    )
    data = [trace1] #Data([trace1])
    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig, filename='/home/apps/hxtool/hx_es_daemon/es_query_result/graph/{0}_ioc_tag.html'.format(where),auto_open=False)

# 단일 bar graph 생성함수 (ex : 이벤트명 별 이벤트 개수)
def make_bar_graph(where,dbcon,sql_query,column_x,column_y,issort,sort_column,show_column,title,x_title,y_title,filename,autosize,y_visible,orientation,width,height ) :
    if os.path.isfile(filename):
        os.remove(filename)
    cursor = dbcon.cursor()
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    df = pd.DataFrame( [[ij for ij in i] for i in rows] )
    df.rename(columns={0: column_x , 1: column_y}, inplace=True)
    if issort == True : df = df.sort_values([sort_column], ascending=[1])
    if orientation == 'h' : 
        sumnum = df[column_x].sum()
        text = df[show_column] + ' : ' + df[column_x].map(str)
    else : 
        sumnum = df[column_y].sum()
        text = df[show_column]
    title = where + title.format(str(sumnum))
    trace1 = go.Bar(
        x=df[column_x],
        y=df[column_y],
        text=text,
        #hovertext=test,
        textposition = 'auto',
        marker=dict(color='rgb(158,202,225)'),
        orientation = orientation
    )
    layout = go.Layout(
        title=title,
        xaxis=go.layout.XAxis(title=x_title,tickmode='linear'),
        yaxis=go.layout.YAxis(title=y_title,visible=y_visible,tickmode='linear'),
        width=width,
        height=height,
        autosize=autosize
    )
    data = [trace1] #Data([trace1])
    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig, filename=filename,auto_open=False)

# double bar  graph 생성 함수 (ex: 전체 이벤트 vs threat)
def make_double_bar_graph(where,dbcon,sql_query1,sql_query2,column_x,column_y,issort,sort_column,show_column,title,x_title,y_title,filename,autosize,y_visible,orientation,width,height ) :
    if os.path.isfile(filename):
        os.remove(filename)
    cursor = dbcon.cursor()
    cursor.execute(sql_query1)
    rows = cursor.fetchall()
    df1 = pd.DataFrame( [[ij for ij in i] for i in rows] )
    df1.rename(columns={0: column_x , 1: column_y}, inplace=True)
    cursor.execute(sql_query2)
    rows = cursor.fetchall()
    df2 = pd.DataFrame( [[ij for ij in i] for i in rows] )
    df2.rename(columns={0: column_x , 1: column_y}, inplace=True)
    if issort == True : df1 = df1.sort_values([sort_column], ascending=[1])
    text1 = df1[show_column]
    text2 = df2[show_column]
    if orientation == 'h' : 
        sumnum = df1[column_x].sum()
    else : sumnum = df1[column_y].sum()
    title = where + title.format(str(sumnum))
    trace1 = go.Bar(
        x=df1[column_x],
        y=df1[column_y],
        text=text1,
        #hovertext=test,
        textposition = 'auto',
        marker=dict(color='rgb(158,202,225)'),
        orientation = orientation,
        name = 'Total'
    )
    trace2 = go.Bar(
        x=df2[column_x],
        y=df2[column_y],
        text=text2,
        #hovertext=test,
        textposition = 'auto',
        marker=dict(color='rgba(222,45,38,0.8)'),
        orientation = orientation,
        name = 'Threat'
    )
    layout = go.Layout(
        barmode='group',
        title=title,
        xaxis=go.layout.XAxis(title=x_title,tickmode='linear'),
        yaxis=go.layout.YAxis(title=y_title,visible=y_visible,tickmode='linear'),
        width=width,
        height=height,
        autosize=autosize
    )
    data = [trace1,trace2] #Data([trace1])
    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig, filename=filename,auto_open=False)


# 텍스트 데이타를 입력 받아 파싱 >> ioc type 별로 수집 >> enterprise search 요청
# ioc type : 'File SHA256 Hash' , 'File SHA1 Hash' , 'File MD5 Hash' , 'Remote IP Address' , 'DNS Hostname' , 'URL'
QUERY_FORMAT = '{"operator": "equals", "field": "%s", "value": "%s"}'
ESFORMAT = '{"host_set": {"_id": 1004},"exhaustive": {"overrides": []},"query": [ %s ]}'  # must modify (1119 test , 1004 allpc)
# search data를 받아 es api 요청
def request_search(search_data):
    maru_restIsSessionValid()
    url = '/hx/api/v3/searches'
    response = request_hx(maru_token['token'],url,'','POST',search_data,'n')
    return response

# 수집한 ioc dic을 받아  type별로 es 요청 
# es search maximum item 개수 = 25개로 그 이상인 경우 나누어서  요청
#텍스트를 입력받는 폼
@app.route('/esfromtext',methods=['GET'])
def esfromtext():
    html = '<html><title>Enterprise Search</title>텍스트란에 IOC 가 포함된 Text를 입력하세요.<br>Text 에서 Hash , IP Address , Domain , URL 을 수집하여 Enterprise Search 를 자동 요청합니다. <br>*주의 : 300 개 이상의 IOC 값을 넣지 마세요!<br>*최대 15개의 Enterprise Search 동시 진행 가능하며 각 Enterprise Search 에 포함될 수 있는 최대 IOC 수는 25개입니다.<br><form action="/checkioc" method="post"><textarea name="description" cols=130 rows=1 onclick="this.value=\'\'">Enterprise Search 를 진행할 IOC 에 대한 설명을 입력하세요.</textarea><br><textarea name="reference" cols=130 rows=1 onclick="this.value=\'\'">참조한 URL을 입력하세요.</textarea><br><textarea name="ioc" cols="130" rows="20">IOC가 포함된 Text를 입력하세요.\r\n</textarea><div><div style="display:inline;width:200px;"><input type="submit" value="GetIOC" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;"></div></form>'
    return html


# text에서 ioc를 분류,수집 한 후 textarea 로 edit 가능하도록 출력한다.
@app.route('/checkioc',methods=['POST'])
def checkioc():
    text = request.form['ioc'].lower()
    description = request.form['description']
    reference = request.form['reference']
    ioc_dic = get_ioc_in_text(text)
    ioc_dic_str = ''
    for ioc_type in ioc_dic.keys():
        #if len(ioc_dic[ioc_type]) == 0 : continue
        ioc_dic_str += '[ ' + ioc_type + ' ]' + '\r\n'
        for item in ioc_dic[ioc_type] :
            if ioc_dic_str.find(item) == -1 :
                ioc_dic_str += item + '\r\n'
        ioc_dic_str += '\r\n'
    html = '<html><title>Enterprise Search</title>텍스트에서 찾은 IOC 값을 확인하고 잘못된 IOC를 삭제하거나 추가 할 IOC를 입력하세요<br>수정 후 "Enterprise Search" 버튼을 클릭하면 해당 IOC들을 Enterprise Search 로 검색합니다.<br>"Reservation" 버튼을 클릭하면 업무 시간 외 검색을 진행하도록 예약합니다.<form action="/reqsearch" name="reqform" method="post"><textarea name="description" cols="130" rows="1">{0}</textarea><br><textarea name="reference" cols="130" rows="1">{1}</textarea><br><textarea name="ioc" cols="130" rows="20">{2}</textarea><br><div><div style="display:inline;width:200px;"><input type="button" value="Enterprise Search" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;" onclick="mysubmit(1)"> <input type="button" value="Reservation" style="font-size:12px;background-color:#084B8A;border:0px red solid; color:#ffffff;" onclick="mysubmit(2)"></div></form>'.format(description,reference,str(ioc_dic_str))
    html += '<script>function mysubmit(index) { if(index==1){document.reqform.action = "/reqsearch";}if(index==2){document.reqform.action = "/esioc_reservation";}document.reqform.submit();}</script></html>'
    return html
# ioc 검색 예약을 위한 작업 : 파일에 저장
@app.route('/esioc_reservation',methods=['POST'])
def esioc_reservation() :
    reserv_dir = '/home/apps/hxtool/hx_es_daemon/ioces_reserved'
    if os.path.isdir(reserv_dir) == False : os.mkdir(reserv_dir)
    text = request.form['ioc'].lower()
    description = request.form['description']
    reference = request.form['reference']
    ioc_dic = get_ioc_in_text(text)
    with open(os.path.join(reserv_dir,description.replace(' ','_')),'wb') as f :
        f.write(description + '\n')
        f.write(reference + '\n')
        f.write(str(ioc_dic) + '\n')
    return 'IOC Enterprise Search 예약 완료. (0 시 ~ 08 시 검색 예정)'


# hx server 에 enterprise search를 요청한다.
@app.route('/reqsearch',methods=['POST'])
def reqsearch():
    text = request.form['ioc'].lower()
    description = request.form['description']
    reference = request.form['reference']
    ioc_dic = get_ioc_in_text(text)
    return (send_ioc(ioc_dic,description,reference))

def send_ioc(ioc_dic,description,reference) :
    try :
        maru_restIsSessionValid()
        result = ''
        allioc = 0
        no_zero_ioc_type = 0
        response = request_hx(maru_token['token'],'/hx/api/v3/searches','','GET',None,'n')
        # 이전 요청에 의해 N 개 이상의 서치 있으면 중단 / client 가용성 문제
        if response['data']['total'] > 5 :
            return '현재 진행 중인 Enterprise Search가 존재하여 입력한 IOC 들을 검색 할 수 없습니다.'
        for ioc_type in ioc_dic.keys() :
            allioc += len(ioc_dic.get(ioc_type))
            if len(ioc_dic.get(ioc_type)) != 0 : no_zero_ioc_type += 1            
        # 입력받은 ioc 개수를 모두 검색 할 수 있는지 확인
        if (15 * 25) - (response['data']['total'] * 25) < allioc or (15 - response['data']['total'] < no_zero_ioc_type) :
            return '%d 현재 진행 중인 Enterprise Search가 존재하여 입력한 IOC 들을 모두 검색 할 수 없습니다.<br>불필요한 Enterprise Search를 삭제하고 재시도 바랍니다.<br><a href = "https://112.175.67.137:3000/hx/enterprise_search" target=_blank>* HX Enterprise Search Menu</a>'%allioc
        # ioc_type 별로 진행
        for ioc_type in ioc_dic.keys() :
            if len(ioc_dic.get(ioc_type)) == 0 : continue # ioc 갯수가 0 이면 패스
            query , data  = '' , '' 
            for idx,item in enumerate(ioc_dic.get(ioc_type)) : 
                if idx != len(ioc_dic.get(ioc_type)) -1 : # ioc list 마지막 item이 아니고
                    if ((idx+1)%25) != 0  : query += (QUERY_FORMAT)%(ioc_type,item) + ',' # 검색 가능 최대치인 25로 나누어지지 떨어지지 않을 경우 query format 마지막에 , 추가
                    else : query += (QUERY_FORMAT)%(ioc_type,item)  # 25로 나누어질 경우 검색 가능 최대치가 된 것으로 판단하고 query format 을 완성한다.
                else :  # ioc list 마지막일 경우 query format 을 완성한다.
                    query += (QUERY_FORMAT)%(ioc_type,item)
                data = (ESFORMAT)%query
                if ((idx+1)%25) == 0 : # 검색 최대치이면 es 요청 후 DB저장 , 변수 초기화
                    response = request_search(data)
                    result += json.dumps(response) + '<br><br>'
                    search_id = response['data']['_id']
                    request_time = response['data']['create_time']
                    insert_ioc_es(str(search_id),request_time,json.dumps(ioc_dic),description,reference)
                    query , data  = '' , '' 
            if data == '' : continue # 사전에 요청 되어 data가 초기화 되면 패스
            response = request_search(data)
            result += json.dumps(response) + '<br><br>'
            #ioc_es table : search_id , request_time , end_time , ioc_dic , hx_response_json , description , reference , search_result_json , userinfo , es_summary
            search_id = response['data']['_id'] # error point 
            request_time = response['data']['create_time']
            insert_ioc_es(str(search_id),request_time,json.dumps(ioc_dic),description,reference) 
        return '<a href = "https://112.175.67.137:3000/hx/enterprise_search" target=_blank>* HX Enterprise Search Menu</a><br><br><a href = "' + hxtool_srv + '/es_query_result/triage_list/ls">* Triage List View</a><br><br>' + '[ Request Enterprise Search Result ]<br>' + result
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        sendalarm('* HX REQ Triage Error : ' + str(err) + '\r\n\r\n' + str(response) + '\r\n\r\n' + str(data) ,errorreceiver)
        passive_traige_error.error(str(err))


def insert_ioc_es(search_id,request_time,ioc_dic,description,reference) :
    try:
        description = description.replace("'","")
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('insert ignore into ioces values(\'{0}\',\'{1}\',\'{2}\',\'{3}\',\'{4}\',\'{5}\',\'{6}\',\'{7}\',\'{8}\',\'{9}\')'.format(search_id,request_time,'',ioc_dic,'',description,reference,'','',''))
        con.commit()
        con.close()
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

def forprint(title,arrary):
    if len(arrary) == 0 : return 0
    print '\r\n\r\n' + title
    for i in arrary:
        print i

#전달받은 텍스트에서 정규식을 이용하여 ioc 를 분류,수집한다. ioc_dic 리턴
def get_ioc_in_text(input) :
    URL = input
    #https://data.iana.org/TLD/tlds-alpha-by-domain.txt    (root domain list)
    with open('rootdomainlist.txt','rb') as f :
        rootdomain = f.read()
    rootdomain = rootdomain.split('\n') # linux \n , windows \r\n
    DOT = '(\.|\[dot\]|\[\.\])'
    REPLACEEOF = '(\r\n|\n|<|>|\t)'
    CMD = [' systeminfo','net1.exe ','cmd.exe ','powershell.exe ','wscript.exe ','vbscript.exe ','wmic.exe ',' /c ',' /v ',' /k ',' /v ']
    #file
    contents_tmp = input
    contents_tmp = contents_tmp.split('\r\n')
    # web
    '''
    response = requests.get(URL)
    contents_tmp  = unicode(response.text.decode('utf-8')).encode('utf-8')
    contents_tmp = contents_tmp.split('\r\n')
    contents_tmp =re.sub('<a href.+</a>','',contents_tmp)
    contents_tmp = re.findall(r'>[^<>=\{\}]+<',contents_tmp)
    '''
    contents = ''
    for i in contents_tmp :
        contents += i.replace('>','').replace('<','') + '\n'
    if 1 !=1 : # contents.find('<br>') > -1 or contents.find('<p>') > -1 : 
        type = 'html'
        EOFCHAR = '<'
        HEADCHAR = '>'
    else : 
        type = 'text'
        EOFCHAR = '' #'(\r\n|\n)'
        HEADCHAR = ''
    # Get IOC Functions    
    #IOC List
    ioc_dic = {'File SHA256 Hash':[] , 'File SHA1 Hash':[] , 'File MD5 Hash':[] , 'Remote IP Address':[] , 'DNS Hostname':[] , 'URL':[], 'File Full Path':[],'Process Arguments':[]}

    # get ipaddress
    #tmp = re.findall('((' + HEADCHAR +' \d{1,3}' + DOT + '){3}\d{1,3}' + EOFCHAR + ')',contents)
    tmp = re.findall('((\d{1,3}(\.|\[dot\]|\[\.\])){3}\d{1,3})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        item = list(set(item))
        for i in item :
            i = i.strip()
            if i not in ioc_dic['Remote IP Address'] and len(i) > 5 :
                ioc_dic['Remote IP Address'].append(i)


    #get url
    tmp = re.findall('((http|https|hxxp|hxxps)\:\/\/((\S+\/?)([a-zA-Z0-9\-_]|(\.|\[dot\]|\[\.\]))+){1,5})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip().replace('hxxp','http')
            if i not in ioc_dic['URL'] and len(i) > 5  :
                ioc_dic['URL'].append(i)

                
    # get domain
    tmp = re.findall('([a-zA-Z\-0-9]{3,30}(\.|\[dot\]|\[\.\])[a-zA-Z\-0-9]{3,30}(\.|\[dot\]|\[\.\])[a-zA-Z\-0-9]{5,30}(\.|\[dot\]|\[\.\])[a-zA-Z]{2,30})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if i not in ioc_dic['DNS Hostname'] and len(i) > 5 and i.split('.')[-1].upper() in rootdomain and str(ioc_dic['URL']).find(i) == 1 :
                ioc_dic['DNS Hostname'].append(i)         
    tmp = re.findall('([a-zA-Z\-0-9]{3,30}(\.|\[dot\]|\[\.\])[a-zA-Z\-0-9]{5,30}(\.|\[dot\]|\[\.\])[a-zA-Z]{2,30})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if i not in ioc_dic['DNS Hostname'] and len(i) > 5 and i.split('.')[-1].upper() in rootdomain and str(ioc_dic['URL']).find(i) == 1 :
                ioc_dic['DNS Hostname'].append(i)            
    tmp = re.findall('([a-zA-Z\-0-9]{5,30}(\.|\[dot\]|\[\.\])[a-zA-Z]{2,30})',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if i not in ioc_dic['DNS Hostname'] and len(i) > 5 and i.split('.')[-1].upper() in rootdomain and str(ioc_dic['URL']).find(i) == 1 :
                ioc_dic['DNS Hostname'].append(i) 
                
    #get sha256
    tmp = re.findall('[A-Fa-f0-9]{64}'+EOFCHAR,contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item= item.strip()
        if item not in ioc_dic['File SHA256 Hash'] and len(item) > 5 :
            ioc_dic['File SHA256 Hash'].append(item) 
            
     #get sha1
    tmp = re.findall('[A-Fa-f0-9]{40}'+EOFCHAR,contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item= item.strip()
        if item not in  ioc_dic['File SHA1 Hash'] and len(item) > 5 and str(ioc_dic['File SHA256 Hash']).find(item) == -1  :
            ioc_dic['File SHA1 Hash'].append(item)
            
     #get md5
    tmp = re.findall('[A-Fa-f0-9]{32}'+EOFCHAR,contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item= item.strip()
        if item not in ioc_dic['File MD5 Hash'] and len(item) > 5 and str(ioc_dic['File SHA256 Hash']).find(item) == -1 and str(ioc_dic['File SHA1 Hash']).find(item) == -1 :
            ioc_dic['File MD5 Hash'].append(item)   
            
    # get file name
    tmp = re.findall('(((([a-zA-Z]:\\\\)|%)([a-zA-Z\-_0-9\[\]%\s]+)\\\\)+.{1,30}(\.[a-zA-Z_0-9]{3}))',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            i = i.strip()
            if bool(re.search('"|\'',i)) == False and i not in ioc_dic['File Full Path'] and len(i) > 5 and i.find(' /') == -1  :
                    ioc_dic['File Full Path'].append(i)
     

    '''
    #get cmdline
    tmp = re.findall('.+\s/[a-z]\s.+',contents)
    for item in tmp :
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        if item not in ioc_dic.values() :
            ioc_dic['Process Arguments'].append(item)
    #get cmdline
    tmp = re.findall('(powershell|cmd|wscript|wmic|bitadmin|tasklist|taskkill|net1)(\.exe)?\s.{10,300}',contents)
    for item in tmp :
        item = item[0]
        item = re.sub(REPLACEEOF,'',item)
        item = re.sub(DOT,'.',item).split(',')
        for i in item :
            if i not in ioc_dic.values() :
                ioc_dic['Process Arguments'].append(i)
    '''        
    '''
    forprint('[hash_sha256]',ioc_dic['File SHA256 Hash'] )
    forprint('[hash_sha1]',ioc_dic['File SHA1 Hash'])
    forprint('[hash_md5]',ioc_dic['File MD5 Hash'])
    forprint('[domain]',ioc_dic['DNS Hostname'])
    forprint('[ipaddress]',ioc_dic['Remote IP Address'])
    forprint('[filepath]',ioc_dic['File Full Path'])
    forprint('[url]',ioc_dic['URL'])
    #forprint('[cmdline]',ioc_dic['Process Arguments'])
    '''
    return ioc_dic

# 총무팀 pc list 정보 출력
from flask import Response
from bs4 import BeautifulSoup
def get_bonsa_pclist(req_type):
    if req_type.find('testpc') > -1 : url = 'http://general.hanpda.com/test/pclist2.php'
    else : url = 'http://general.hanpda.com/test/pclist.php'
    req=requests.get(url)
    html=req.text
    soup=BeautifulSoup(html,'html.parser')
    columns=soup.select('table.w3-striped > tbody > tr > td')
    newlines = []
    only_ip = []
    line = ''
    for idx,col in enumerate(columns) :
        col = str(col)
        col = col.replace('<td>','').replace('</td>','')
        if (idx + 1) %6 == 0 : 
            #line += ' ' + col
            line = line.split('=split=')
            line = line[0] + '=split=' + line[1] + '=split=' + line[2]
            if req_type.find('testpc') > -1 : 
                if col == 'O' : newlines.append(line)
            else : newlines.append(line)
            line = ''
        elif (idx + 1) %6 == 1 : 
            line +=  'id=' + col + '=split='
        elif (idx + 1) %6 == 2 : 
            line +=  'name=' + col + '=split='
        elif (idx + 1) %6 == 3 : 
            line +=  'ip=' + col + '=split='
        #else : line +=  col + '=split='
        
    newlines.pop(0)
    info_text = ''
    for line in newlines :
        ip = line.split('=split=')[2]
        if ip !='ip=' : only_ip.append(ip)
        line = line.replace('=split=',',')
        if line.find('id=,name=,ip=') > -1 : continue
        info_text += line + '\n'
    
    if req_type.find('iplist') > -1 :
        info_text = ''
        for ip in only_ip :
            info_text += ip + '\n'
    return info_text
    
@app.route('/allpclist',methods=['GET'])
def allpclist():
    info_txt = get_bonsa_pclist('allpclist')
    return Response(info_txt, mimetype='text/plain')

@app.route('/alliplist',methods=['GET'])
def alliplist():
    info_txt = get_bonsa_pclist('alliplist')
    return Response(info_txt, mimetype='text/plain')

@app.route('/alltestpclist',methods=['GET'])
def alltestpclist():
    info_txt = get_bonsa_pclist('alltestpclist')
    return Response(info_txt, mimetype='text/plain')

@app.route('/alltestpciplist',methods=['GET'])
def alltestpciplist():
    info_txt = get_bonsa_pclist('alltestpciplist')
    return Response(info_txt, mimetype='text/plain')


# agent 가 설치된 hosts 정보를 수집하여 출력한다.
@app.route('/hosts_info',methods=['GET'])
def hosts_info():
    host_info_dic , host_info_dic_long = get_all_agent_info()
    #info_txt = 'Total FireeyeHX Agent Num : %d <br>'%len(host_info_dic)
    #info_txt += 'last_poll_ip ; hostname ; initial_agent_checkin ; last_audit_timestamp ; agent_url' + '<br>'
    info_txt = ''
    for host_info in host_info_dic_long :
        info_txt += host_info
    return Response(info_txt.replace('\n','<br>'))
    
@app.route('/hosts_info2',methods=['GET'])
def hosts_info2():
    host_info_dic , host_info_dic_long = get_all_agent_info()
    #info_txt = 'Total FireeyeHX Agent Num : %d <br>'%len(host_info_dic)
    #info_txt += 'last_poll_ip ; hostname ; initial_agent_checkin ; last_audit_timestamp ; agent_url' + '<br>'
    info_txt = ''
    for host_info in host_info_dic :
        info_txt += host_info.split(' ')[-1].replace('ip=','')
    return Response(info_txt.replace('\r\n','\n'), mimetype='text/plain')


def get_all_agent_info() :
    maru_restIsSessionValid()
    url = '/hx/api/v3/hosts'
    host_info_dic = []
    host_info_dic_long = []
    ip_dic = []
    response = request_hx(maru_token['token'],url,'?limit=10000&sort=last_audit_timestamp+descending','GET',None,'n')
    for entry in response['data']['entries'] :
        try:
            host_info_short = ''
            host_info_long = ''
            host_info_short2 = ''
            host_info_long2 = ''            
            initial_agent_checkin = entry['initial_agent_checkin']
            last_audit_timestamp = entry['last_audit_timestamp']
            agent_url = entry['sysinfo']['url']
            agent_id = entry['_id']
            #primary_mac = entry['primary_mac']
            last_poll_ip = entry['last_poll_ip']
            primary_ip = entry['primary_ip_address'] # here
            hostname = entry['hostname']
            if hostname == None : hostname = 'NotFoundHostname'
            host_info_long += last_poll_ip + ';' + '<a href="' + 'https://112.175.67.137:3000/hx/#/hosts/' + agent_id + '" target="_blank">' + hostname + ';' + '</a>' + initial_agent_checkin + ';' + last_audit_timestamp + ';' + agent_url + '\n'
            host_info_long2 += primary_ip + ';' + '<a href="'+ 'https://112.175.67.137:3000/hx/#/hosts/' + agent_id +'" target="_blank">' + hostname + ';' + '</a>' + initial_agent_checkin + ';' + last_audit_timestamp + ';' + agent_url + '\n'
            #host_info_long : 192.168.1.139;judePC-W;2018-09-28T01:58:35.322Z;2018-10-04T03:01:30.620Z;/hx/api/v3/hosts/HBwM3yY2BR7ep9ZFRIlEdY/sysinfo
            host_info_short += 'id=' + hostname + ' ' + 'ip=' + last_poll_ip + '\n'
            host_info_short2 += 'id=' + hostname + ' ' + 'ip=' + primary_ip + '\n'            
            if last_poll_ip not in ip_dic :
                ip_dic.append(last_poll_ip)
                if host_info_short not in host_info_dic: host_info_dic.append(host_info_short)
                if host_info_long not in host_info_dic_long: host_info_dic_long.append(host_info_long)
            if last_poll_ip != primary_ip :
                if primary_ip not in ip_dic :
                    ip_dic.append(primary_ip)
                    if host_info_short2 not in host_info_dic: host_info_dic.append(host_info_short2)
                    if host_info_long2 not in host_info_dic_long: host_info_dic_long.append(host_info_long2)
                    
            '''
            primary_ip_address = entry['primary_ip_address']
            if primary_ip_address == None : primary_ip_address = 'NotFoundPrimary_ip_address'
            if last_poll_ip != primary_ip_address : 
                print last_poll_ip + ';' + primary_ip_address
            '''
        except Exception as err:
            print err
            continue
    host_info_dic.sort()
    host_info_dic_long.sort()
    return host_info_dic,host_info_dic_long


# Triage 파일 내 md5 를 max cloud antivirus api 로 질의한다. 
# 결과는 쪽지로 전송하고 popen 을 이용하여 독립된 프로세스로 실행한다.
# mans > unzip > make online file > grep > collect md5 value > request max api > send alarm
@app.route('/es_query_result/triage_list/req_maxav',methods=['GET'])
def req_maxav() : 
    try : 
        triage_id = request.args.get('triage_id')
        con = dbconn()
        cursor = con.cursor()
        cursor.execute('select state from reqtriage where triage_id = "%s"'%triage_id)
        row = cursor.fetchone()
        con.close()
        if row[0] != 'COMPLETE' : return '<script>alert("현재 Triage 수집이 완료되지 않았습니다. 상태가 COMPLETE 로 변경되면 다시 시도하세요..");history.back();</script>'
        con = sqlite3.connect('/home/apps/hxtool/HXTool-3.0/hashdb')
        cursor = con.cursor()
        create_hashdb_table = '''
        create table if not exists hashdb(idx integer primary key autoincrement,first_inserted_time text,last_checked_time text,hash_reference text,hash_type text,hash_value text,
        report_type text,report_url text,full_result text,result text,original_line text,checked_filename text,etc1 text,etc2 text,etc3 text)
        '''
        cursor.execute(create_hashdb_table)
        create_hashdb_table = '''
        create table if not exists maxav_alarm(idx integer primary key autoincrement, triage_id text , alarm text , etc1 text , etc2 text , etc3 text)
        '''
        cursor.execute(create_hashdb_table)
        con.commit()
        cursor.execute('select alarm from maxav_alarm where triage_id = "%s"'%triage_id)
        row = cursor.fetchone()
        if row != None :
            if len(row) > 0 : return row[0].replace('\r\n','<br>')
        path = '/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files'
        mans = path + '/' + triage_id + '.mans'
        onelinefile = path + '/' + triage_id + '.one'
        if os.path.isfile('/home/apps/hxtool/hx_es_daemon/es_query_result/passive_triage_files/%s.one'%triage_id) == False :
            maru_restIsSessionValid()
            response =  download_triage(maru_token['token'],'/hx/api/v3/acqs/triages/{0}.mans'.format(triage_id))
            if response.find('Not Found') == -1 :
                extract_path = path + '/' + triage_id + '_extract'
                if os.path.isfile(onelinefile)  == False :
                    if os.path.isfile(mans) :
                        flist = unzip_triage(mans,extract_path)
                        for file in flist :
                            make_oneline(os.path.join(extract_path,file),onelinefile)
                    else :
                        return '"error":"Not Found Triage File"'
        check_duplicated = os.popen('ps -ef').read()
        if check_duplicated.find('python /home/apps/hxtool/hx_es_daemon/lib/maxav_for_hxtool_srv.py') > -1 :
            msg = '<script>alert("현재 클라우드 백신 검사가 진행 중인 Triage가 확인되었습니다.잠시 후 다시 시도하세요.");history.back();</script>'
        else :
            msg = '<script>alert("해당 Triage 파일에 포함된 md5를 추출하여 클라우드 백신 검사를 진행하고 있습니다.검사가 완료되면 쪽지로 결과가 전송됩니다.");history.back();</script>'
            os.spawnl(os.P_NOWAIT,'/usr/bin/python','python','/home/apps/hxtool/hx_es_daemon/lib/maxav_for_hxtool_srv.py','triage',onelinefile)
        return msg
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#health check
@app.route('/es_query_result/hxhealth',methods=['GET'])
def hxhealth() : 
    try : 
        report = health_check_hx()
        return Response(report, mimetype='text/plain')
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

#daily report
import security_daily_report
@app.route('/daily_report',methods=['GET'])
def daily_report() :
    html = '''
    * 파이어아이 일일 이벤트 자동 생성 페이지<br>
    * 레포트에 포함될 이벤트 검색 시작 날짜 입력 (ex : 2019/05/10)<br>
    <form action="/make_daily_report" method="post">
    <input type="text" name="startdate">
    <input type="submit" value="레포트 생성" style="font-size:15px;background-color:#084B8A;border:0px red solid; color:#ffffff;">
    </form>
    '''
    return html
    
@app.route('/make_daily_report',methods=['POST'])
def make_daily_report() :
    try :
        startdate = request.form['startdate']
        if startdate != '' :
            report = security_daily_report.report(startdate)
        else : report = 'Report Error'
        #return Response(report, mimetype='text/plain')
        return Response(report)
    except Exception as err:
        err = str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        passive_traige_error.error(str(err))

###Main ####
############
       


import urllib
def check_host(token,device,category,computer_name,ipaddr):
    print 'kakaka'
    print computer_name
    print token
    search_url = '?search=' + computer_name + '&sort=last_audit_timestamp+descending&limit=100'
    search_url = urllib.parse.urlparse(search_url)
    search_url = urllib.parse.parse_qs(search_url.query)
    search_url = '?' + urllib.parse.urlencode(search_url,doseq=True)
    print search_url
    check_only_ipaddress = ['ntp','fortinet'] # IP로 검색해야 하는 카테고리
    try:
        iplist = []
        result = {"state":"okay","message":"not_found_agent_false"}
        maru_restIsSessionValid()
        # get agent_id from computer_name or ipaddress 
        if computer_name != '' and category.lower() not in check_only_ipaddress : 
            response = request_hx(token,HXSRV_HOSTS,search_url,'GET',None)
            print json.dumps(response,indent=2,ensure_ascii=False)
            if response['data']['total'] == 0 : 
                return {"state":"okay","message":"not_found_agent_false"}
            for entry in response['data']['entries'] :
                if computer_name.lower() == entry['hostname'].lower() :
                    if 1==1 : #check_last_triage_time(entry['_id'],device,category) == True : 
                        result = entry['_id']
                    else : result = {"state":"okay","message":"req_duplicated_false"}
                    break
                else : result = {"state":"okay","message":"not_found_agent_false"}
        elif ipaddr != '' :
            response = request_hx(token,HXSRV_HOSTS,'?search=' + ipaddr + '&sort=last_audit_timestamp+descending&limit=200','GET',None)
            #print json.dumps(response,indent=4)
            if response['data']['total'] == 0 : 
                return {"state":"okay","message":"not_found_agent_false"} 
            for entry in response['data']['entries'] :
                if ipaddr == entry['last_poll_ip'] :
                    if 1==1 : #check_last_triage_time(entry['_id'],device,category) == True : 
                        result = entry['_id']
                    else : result = {"state":"okay","message":"req_duplicated_false"}
                    break
                else : result = {"state":"okay","message":"not_found_agent_false"}
            '''
            for netinfo in sysinfo['data']['networkArray']['networkInfo'] :
                if netinfo.has_key('ipArray') :
                    if netinfo['ipArray'].has_key('ipInfo') :
                        for ipinfo in netinfo['ipArray']['ipInfo'] :
                            if ipinfo.has_key('ipAddress') :
                                ip = ipinfo['ipAddress']
                                if ip.find('127.0.0.1') == -1 and ip.find('169.254') == -1 :
                                    iplist.append(ip)
            if ipaddr in iplist :
                if self.check_last_triage_time(entry['_id'],device,category) == True :
                    result = entry['_id']
            else : result = 'check_last_triage_time_false'
            '''
        print  result
        #allhost = request_hx(maru_token,HXSRV_HOSTS,'?limit=10000','GET',None,'yes')
    except Exception as err:
        err = {"state":"error","message": str(err) + ' Error on line {}'.format(sys.exc_info()[-1].tb_lineno)}
        #sendalarm('* HX REQ Triage Error : ' + str(err),errorreceiver)
        print err



 
if __name__ == "__main__":
    
    check_host(token,'symantec','threats',u'JC-3층02','')
    '''
    print DBTYPE
    app.secret_key = crypt_generate_random(32)
    
    app.logger.setLevel(logging.INFO)
    
    # Log early init/failures to stdout
    console_log = logging.StreamHandler(sys.stdout)
    console_log.setFormatter(logging.Formatter('[%(asctime)s] {%(module)s} {%(threadName)s} %(levelname)s - %(message)s'))
    app.logger.addHandler(console_log)
    
    ht_config = hxtool_config('conf.json', logger = app.logger)
    
    # Initialize configured log handlers
    for log_handler in ht_config.log_handlers():
        app.logger.addHandler(log_handler)

    # WSGI request log - when not running under gunicorn or mod_wsgi
    logger = logging.getLogger('werkzeug')
    if logger:
        logger.setLevel(logging.INFO)
        request_log_handler = logging.handlers.RotatingFileHandler('log/access.log', maxBytes=50000, backupCount=5)
        request_log_formatter = logging.Formatter("[%(asctime)s] {%(threadName)s} %(levelname)s - %(message)s")
        request_log_handler.setFormatter(request_log_formatter)
        logger.addHandler(request_log_handler)

    # Start
    app.logger.info('Application starting')

    # Init DB
    ht_db = hxtool_db('hxtool.db', logger = app.logger)
    
    if ht_config['network']['ssl'] == "enabled":
        context = (ht_config['ssl']['cert'], ht_config['ssl']['key'])
        app.run(host=ht_config['network']['listen_address'], port=ht_config['network']['port'], ssl_context=context, threaded=True,debug=True)
    else:
        app.run(host=ht_config['network']['listen_address'], port=ht_config['network']['port'],threaded=True,debug=True)

   '''

